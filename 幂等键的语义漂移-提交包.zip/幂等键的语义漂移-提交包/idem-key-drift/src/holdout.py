"""
holdout.py — 冻结的隐藏测试集（审阅方第六/七节要求）。

为什么要单独一个文件
--------------------
审阅方指出：我同时做扰动器、定义标签、设计策略、生成诱饵、解释结果。
这不自动导致错误，但会产生共同盲区——**策略和测试用同一套领域词表**，
于是缺陷可能被双方一起接受。v1 的过程正好是"补诱饵→改策略→在同一诱饵集上
评估"，这是标准的开发集反复适配。

★ 第三轮补的第三个洞：**原先 18 组全是负例**（全部要求"不同键"）。
  这意味着一个永不合并的策略也能拿 0/18 碰撞，满分。
  这样的集合能补充安全边界探针，但不能比较策略总体能力，更不能证明泛化。

  现在正负两类都收，并且**分开报告三个数**：
    · 正确合并率  —— 正例里被合并的比例（越高越好）
    · 错误合并率  —— 负例里被合并的比例（越低越好）
    · 选择性拒绝率 —— 负例里被判"不同键"的比例
  只报碰撞率是不行的：永不合并的极端策略碰撞率恒为 0。

本文件的纪律：
  1. 诱饵的构造方式与 universe.build_decoys **不同源**：
     不按"工具 × 字段"生成，而是按"业务场景"生成，字段组合更随意；
  2. 只在最后评估阶段被 import 一次，不参与任何策略设计；
  3. 真值由契约（contract.py）给出，不由我手工标注；
  4. 一旦写定，**不再修改**。修改必须记进 data/holdout_freeze.json 的版本号。

关于第 3 条要收窄（审阅方第七节（二））
--------------------------------------
"真值由 contract 给出"这个说法过头了。实际实现是手写 `add()` 把输入对和
理由填进去——**没有独立调用任何语义裁判**。而 contract.py 与 holdout.py
由同一个开发者、在同一个可见范围内产出，没有提交时间、冻结哈希、外部保管
记录。所以：

  · 它能证明的：这份测试在**冻结之后**没被改过（只要哈希对得上）；
  · 它不能证明的："只评一次、不参与设计"这个过程。
    后者需要外部保管或第三方代持，本包做不到，也不声称做到了。

冻结证据写在 data/holdout_freeze.json（内容哈希 + 生成时刻 + 条目计数），
run_experiments 每次跑都会重算并比对，不一致就报 "holdout 被动过"。

隐藏集与主集的差别（刻意为之）
----------------------------
  · 主集只覆盖 5 个海区、4 个站、3 个月；隐藏集加入主集没有的取值
  · 主集的备注都是"S07 温度传感器疑似漂移"；隐藏集包含数字、日期、否定式
  · 主集没有"同一对象上多个字段同时不同"的样本；隐藏集有（检验是否会
    因为一处差异就被整体判为不同，从而漏掉真正的问题）
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, List, Tuple

from universe import Decoy, LogicalOp

# 隐藏集专用取值：主集的 REGIONS/STATIONS/MONTHS 里没有这些
_H_REGIONS = ["南海北部", "冲绳海槽", "吕宋海峡", "苏禄海"]
_H_STATIONS = ["S07", "C22", "B04", "K11"]
_H_MONTHS = ["2026-08", "2027-03", "2027-11"]

# 冻结版本号：改动 must bump，并在报告里记一笔
FREEZE_VERSION = 3

# 每一条的极性
POS = "正例"     # 语义相同、写法不同 → 期望合并
NEG = "负例"     # 语义不同 → 期望分开


def build_holdout() -> List[Decoy]:
    """
    按场景构造。每条都写明"为什么这两个是/不是同一件事"。

    ★ 第三轮：正例与负例成对覆盖同一批边界，这样"选择性拒绝"才有意义——
    一个只会说"不同"的策略，负例全对、正例全错，三个数一看就露馅。
    """
    out: List[Decoy] = []

    def add(kind: str, tool: str, a_slots, b_slots, changed, why,
            polarity: str = NEG, used_in_dev: bool = False):
        tag = "p" if polarity == POS else "n"
        d = Decoy(
            LogicalOp(f"h_{tag}{len(out):03d}", tool, a_slots, kind),
            LogicalOp(f"h_{tag}{len(out):03d}_d", tool, b_slots, kind),
            tuple(changed), kind, why, polarity)
        # ★ 是否已经被用于开发（"看着它的结果改过代码"）。
        #   这不是洁癖：一旦用于开发，它就不再是泛化证据，只是开发集。
        #   报告里必须同时给"全量"和"扣除已污染项"两个数。
        d.used_in_dev = used_in_dev
        out.append(d)

    # ================= 正例：语义相同，写法不同 → 应合并 =================
    # 每一对都与下面某条负例共享边界，只是落在"同侧"

    add("正-月份换写法", "query_region_stats",
        {"region": "冲绳海槽", "month": "2026-08"},
        {"region": "冲绳海槽", "month": "2026年8月"},
        ["month"], "同一个月，只是写法不同：月精度内部等价", POS)

    add("正-站号大小写", "query_station_stats",
        {"station": "C22", "month": "2027-03"},
        {"station": "c-22", "month": "2027-03"},
        ["station"], "同一站号，大小写与连字符不同", POS,
        used_in_dev=True)   # ← 本轮首跑 6/8 失败，据此改了 norm_station

    add("正-区域别名", "geocode_region",
        {"region": "冲绳海槽", "res": 7, "coverage": "all_intersecting"},
        {"region": "冲绳海槽", "res": "7", "coverage": "all_intersecting"},
        ["res"], "数字写成字符串，同一分辨率", POS)

    add("正-默认值显式化", "submit_batch_job",
        {"job_name": "recompute_C22_2027-03", "station": "C22", "month": "2027-03"},
        {"job_name": "recompute_C22_2027-03", "station": "C22",
         "month": "2027-03", "cores": 32},
        ["cores"], "cores=32 是 schema 默认值，显式写出不改变请求", POS)

    add("正-布尔写成字符串", "query_station_stats",
        {"station": "K11", "month": "2027-11", "include_qc": True},
        {"station": "K11", "month": "2027-11", "include_qc": "true"},
        ["include_qc"], "布尔写成字符串，同一取值", POS)

    add("正-作业名换分隔符", "submit_batch_job",
        {"job_name": "recompute_C22_2027-03", "station": "C22", "month": "2027-03"},
        {"job_name": "RECOMPUTE-C22-202703", "station": "C22", "month": "2027-03"},
        ["job_name"], "作业名大小写/分隔符/紧凑月份写法不同，槽位一致", POS,
        used_in_dev=True)   # ← 本轮首跑 6/8 失败，据此改了 STATION_PAT

    add("正-键序不同", "write_qc_note",
        {"station": "B04", "month": "2026-08", "note": "低盐度导致密度跃层上移"},
        {"note": "低盐度导致密度跃层上移", "month": "2026-08", "station": "B04"},
        [], "字典键序不同，内容完全一致", POS)

    add("正-追踪字段", "send_email",
        {"to": "watch@marine.example", "subject": "S07 异常", "body_ref": "B-101"},
        {"to": "watch@marine.example", "subject": "S07 异常", "body_ref": "B-101",
         "__trace": "req-9f2a"},
        [], "__ 前缀字段按契约不进键", POS)

    # ================= 负例：语义不同 → 应分开 =================

    # --- 1. 时间：跨精度、跨月、缺年份 -----------------------------------
    add("时间-跨精度", "submit_batch_job",
        {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-08"},
        {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-08-15"},
        ["month"], "整月重算 vs 8月15日单日重算：计算范围不同")

    add("时间-缺年份", "query_region_stats",
        {"region": "冲绳海槽", "month": "2026-08"},
        {"region": "冲绳海槽", "month": "8月"},
        ["month"], "裸'8月'缺年份，不能等同于 2026 年 8 月")

    add("时间-跨年同月", "query_station_stats",
        {"station": "C22", "month": "2027-03"},
        {"station": "C22", "month": "2026-03"},
        ["month"], "同一个 3 月，跨了一年，是完全不同的时段")

    # --- 2. 空间：跨海区、同海不同分区、跨洋 ------------------------------
    add("空间-跨洋", "geocode_region",
        {"region": "冲绳海槽", "res": 7, "coverage": "all_intersecting"},
        {"region": "苏禄海", "res": 7, "coverage": "all_intersecting"},
        ["region"], "两个海区相隔上千公里，产物不可互换")

    add("空间-同海不同槽", "geocode_region",
        {"region": "南海北部", "res": 9, "coverage": "centroid_only"},
        {"region": "吕宋海峡", "res": 9, "coverage": "centroid_only"},
        ["region"], "吕宋海峡是南海与太平洋的水交换通道，与南海北部内陆架不是一回事")

    # --- 3. 字段：schema 声明字段逐项 -------------------------------------
    add("字段-正文版本", "send_email",
        {"to": "watch@marine.example", "subject": "S07 异常", "body_ref": "B-101"},
        {"to": "watch@marine.example", "subject": "S07 异常", "body_ref": "B-102"},
        ["body_ref"], "同主题不同正文版本：收件人看到的内容不同")

    add("字段-分辨率", "geocode_region",
        {"region": "冲绳海槽", "res": 5, "coverage": "all_intersecting"},
        {"region": "冲绳海槽", "res": 11, "coverage": "all_intersecting"},
        ["res"], "5 分与 11 分网格的落格结果不同")

    add("字段-覆盖", "geocode_region",
        {"region": "冲绳海槽", "res": 7, "coverage": "all_intersecting"},
        {"region": "冲绳海槽", "res": 7, "coverage": "touching_only"},
        ["coverage"], "是否覆盖所有相交格决定产物完整度")

    add("字段-资源", "submit_batch_job",
        {"job_name": "recompute_C22_2027-03", "station": "C22",
         "month": "2027-03", "cores": 16},
        {"job_name": "recompute_C22_2027-03", "station": "C22",
         "month": "2027-03", "cores": 128},
        ["cores"], "按契约保守视为不同请求：cores 改变资源配置与计费")

    add("字段-返回列", "query_station_stats",
        {"station": "K11", "month": "2027-11", "include_qc": False},
        {"station": "K11", "month": "2027-11", "include_qc": True},
        ["include_qc"], "是否含质检列改变返回结构")

    # --- 4. 文本：数字、日期、语序、否定、断言 ----------------------------
    add("文本-数字", "write_qc_note",
        {"station": "C22", "month": "2027-03", "note": "盐度偏差0.3"},
        {"station": "C22", "month": "2027-03", "note": "盐度偏差0.5"},
        ["note"], "偏差量不同，处置阈值不同")

    add("文本-日期", "write_qc_note",
        {"station": "K11", "month": "2027-11", "note": "11月7日复测通过"},
        {"station": "K11", "month": "2027-11", "note": "11月17日复测通过"},
        ["note"], "复测日期不同")

    add("文本-语序", "write_qc_note",
        {"station": "B04", "month": "2026-08", "note": "低盐度导致密度跃层上移"},
        {"station": "B04", "month": "2026-08", "note": "密度跃层上移导致低盐度"},
        ["note"], "因果方向相反：一个是成因，一个是结果")

    add("文本-否定", "write_qc_note",
        {"station": "B04", "month": "2026-08", "note": "传感器未漂移"},
        {"station": "B04", "month": "2026-08", "note": "传感器漂移"},
        ["note"], "一个否定一个肯定，结论完全相反")

    add("文本-断言", "write_qc_note",
        {"station": "S07", "month": "2027-03", "note": "温盐异常疑似"},
        {"station": "S07", "month": "2027-03", "note": "温盐异常确认"},
        ["note"], "'疑似'与'确认'触发不同处置流程与责任归属")

    # --- 5. 范围：作业名里的限定词 ---------------------------------------
    add("范围-只某站", "submit_batch_job",
        {"job_name": "recompute_C22_2027-03", "station": "C22", "month": "2027-03"},
        {"job_name": "recompute_C22_2027-03_C22only", "station": "C22",
         "month": "2027-03"},
        ["job_name"], "全站重算 vs 只重算 C22：作业范围不同")

    add("范围-排除", "submit_batch_job",
        {"job_name": "recompute_all_2027-03", "station": "C22", "month": "2027-03"},
        {"job_name": "recompute_all_2027-03_except_B04", "station": "C22",
         "month": "2027-03"},
        ["job_name"], "排除某站与不排除，覆盖的站点集合不同")

    # --- 6. 多字段同时不同（检验"一处差异即整体判不同"的漏判） -----------
    add("多字段-时间加空间", "geocode_region",
        {"region": "冲绳海槽", "res": 7, "coverage": "all_intersecting"},
        {"region": "苏禄海", "res": 9, "coverage": "centroid_only"},
        ["region", "res", "coverage"], "三处都不同，更不该合并")

    # --- 7. 原文等于内部标记（审阅方第二轮的探针）-----------------------
    add("边界-原文等于内部标记", "submit_batch_job",
        {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-08"},
        {"job_name": "\u27e6recompute|S07|2026-08\u27e7", "station": "S07",
         "month": "2026-08"},
        ["job_name"], "一个长得像内部标记的作业名，不能与真正的派生表示相撞")

    # --- 8. 多实体冲突（作业名里出现两个站号）---------------------------
    add("边界-作业名多站号", "submit_batch_job",
        {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-08"},
        {"job_name": "recompute_S07_S12_2026-08", "station": "S07", "month": "2026-08"},
        ["job_name"], "作业名里多了一个站号 S12，范围已经不同，不能按单站解释")

    return out


def freeze_record(rows: List[Decoy]) -> Dict[str, Any]:
    """
    冻结记录：内容哈希 + 条目计数 + 极性分布。

    哈希的对象是**规范化后**的条目序列（排序后逐条序列化），
    所以重排代码里的 add() 顺序不会改哈希，改内容才会。
    """
    items = []
    for d in rows:
        items.append({
            "kind": d.kind, "tool": d.src.tool,
            "a": json.dumps(d.src.slots, sort_keys=True, ensure_ascii=False),
            "b": json.dumps(d.decoy.slots, sort_keys=True, ensure_ascii=False),
            "changed": list(d.changed),
            "polarity": getattr(d, "polarity", NEG),
            "used_in_dev": bool(getattr(d, "used_in_dev", False)),
        })
    items.sort(key=lambda x: (x["kind"], x["a"], x["b"]))
    blob = json.dumps(items, ensure_ascii=False, sort_keys=True)
    h = hashlib.sha256(blob.encode("utf-8")).hexdigest()
    n_pos = sum(1 for x in items if x["polarity"] == POS)
    n_dev = sum(1 for x in items if x["used_in_dev"])
    return {"version": FREEZE_VERSION, "sha256": h, "n": len(items),
            "n_pos": n_pos, "n_neg": len(items) - n_pos,
            "n_used_in_dev": n_dev,
            "clean_n_pos": sum(1 for x in items
                               if x["polarity"] == POS and not x["used_in_dev"]),
            "clean_n_neg": sum(1 for x in items
                               if x["polarity"] == NEG and not x["used_in_dev"]),
            "kinds": sorted({x["kind"] for x in items})}


def holdout_metrics(rows: List[Decoy], keyof) -> Dict[str, Any]:
    """
    对给定策略，分别报告三个数（+ 一个补充数）。

    keyof(tool, slots) -> 键。用同一个函数算两侧的键，相等即"合并"。

      correct_merge    正例里被合并的比例 —— 越高越好
      wrong_merge      负例里被合并的比例 —— 越低越好（这是真正的风险）
      selective_reject 负例里被判"不同"的比例 —— 越高越好
      miss_merge       正例里未被合并的比例 —— 越低越好（代价是重复执行）

    ★ 为什么不能只报碰撞率：永不合并的策略 wrong_merge = 0、碰撞率也 = 0，
      看上去最安全；但它的 correct_merge 也是 0，一次都没合并成。
      三个数一起看才关得上这个漏洞。
    """
    def _m(sub: List[Decoy], prefix: str) -> Dict[str, Any]:
        pos = [d for d in sub if getattr(d, "polarity", NEG) == POS]
        neg = [d for d in sub if getattr(d, "polarity", NEG) == NEG]

        def merged(d: Decoy) -> bool:
            return keyof(d.src.tool, d.src.slots) == keyof(d.decoy.tool, d.decoy.slots)

        cm = sum(1 for d in pos if merged(d))
        wm = sum(1 for d in neg if merged(d))
        return {
            f"n_pos{prefix}": len(pos), f"n_neg{prefix}": len(neg),
            f"correct_merge{prefix}": cm,
            f"correct_merge_rate{prefix}": cm / len(pos) if pos else None,
            f"wrong_merge{prefix}": wm,
            f"wrong_merge_rate{prefix}": wm / len(neg) if neg else None,
            f"selective_reject{prefix}": len(neg) - wm,
            f"selective_reject_rate{prefix}": (len(neg) - wm) / len(neg) if neg else None,
            f"miss_merge{prefix}": len(pos) - cm,
            f"wrong_kinds{prefix}": [d.kind for d in neg if merged(d)],
            f"missed_kinds{prefix}": [d.kind for d in pos if not merged(d)],
        }

    out = _m(rows, "")
    # ★ 扣除"已用于开发"的条目后的干净子集：这才是泛化证据。
    clean = [d for d in rows if not getattr(d, "used_in_dev", False)]
    out.update(_m(clean, "_clean"))
    out["n_used_in_dev"] = len(rows) - len(clean)
    out["used_in_dev_kinds"] = [d.kind for d in rows if getattr(d, "used_in_dev", False)]
    out["n_pairs"] = len(rows)
    # 旧口径的"碰撞率"保留，方便与 v2 报告对照，但不作为结论依据
    out["collide_all"] = out["correct_merge"] + out["wrong_merge"]
    return out


def describe() -> str:
    rows = build_holdout()
    from collections import Counter
    c = Counter(d.kind for d in rows)
    n_pos = sum(1 for d in rows if getattr(d, "polarity", NEG) == POS)
    return (f"隐藏集 {len(rows)} 对（正例 {n_pos} / 负例 {len(rows) - n_pos}），"
            f"{len(c)} 类；覆盖工具 {len({d.src.tool for d in rows})} 个；"
            f"冻结版本 v{FREEZE_VERSION}")


if __name__ == "__main__":
    rows = build_holdout()
    print(describe())
    for d in rows:
        pol = getattr(d, "polarity", NEG)
        print(f"  [{pol}] [{d.kind:16s}] {d.src.tool:20s} 改 {d.changed}")
    print()
    print("冻结记录:", json.dumps(freeze_record(rows), ensure_ascii=False,
                                  indent=2))