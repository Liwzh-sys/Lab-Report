"""
contract.py — 语义契约：本项目唯一的"标准答案"来源。

为什么需要这个文件
------------------
第一版最大的问题不是"某个函数写错了"，而是**标准本身分散在三个地方**：

  · perturb.py 的 MonthSyn        声明 2026-08-01 是 2026-08 的保义写法
  · policy.py  的 MONTH_ALIAS     不折叠 2026-08-01（保留日精度）
  · universe.py 把 2026-08 与 2026-08-15 当变义诱饵

于是同一个输入关系在不同位置被同时标成"保义"和"变义"。
审阅方指出这一点时说得很准确：难处理不是问题，标准不一致才是。

本文件把契约收敛成**一处声明**，生成侧（perturb）与判定侧（policy/structured）
都从这里读，不再各自维护一份。contract_check.py 负责验证两侧真的一致。

时间语义契约（二选一的结论）
----------------------------
采纳：**日精度代表不同的逻辑操作。**

理由：这类工具（重算某站某时段、写质检备注）的时间粒度直接决定计算范围，
"8 月整月重算"与"8 月 15 日单日重算"是两次不同的作业，成本与产物都不同。
把它俩判成同一次，等于让一次整月重算被一次单日重算"抑制"掉——正是本报告
要防的那类错合并。

因此：
  · 2026-08-01 与 2026-08 **不是**保义关系（前者日精度，后者月精度）
  · 月精度的等价写法只在"月精度"内部闭合：2026-08 ≡ 2026年8月 ≡ 202608 ≡ Aug 2026
  · 裸"8月"缺年份，**不得**无条件等同 2026-08，只能落到歧义标记 ??-08

字段/类型/别名契约
------------------
见下文各表。核心纪律是**白名单**：
  · 只有 FIELD_CONTRACT 里声明的字段才允许进键；
  · 只有 TYPE_COERCIBLE 里列出的字段才允许做 字符串→数值/布尔 转换；
  · 只有 ALIAS_FIELDS 里列出的字段才允许套词表别名。
不在名单上的一律原样保留——**沉默不是许可**。
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set, Tuple

from universe import TOOLS


# --------------------------------------------------------------------------
# 一、时间语义契约
# --------------------------------------------------------------------------

# 月精度等价类。**只允许同精度互转**，任何跨精度的映射都是违规。
MONTH_EQUIV: Dict[str, tuple] = {
    "2026-08": ("2026年8月", "2026/08", "202608", "Aug 2026", "aug 2026", "08-2026"),
    "2026-09": ("2026年9月", "2026/09", "202609", "Sep 2026", "sep 2026", "09-2026"),
    "2026-10": ("2026年10月", "2026/10", "202610", "Oct 2026", "oct 2026", "10-2026"),
    "2026-11": ("2026年11月", "2026/11", "202611", "Nov 2026", "nov 2026", "11-2026"),
    "2026-12": ("2026年12月", "2026/12", "202612", "Dec 2026", "dec 2026", "12-2026"),
}

# 裸月份（无年份）→ 歧义标记。刻意**不**映射到具体年份。
AMBIGUOUS_MONTH = "??-{}"

PRECISION_MONTH = "month"
PRECISION_DAY = "day"
PRECISION_UNKNOWN_YEAR = "unknown_year"


def _akey(s: str) -> str:
    """别名表的查表键：去空白 + 小写。'Aug 2026' 与 'aug2026' 视作同一写法。"""
    return re.sub(r"\s+", "", s).lower()


def build_month_alias() -> Dict[str, str]:
    """由契约生成别名表，供归一化侧使用。"""
    alias: Dict[str, str] = {}
    for canon, alts in MONTH_EQUIV.items():
        alias[_akey(canon)] = canon
        for a in alts:
            alias[_akey(a)] = canon
    return alias


MONTH_ALIAS = build_month_alias()


def norm_month(v: Any) -> Any:
    """
    月份归一。**只统一书写形式，绝不改变精度。**

      2026-08 / 2026年8月 / 202608 / Aug 2026 → 2026-08    （月精度闭合）
      2026-08-01 / 2026/8/1                   → 2026-08-01 （日精度，保留）
      8月                                     → ??-08      （缺年份，不猜）
    """
    if not isinstance(v, str):
        return v
    s = v.strip()
    if _akey(s) in MONTH_ALIAS:
        return MONTH_ALIAS[_akey(s)]

    t = re.sub(r"\s+", "", s)

    # 带日：保留到日
    m = re.fullmatch(r"(\d{4})[-/年.]?(\d{1,2})[-/月.](\d{1,2})日?", t)
    if m:
        return f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"

    # 只到月
    m = re.fullmatch(r"(\d{4})[-/年.]?(\d{1,2})月?", t)
    if m:
        return f"{int(m.group(1)):04d}-{int(m.group(2)):02d}"

    # 缺年份：标歧义，绝不猜
    m = re.fullmatch(r"(\d{1,2})月?", t)
    if m:
        return AMBIGUOUS_MONTH.format(f"{int(m.group(1)):02d}")

    return t


def precision_of(v: Any) -> Optional[str]:
    """返回该月份值的精度。用于契约自检与跨精度合并的告警。"""
    if not isinstance(v, str):
        return None
    s = v.strip()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return PRECISION_DAY
    if re.fullmatch(r"\d{4}-\d{2}", s):
        return PRECISION_MONTH
    if re.fullmatch(r"\?\?-\d{2}", s):
        return PRECISION_UNKNOWN_YEAR
    return None


# --------------------------------------------------------------------------
# 二、词表契约：区域名 / 站号的别名（人工审定，不由算法推断）
# --------------------------------------------------------------------------

REGION_ALIAS: Dict[str, str] = {
    "南海北部": "南海北部", "南海北部海区": "南海北部", "南海北部区域": "南海北部",
    "南海北部海域": "南海北部", "northern south china sea": "南海北部",
    "scs-n": "南海北部",
    "南海中部": "南海中部", "南海中部海区": "南海中部", "南海中部区域": "南海中部",
    "central south china sea": "南海中部", "scs-c": "南海中部",
    "东海陆架": "东海陆架", "东海陆架区": "东海陆架", "东海大陆架": "东海陆架",
    "east china sea shelf": "东海陆架", "ecs-shelf": "东海陆架",
    "白令海": "白令海", "白令海海域": "白令海", "bering sea": "白令海",
    "马六甲海峡": "马六甲海峡", "马六甲": "马六甲海峡",
    "strait of malacca": "马六甲海峡",
}

STATION_ALIAS: Dict[str, str] = {
    "s07": "S07", "s-07": "S07", "站s07": "S07", "s07站": "S07",
    "s12": "S12", "s-12": "S12", "站s12": "S12", "s12站": "S12",
    "s31": "S31", "s-31": "S31", "站s31": "S31", "s31站": "S31",
    "b04": "B04", "b-04": "B04", "站b04": "B04", "b04站": "B04",
}

_ALL_ALIAS: Dict[str, str] = {}
for _d in (REGION_ALIAS, STATION_ALIAS, MONTH_ALIAS):
    for _k, _v in _d.items():
        _ALL_ALIAS[_akey(_k)] = _v
del _d, _k, _v

# 按 _akey 索引的查表副本：原文键里含空格（'northern south china sea'），
# 而查表时输入已被去空格，必须用同一套键才能命中。
_REGION_AK: Dict[str, str] = {_akey(k): v for k, v in REGION_ALIAS.items()}
_STATION_AK: Dict[str, str] = {_akey(k): v for k, v in STATION_ALIAS.items()}


def norm_region(v: Any, allow_alias: bool = True) -> Any:
    if not isinstance(v, str):
        return v
    s = re.sub(r"\s+", " ", v.strip())
    if allow_alias:
        hit = _REGION_AK.get(_akey(s))
        if hit is not None:
            return hit
    return s


_STATION_CANON = re.compile(r"^([SB])-?(\d{2})$", re.I)
# 站号前缀可以是任意字母（C/K/B/S…），不能只认 S 与 B。
_STATION_CANON2 = re.compile(r"^([A-Za-z])-?(\d{1,2})$")


def norm_station(v: Any, allow_alias: bool = True) -> Any:
    """站号归一。只对站号字段调用——绝不套到邮件主题上。"""
    if not isinstance(v, str):
        return v
    s = re.sub(r"\s+", " ", v.strip())
    if allow_alias:
        hit = _STATION_AK.get(_akey(s))
        if hit is not None:
            return hit
    # 无别名的写法：'S-7' → 'S07'、'c-22' → 'C22'
    # （仅大小写与分隔符，不改变字母数字本身）
    #
    # ★ 第三轮修正：原来的字符类写成 [SB]，只覆盖 S 与 B 两个字母。
    #   隐藏集里 C22 / K11 是主集没有的站号，于是 'C22' 与 'c-22'
    #   被判为不同站——这不是"保守"，是**归一则声明与实现不一致**：
    #   契约写的是"大小写与分隔符不影响站号"，实现却按字母白名单。
    #   现在放宽到任意字母，仍然只抹大小写与连字符，不碰数字。
    m = _STATION_CANON2.match(s)
    if m:
        return f"{m.group(1).upper()}{int(m.group(2)):02d}"
    return s


# --------------------------------------------------------------------------
# 三、字段语义契约：哪些字段参与键，为什么
# --------------------------------------------------------------------------

FIELD_CONTRACT: Dict[str, Dict[str, Any]] = {
    "query_region_stats": {
        "key_fields": ["region", "month", "include_flag_dist"],
        "why": "查区域统计：区域+月份定位数据切片；是否附带标志分布改变返回列，属不同查询。",
    },
    "query_station_stats": {
        "key_fields": ["station", "month", "include_qc"],
        "why": "查站点统计：站点+月份定位切片；是否含质检列改变返回结构。",
    },
    "geocode_region": {
        "key_fields": ["region", "res", "coverage"],
        "why": "落格：分辨率 res 决定网格，coverage 决定落在哪些格，二者不同则产物不同。",
    },
    "submit_batch_job": {
        "key_fields": ["job_name", "station", "month", "cores"],
        "why": "批作业：作业名+站点+月份定位计算；cores 改变资源配置与计费，保守进键。",
    },
    "write_qc_note": {
        "key_fields": ["station", "month", "note"],
        "why": "写质检备注：站点+月份定位记录；note 是正文，必须逐字参与（不得删数字）。",
    },
    "send_email": {
        "key_fields": ["to", "subject", "body_ref"],
        "why": "发邮件：收件人+主题+正文引用；body_ref 不同即不同通知内容。",
    },
}

# 明确**不**参与键的字段，以及理由（空表也要显式声明"没有可忽略字段"）
IGNORABLE_FIELDS: Dict[str, Dict[str, str]] = {t: {} for t in FIELD_CONTRACT}

# ★ 第三轮追加：TOOLS（规范 schema）与 FIELD_CONTRACT（派生视图）的关系必须写明。
# 审阅方说"工具字段在 universe.TOOLS 和 FIELD_CONTRACT 两处各描述一遍"——
# 这个结构可以留，但不能让两处各自成为一份真相源。
# 规范：universe.TOOLS 是**规范**（required/optional 是这个工具的接口事实）；
#       FIELD_CONTRACT 是**派生视图**（哪些字段进键，以及为什么）。
# 下面这条断言把"派生视图不许凭空造字段"变成可执行检查，
# 由 contract_check.py 一并跑；这里 import 时先自检一次，early fail。
FIELD_VIEW_IS_DERIVED = True


def _check_field_view_derived() -> List[str]:
    """派生视图里出现的字段，必须是 TOOLS 声明过的字段。"""
    bad = []
    for tool, spec in FIELD_CONTRACT.items():
        declared = set(TOOLS[tool]["required"]) | set(TOOLS[tool]["optional"])
        for f in spec["key_fields"]:
            if f not in declared:
                bad.append(f"{tool}.{f} 不在 TOOLS 的 required/optional 里")
    return bad


# --------------------------------------------------------------------------
# 三之二、备注同义词：从生成器搬回契约（审阅方第七节（一））
# --------------------------------------------------------------------------
# 第二版把 NoteSyn 单独声明在 perturb.py 里，于是"标准只剩一处"这句话不成立：
# 生成器用一份自己的同义词表去造"保义改写"，而契约并不知道这件事。
# 现在它是契约的一部分：既被生成器读，也被下面 equiv_alternatives() 读。
NOTE_EQUIV: Dict[str, Tuple[str, ...]] = {
    "疑似": ("可能存在", "疑为", "疑似出现", "suspected"),
}

# 命名空间：工具名必须参与键。缺了它，两个不同工具的参数相同就会撞。
KEY_NAMESPACE_SEP = "|"


def key_fields(tool: str) -> list:
    return FIELD_CONTRACT[tool]["key_fields"]


def is_ignorable(tool: str, field_name: str) -> bool:
    return field_name in IGNORABLE_FIELDS.get(tool, {})


def default_of(tool: str, field_name: str) -> Any:
    """schema 声明的默认值。'未写' 与 '显式写出默认值' 必须等价。"""
    opt = TOOLS[tool]["optional"]
    return opt.get(field_name, None)


def field_kind(tool: str, field_name: str) -> str:
    """
    字段的归一化类别：
      month / station / region / bool / int / text
    依据 schema 默认值的类型 + 契约白名单判定，而不是"看当前值的类型"。
    """
    d = default_of(tool, field_name)
    if field_name == "month" or field_name.endswith("_month"):
        return "month"
    if field_name == "station":
        return "station"
    if field_name == "region":
        return "region"
    if isinstance(d, bool):
        return "bool"
    if isinstance(d, int) and not isinstance(d, bool):
        return "int"
    return "text"


# --------------------------------------------------------------------------
# 四、类型转换契约：只有经过验证的转换才算保义
# --------------------------------------------------------------------------

# 哪些字段允许做"字符串→数值/布尔"的归一。字段不在名单里就不许转。
# 审阅方的两个反例（备注 "01" vs "1.0"、邮件主题 "S07" vs "S-07"）
# 正好是"把数值/别名规则套到文本字段上"造成的，所以这里按字段白名单。
TYPE_COERCIBLE: Dict[str, Set[str]] = {
    "query_region_stats": {"include_flag_dist"},
    "query_station_stats": {"include_qc"},
    "geocode_region": {"res"},
    "submit_batch_job": {"cores"},
    "write_qc_note": set(),      # note 是正文，永不转
    "send_email": set(),         # to/subject/body_ref 都是文本，永不转
}

# 别名只对"枚举型标识字段"生效，不对自由文本生效
ALIAS_FIELDS: Dict[str, Set[str]] = {
    "query_region_stats": {"region"},
    "query_station_stats": {"station"},
    "geocode_region": {"region"},
    "submit_batch_job": {"station"},
    "write_qc_note": {"station"},
    "send_email": set(),         # 邮件主题不是站号，永不套站号别名
}


def may_coerce(tool: str, field_name: str) -> bool:
    return field_name in TYPE_COERCIBLE.get(tool, set())


def may_alias(tool: str, field_name: str) -> bool:
    return field_name in ALIAS_FIELDS.get(tool, set())


# --------------------------------------------------------------------------
# 四之二、空白契约：换行能不能折叠，由字段用途决定
# --------------------------------------------------------------------------
# 审阅方的空白保真探针：
#     a: "第一行\n第二行"   b: "第一行 第二行"   → 第二版同键
#
# 而字段契约又写着"note 正文必须逐字参与"。这两句话不能同时成立。
#
# 第二版的根因是 policy._clean_text() 对所有 text 字段无条件做
#     re.sub(r"\s+", " ", v.strip())
# 注释里还写着"这两步对任何文本字段都保义"。这个断言是错的：
#   · 对**机器生成的结构化标识**（job_name、body_ref、subject），
#     首尾空白与连续空白确实是噪声，折叠保义；
#   · 对**人写的正文**（note），换行是排版信息本身。
#     "第一行\n第二行" 与 "第一行 第二行" 是两段不同的文字。
#     Git commit message、邮件正文、工单描述都属这一类。
#
# 所以按字段声明，而不是按类型一刀切。默认值是"逐字保留"——
# 沉默不是许可：没声明的字段不允许折叠。

# 允许"折叠空白"（去首尾 + \s+ → 单空格）的字段。
# 这些字段的值由程序拼装，空白不承载语义。
WHITESPACE_FOLDABLE: Dict[str, Set[str]] = {
    "query_region_stats": set(),
    "query_station_stats": set(),
    "geocode_region": set(),
    "submit_batch_job": {"job_name"},   # 作业名是拼出来的标识符
    "write_qc_note": set(),             # note 是人写的正文，逐字保留
    "send_email": {"to", "subject", "body_ref"},  # 地址/主题/引用是标识符
}


def may_fold_whitespace(tool: str, field_name: str) -> bool:
    """
    该字段的空白是否允许折叠。**默认 False**（逐字保留）。
    """
    return field_name in WHITESPACE_FOLDABLE.get(tool, set())


# --------------------------------------------------------------------------
# 四之三、未知字段的处理方式：必须显式定义，不能"默默丢掉"
# --------------------------------------------------------------------------
# 审阅方指出：报告写"名单外全部原样保留"，而 safe_schema_project() 干的是
# "只取声明字段、未知字段直接丢掉"，IGNORABLE_FIELDS 又全空。三者不一致。
#
# 这是真实的三种可选语义，必须挑一个并声明：
#   reject  —— 出现未知字段就报错（最严，适合外部不可信输入）
#   ignore  —— 显式忽略，但要有名单与理由（适合已知的追踪字段）
#   keep    —— 未知字段也进键（最保守，但键会随无关字段抖动）
#
# 本项目选 reject：工具 schema 是封闭契约，多出来的字段说明调用方对接口的
# 理解与实现不一致，这是需要人看的事件，不该由键悄悄吸收。
UNKNOWN_FIELD_POLICY = "reject"


class UnknownFieldError(ValueError):
    """工具收到了 schema 未声明的字段。"""


def check_unknown_fields(tool: str, args: Dict[str, Any]) -> None:
    """
    按 UNKNOWN_FIELD_POLICY 处理未知字段。

    豁免：以 `__` 开头的字段是调用链内部追踪用的（`__trace` / `__note`），
    在进入键之前就该被 safe_drop_noise() 剥掉，所以这里不算未知。
    """
    if UNKNOWN_FIELD_POLICY == "keep":
        return
    known = set(TOOLS[tool]["optional"]) | set(key_fields(tool))
    unknown = [k for k in args
               if k not in known and not k.startswith("__")]
    if not unknown:
        return
    if UNKNOWN_FIELD_POLICY == "reject":
        raise UnknownFieldError(
            f"{tool} 收到未声明字段：{sorted(unknown)}；"
            f"已声明字段为 {sorted(known)}")
    # ignore：只忽略显式登记过的
    bad = [k for k in unknown if not is_ignorable(tool, k)]
    if bad:
        raise UnknownFieldError(f"{tool} 收到不可忽略的未声明字段：{sorted(bad)}")


# --------------------------------------------------------------------------
# 五、冗余契约：哪些自由文本字段可以被"结构化替代"，以及必须满足的守卫
# --------------------------------------------------------------------------
# 上一版把"自由文本不进键"当成原则，后果是 job_name 里 `_partial` 这种
# 真实差别被直接丢弃。正确做法不是"全丢"也不是"全留"，而是**带守卫的替代**。
#
# ★ 第三轮修正：守卫的判据从"残余为空"改成"逐段可核对"
# ------------------------------------------------------
# 第二版的守卫逻辑是：
#     search() 抽出**第一个**站号、**第一个**月份、**一个**动作词
#     然后 residual_of() **全局删除**所有站号、所有月份、所有动作词、所有区域别名
#     最后看"残余是否为空" → 空就认为"全部内容都被正确解释了"
#
# 这个推断不成立。残余为空只说明"我把能匹配的都删干净了"，
# 不等于"我验证过的那些就是全部"。审阅方六组探针全部同键，因为它：
#   · 额外站号 S12   —— 检查了 S07，然后 S07 和 S12 一起被删
#   · 额外月份 09    —— 检查了第一个月，然后两个月一起被删
#   · 额外动作 query —— 挑中 recompute，残余阶段连 query 一起删
#   · 额外区域       —— 南海北部既不在该字段的派生槽位集合里，也没参与一致性检查
#   · 原文 == 内部标记 —— 用户输入恰好是 ⟦recompute|S07|2026-08⟧ 就直接撞上
#   · 空白差异       —— 分隔符被抹平，但这是文本字段，折叠与否该由用途决定
#
# 现在的做法：
#   1. collect_spans() 用 finditer 收集**全部**匹配，连同字符范围；
#   2. 对每个片段逐条判定：它能对应上一个**已验证**的语义项吗？
#         - 实体值必须等于已声明槽位值（不等 → 冲突 → 拒绝替代）
#         - 同一类实体出现多次（重复 → 拒绝替代）
#         - 多出一个未经声明的实体（额外 → 拒绝替代）
#         - 动作词出现多个且不一致（冲突 → 拒绝替代）
#         - 区域别名不属本字段派生槽位（额外 → 拒绝替代）
#   3. 所有覆盖区间必须能拼成完整的原文（无遗漏片段、无重叠），
#      剩下的分隔符只能是**显式声明为可折叠**的那几种；
#   4. 任一条不满足 → 返回 None，原样保留。
#
# 一句话：**"残余为空"不是"全部已解释"的判据。** 这两个命题的差别是
# "我删干净了"和"我逐项核对过了"，前者对错误完全不可见。

DERIVED_FROM: Dict[Tuple[str, str], Tuple[str, ...]] = {
    # (工具, 字段) → 该字段的内容应当能由这些槽位解释
    ("submit_batch_job", "job_name"): ("action", "station", "month"),
}

# 派生槽位：由字段自身内容解释，不对应任何声明字段，
# 因此**不参与** "found 必须与 declared 一致" 这条守卫。
DERIVED_SLOTS = {"action"}

# 动作词表：只用于"解释" job_name，不用于改写任何进键值
ACTION_VOCAB = {
    "recompute": "recompute", "recalc": "recompute", "重算": "recompute",
    "rerun": "recompute", "redo": "recompute", "重新计算": "recompute",
    "query": "query", "查询": "query", "查": "query", "get": "query",
    "write": "write", "写入": "write", "写": "write",
    "send": "send", "发送": "send", "发": "send",
    "geocode": "geocode", "落格": "geocode",
}

# 站号：刻意不用 \b —— 下划线在正则里属"词字符"，job_name 里站号几乎总被
# 下划线包着（recompute_S07_2026-08），\b 在那里不成立。
# ★ 第三轮修正：前缀字母从 [sbSB] 放宽到任意字母。
#   原写法只认 S 与 B（主集只有这四个站），于是 job_name 里的 C22 / K11
#   认不出来，'RECOMPUTE-C22-202703' 与 'recompute_C22_2027-03' 因此被判不同。
#   这不是"保守"，是站号词表与主集取值耦合——隐藏集一碰就露。
STATION_PAT = re.compile(r"(?<![A-Za-z0-9])([A-Za-z]-?\d{1,2})(?![0-9])")

# 月份：带年（含 202608 与 2026-08-15）优先，其次裸月
MONTH_PAT_FULL = re.compile(r"(?<!\d)(\d{4})[-_/年.]?(\d{1,2})(?:[-_/月.](\d{1,2})日?)?(?!\d)")
MONTH_PAT_BARE = re.compile(r"(?<!\d)(\d{1,2})月")
MONTH_PAT_COMPACT = re.compile(r"(?<!\d)(\d{4})(\d{2})(?!\d)")

# 分隔符集合：只有这些字符允许"不作为语义内容"，且必须是字段声明过的分隔符。
# 换行 \n 与制表 \t **不在此列** —— 它们是文本内容的一部分，折叠与否由字段用途
# 决定，不能默认抹平。（这就是审阅方那条空白探针。）
DERIVED_SEPARATORS = re.compile(r"[_\-/|,;:·.\s]+")


# --------------------------------------------------------------------------
# 带类型的内部表示：把"用户原文"和"内部派生标记"物理隔开
# --------------------------------------------------------------------------
# 为什么需要类型而不是特殊符号：
#   第二版用 ⟦recompute|S07|2026-08⟧ 这种字符串做内部标记，指望"特殊括号
#   不会出现在用户输入里"。审阅方直接把这个字面量当 job_name 传进来，不经过
#   任何替代过程就和内部表示撞上了。**不能指望特殊符号不出现在用户输入里。**
#
# 现在内部表示是一个带 kind 标签的结构，序列化时加上不可混淆的类型前缀；
# 原始文本一律走 "raw" 分支，两边在字符串空间上不可能撞。

@dataclass(frozen=True)
class DerivedValue:
    """由槽位解释出来的结构化值。kind 固定为 "derived"。"""
    action: str
    station: str
    month: str
    kind: str = "derived"

    def to_key_repr(self) -> Dict[str, str]:
        # 键里存的是**带类型标签的对象**，不是裸字符串。
        # 用户即使输入 "derived|recompute|S07|2026-08"，它也会走 RawValue 分支，
        # 两者在 JSON 结构上不可能相等（一个是 dict，一个是带 kind=raw 的 dict）。
        return {"kind": "derived",
                "value": f"{self.action}|{self.station}|{self.month}"}


@dataclass(frozen=True)
class RawValue:
    """原样保留的文本。kind 固定为 "raw"。"""
    text: str
    kind: str = "raw"

    def to_key_repr(self) -> Dict[str, str]:
        return {"kind": "raw", "value": self.text}


def _span_key(kind: str, value: str) -> str:
    return f"{kind}:{value}"


# --------------------------------------------------------------------------
# 收集全部匹配（不是第一个）
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class Span:
    """一个被识别出来的实体片段及其在原文中的字符范围。"""
    kind: str          # station / month / action / region
    raw: str           # 原文片段
    start: int
    end: int
    norm: Optional[str]  # 归一后的值（region 为 None，只用于"是否被删"核对）


def collect_spans(value: str) -> List[Span]:
    """
    收集 value 里**全部**实体片段，带上字符范围。

    与第二版 search() 的区别：这里不做"第一个就够了"的假设。
    finditer 会把每一个站号、每一个月份都找到，重复的也留着，
    留给调用方去判定"重复算不算合法"。
    """
    spans: List[Span] = []

    for m in STATION_PAT.finditer(value):
        spans.append(Span("station", m.group(0), m.start(), m.end(),
                          norm_station(m.group(1), allow_alias=True)))

    # 月份：三种写法分开扫，但要注意 FULL 会覆盖 COMPACT（202608 两种都能匹配）。
    # 这里先扫 FULL，再扫 COMPACT 时跳过已被 FULL 覆盖的区间，避免同一段文字
    # 被当成两个实体（那会误判成"重复实体"）。
    taken: List[Tuple[int, int]] = []
    for m in MONTH_PAT_FULL.finditer(value):
        spans.append(Span("month", m.group(0), m.start(), m.end(),
                          norm_month(m.group(0))))
        taken.append((m.start(), m.end()))
    for m in MONTH_PAT_COMPACT.finditer(value):
        if any(s <= m.start() and m.end() <= e for s, e in taken):
            continue
        spans.append(Span("month", m.group(0), m.start(), m.end(),
                          norm_month(m.group(0))))
        taken.append((m.start(), m.end()))
    for m in MONTH_PAT_BARE.finditer(value):
        if any(s <= m.start() and m.end() <= e for s, e in taken):
            continue
        spans.append(Span("month", m.group(0), m.start(), m.end(),
                          norm_month(m.group(0))))

    # 动作词与区域别名：用位置扫描而不是替换，这样才能知道"删了几个"
    low = value.lower()
    for w, canon in sorted(ACTION_VOCAB.items(), key=lambda kv: -len(kv[0])):
        start = 0
        while True:
            i = low.find(w, start)
            if i < 0:
                break
            # 已被更长的动作词覆盖则跳过（避免 "recompute" 里再匹配出 "compute"）
            if not any(s.start <= i and i + len(w) <= s.end for s in spans):
                spans.append(Span("action", value[i:i + len(w)], i, i + len(w), canon))
            start = i + len(w)

    for alias in sorted(REGION_ALIAS, key=len, reverse=True):
        start = 0
        al = alias.lower()
        while True:
            i = low.find(al, start)
            if i < 0:
                break
            if not any(s.start <= i and i + len(al) <= s.end for s in spans):
                spans.append(Span("region", value[i:i + len(alias)], i, i + len(al), None))
            start = i + len(al)

    spans.sort(key=lambda s: (s.start, -(s.end - s.start)))
    return spans


def residual_of(tool: str, field_name: str, value: str) -> str:
    """
    把 value 里"能被已声明槽位解释"的部分抹掉，返回剩下的残余。

    ⚠️ 这个函数**不再用于守卫判定**（第三轮起）。它保留下来只作诊断输出，
    让人能看到"被抹掉之后还剩什么"。守卫判定用 explain_field()，
    因为"残余为空"证明不了"全部已解释"。

    纪律（第一版在这里犯的错）：
      · **不得** `re.sub(r"\\d", " ", r)` —— 那会把 '偏差1度' 与 '偏差2度'
        抹成同一个东西。数字是最常见的真实差异载体。
      · 不排序、不去重、不大小写归一 —— 残余要保留语序，'甲影响乙' ≠ '乙影响甲'。
    """
    s = value
    s = STATION_PAT.sub(" ", s)
    s = MONTH_PAT_FULL.sub(" ", s)
    s = MONTH_PAT_COMPACT.sub(" ", s)
    s = MONTH_PAT_BARE.sub(" ", s)
    low = s.lower()
    for w in sorted(ACTION_VOCAB, key=len, reverse=True):
        low = low.replace(w, " ")
    for w in sorted(REGION_ALIAS, key=len, reverse=True):
        low = low.replace(w.lower(), " ")
    # 只抹分隔符与空白；**其余一律保留，含数字**
    low = re.sub(r"[\s_\-/|,;:·.]+", " ", low).strip()
    return low


# --------------------------------------------------------------------------
# 守卫：逐段可核对
# --------------------------------------------------------------------------

@dataclass
class ExplainResult:
    """
    一次"字段能否被槽位完全解释"的判定结果。

    ok           : 是否允许替代（False → 原样保留）
    derived      : ok 时的结构化值
    reason       : 不通过的原因（可核验的字符串，进断言与报告）
    spans        : 识别到的全部片段
    unexplained  : 未被任何片段覆盖的原文片段（应只剩分隔符）
    """
    ok: bool
    derived: Optional[DerivedValue]
    reason: str
    spans: List[Span]
    unexplained: List[str]


def explain_field(tool: str, field_name: str, value: Any,
                  declared: Dict[str, Any]) -> ExplainResult:
    """
    判定 value 能否被 declared 里的槽位**逐段**解释。

    通过条件（全部满足，缺一即拒）：
      1. 该字段在 DERIVED_FROM 里声明过；
      2. 每个被需要的槽位都能在原文里找到（不漏）；
      3. **每一类实体最多出现一次**（重复 → 拒，因为无法确定谁是谁）；
      4. 每个实体都与已声明槽位**一致**（冲突 → 拒）；
      5. 原文里**不存在**该字段派生槽位之外的实体（额外 → 拒）；
      6. 所有片段覆盖之后，剩下的只能是声明过的分隔符（有内容片段 → 拒）；
      7. 原文里不出现内部标记字面量（防"用户输入恰好撞上内部表示"）。
    """
    want = DERIVED_FROM.get((tool, field_name))
    if want is None or not isinstance(value, str):
        return ExplainResult(False, None, "字段未声明为可派生", [], [])

    # 条件 7：先排除"用户原文就等于内部标记"这种输入。
    # 带类型封装后即使不排也不会撞，但显式拒绝更清楚：
    # 一个长得像内部标记的作业名，本来就不该被当成可解释的。
    if "\u27e6" in value or "\u27e7" in value:
        return ExplainResult(False, None, "原文含内部标记字符，拒绝替代", [], [value])

    spans = collect_spans(value)

    # 条件 5：本字段只允许出现 want 里声明的实体类型
    allowed_kinds = set()
    for k in want:
        allowed_kinds.add("action" if k == "action" else k)
    extra = [s for s in spans if s.kind not in allowed_kinds]
    if extra:
        return ExplainResult(
            False, None,
            "存在未声明实体：" + "、".join(f"{s.kind}={s.raw}" for s in extra),
            spans, [])

    by_kind: Dict[str, List[Span]] = {}
    for s in spans:
        by_kind.setdefault(s.kind, []).append(s)

    # 条件 3：每类最多一个（重复实体无法区分谁是"那一个"）
    for k, ss in by_kind.items():
        if len(ss) > 1:
            vals = "、".join(s.raw for s in ss)
            return ExplainResult(False, None, f"{k} 出现 {len(ss)} 次：{vals}",
                                 spans, [])

    # 条件 4：实体值必须与已声明槽位一致
    found: Dict[str, str] = {}
    for k, ss in by_kind.items():
        s = ss[0]
        found[k] = s.norm if s.norm is not None else s.raw
        if k in DERIVED_SLOTS:
            continue
        dv = declared.get(k)
        if dv is None:
            return ExplainResult(False, None, f"声明槽位缺少 {k}", spans, [])
        if found[k] != dv:
            return ExplainResult(
                False, None,
                f"{k} 与声明槽位冲突：原文 {found[k]!r} ≠ 声明 {dv!r}",
                spans, [])

    # 条件 2：需要的槽位一个都不能少
    for k in want:
        if k not in found:
            return ExplainResult(False, None, f"缺少槽位 {k}", spans, [])

    # 条件 6：覆盖率检查 —— 所有片段 + 允许的分隔符必须拼满整串。
    # 这是"逐段可核对"的核心：不是"抹完看剩什么"，而是"每一段都有归属"。
    cursor = 0
    leftover: List[str] = []
    for s in sorted(spans, key=lambda x: x.start):
        gap = value[cursor:s.start]
        if gap and not DERIVED_SEPARATORS.fullmatch(gap):
            leftover.append(gap)
        cursor = max(cursor, s.end)
    tail = value[cursor:]
    if tail and not DERIVED_SEPARATORS.fullmatch(tail):
        leftover.append(tail)
    if leftover:
        return ExplainResult(
            False, None,
            "存在无法解释的片段：" + "、".join(repr(x) for x in leftover),
            spans, leftover)

    return ExplainResult(
        True,
        DerivedValue(action=found["action"], station=found["station"],
                     month=found["month"]),
        "", spans, [])


def canon_derived(tool: str, field_name: str, value: Any,
                  declared: Dict[str, Any]) -> Optional[Any]:
    """
    带守卫的结构化替代。返回 None 表示"守卫不通过，必须原样保留"。

    ★ 返回类型在第三轮变了：原来是 str（⟦...⟧ 字面量），现在是 DerivedValue。
      这样内部表示和用户原文在**类型层面**就分开了，不靠"特殊符号不会出现"。
    """
    r = explain_field(tool, field_name, value, declared)
    return r.derived if r.ok else None


def canon_dict(tool: str, field_name: str, value: Any,
               declared: Dict[str, Any]) -> Dict[str, str]:
    """
    把字段值转成进键用的表示：要么 {"kind":"derived",...}，要么 {"kind":"raw",...}。

    这是 structured.extract_slots() 唯一应该调用的入口——
    返回的永远是 dict，不是裸字符串，所以两条路径不可能在 JSON 上相等。
    """
    r = explain_field(tool, field_name, value, declared)
    if r.ok and r.derived is not None:
        return r.derived.to_key_repr()
    return RawValue("" if value is None else str(value)).to_key_repr()


# --------------------------------------------------------------------------
# 七、成本模型：把两块代价映射到同一个效用尺度（★ 第三轮新增）
# --------------------------------------------------------------------------
# 审阅方第六节（二）指出：报告写"两块代价量纲不同，不能相加"，
# 而 total_cost = dup_cost + miss_cost，E3 优化与 E7 净效应也都在加。
# 文档说不能加、代码在加 —— 这两句必须统一。
#
# 只有两条出路，不能两头都要：
#   出路 A：给出**可加成本模型**及其假设，并按出现率加权；
#   出路 B：只做二维比较（(dup, miss) 平面上的帕累托前沿），
#           不宣称任何"总分最优"。
#
# 本项目的选择：**A 为主，B 为校验**。
#   · 主结果用 A（可加模型），因为它能回答"在什么出现率下该开几条规则"；
#   · 同时给出 B 的帕累托前沿，用来检查 A 的最优点是否落在前沿上。
#     如果 A 的最优点不在前沿上，说明成本参数本身有问题。
#
# A 的假设（每一条都必须能被质疑，所以逐条写出来）：
#   A1 两块代价折算到同一效用单位：**人工处置一次的等效工时**。
#      1.0 = 值班员处理一次异常工单的等效成本。
#   A2 c_dup 与 c_miss 都是这个单位下的常数，不随并发量变化（无规模效应）。
#   A3 两类事件的出现率独立给定：p_retry（同一操作被拆开的概率）、
#      p_conflict（真正撞上语义冲突的概率）。二者都是**外部参数**，
#      不由本实验的数据决定。
#   A4 期望损失对事件数线性：E[L] = N · Σ_k p_k · c_k。这要求 N 固定，
#      且单次事件之间不相互作用（没有级联失败）。
#   A5 单位换算表是**假设**，不是测量结果。它来自课程第7讲的权限分级
#      （只读 / 写隔离区 / 写正式 / 对外发送），量级取 1:2:4，属工程判断。
#
# 在这些假设下，成本才可加。脱离 A1–A5 说"总代价"，是无意义的数字。

COST_MODEL = "additive"

COST_UNIT = "值班员处理一次异常工单的等效工时"

COST_ASSUMPTIONS = (
    "A1 两块代价折算到同一效用单位（COST_UNIT）",
    "A2 c_dup / c_miss 为单位下的常数，无规模效应",
    "A3 p_retry 与 p_conflict 由外部给定，不来自本实验数据",
    "A4 期望损失对事件数线性，事件之间无级联",
    "A5 单位换算表来自课程权限分级，是工程假设而非测量",
)

# 出现率的**名义**基准值。选 1.0 只是为了让旧的单事件口径可以复现，
# 它**不是**对真实业务频率的估计——报告里不许把它当估计值用。
P_RETRY_BASELINE = 1.0
P_CONFLICT_BASELINE = 1.0

# 出现率敏感性网格：真实业务里这两个数几乎不可能等于 1
P_RETRY_GRID = (0.02, 0.05, 0.1, 0.2, 0.5, 1.0)
P_CONFLICT_GRID = (0.01, 0.02, 0.05, 0.1, 0.2, 0.5)


def total_cost(dup_cost: float, miss_cost: float,
               model: str = COST_MODEL) -> float:
    """
    按声明的成本模型合并两块代价。

    只有 model == "additive" 才允许返回一个标量；其他取值一律报错，
    因为本项目**没有**声明别的模型——不声明就不许悄悄加。
    """
    if model != "additive":
        raise ValueError(
            f"未声明的成本模型 {model!r}；本项目只声明了 additive，"
            f"要做二维比较请直接返回 (dup, miss) 二元组，不要合并成一个数")
    return dup_cost + miss_cost


# --------------------------------------------------------------------------
# 八、隐藏集冻结证据（★ 第三轮新增）
# --------------------------------------------------------------------------
# 审阅方第七节（二）："先冻结测试再改策略，并留下可核验的冻结证据"。
# 做法：先算 holdout 的内容哈希，写进 data/holdout_freeze.json，含
#   · 生成时刻（UTC）
#   · 规范化内容（排序后的条目序列）的 sha256
#   · 条目数与分类计数
# 之后每次跑实验都重算并比对；不一致就报 HOLDout 被动过。
# 这**不能**证明"这份测试没参与设计"（那需要外部保管记录），
# 它能证明的是"这份测试在冻结之后没被改过"——两件事的强度不同，别混。

HOLDOUT_FREEZE_PATH = "holdout_freeze.json"
# 审阅方第四节（一）：生成器知道什么叫变义，评估器不知道。
# 把标签留下来之后，还必须能回答"这条标签凭什么是对的"。
#
# 判据不能是"我觉得意思没变"，也不能是"用 key 函数跑一遍看键是否相同"——
# 后者等于拿被检验的那套规则检验自己。所以等价关系单独定义在这里，
# 是**契约的独立声明**，contract_check.py 负责核对它与归一化实现一致。
#
# 这是"内部一致性"的证据，不是"现实语义正确"的证据（审阅方第七节（一））。
# 它证明的是：生成器打的标签和规范化器认的等价类是同一个东西。

def contract_equiv(tool: str, field_name: str, a: Any, b: Any) -> bool:
    """
    a 与 b 在契约意义上是否保义等价。

    规则（按字段类别分派，与 norm_field 同一套依据，但**独立实现**）：
      · 两边相等 → 等价
      · `__` 前缀的追踪字段 → 一律等价（它们连键都进不去，谈不上改变语义）
      · 缺省 vs schema 默认值 → 等价（"没写"与"写出默认值"保义）
      · month    → 同一 MONTH_EQUIV 等价类（同精度）
      · station  → norm_station 后相等
      · region   → norm_region 后相等
      · bool/int → 数值/布尔字面等价（'true' ≡ True，'7' ≡ 7）
      · DERIVED_FROM 字段 → 两边**规范化签名**相同
      · 其余文本 → 声明的同义词表内互换，或该字段声明可折叠时仅空白差异
    """
    if a == b:
        return True

    # 追踪字段（`__trace` / `__note`）：契约明确规定它们不进键。
    # 往它们里面塞什么都不改变这条请求的语义，因此等价。
    if isinstance(field_name, str) and field_name.startswith("__"):
        return True

    absent_a = a is None or (isinstance(a, str) and a == "")
    absent_b = b is None or (isinstance(b, str) and b == "")
    if absent_a or absent_b:
        d = default_of(tool, field_name)
        other = b if absent_a else a
        if d is None:
            return other is None or (isinstance(other, str) and other == "")
        return _scalar_equiv(d, other)

    kind = field_kind(tool, field_name)

    if kind == "month":
        return norm_month(a) == norm_month(b)
    if kind == "station":
        return norm_station(a) == norm_station(b)
    if kind == "region":
        return norm_region(a) == norm_region(b)
    if kind in ("bool", "int") and may_coerce(tool, field_name):
        return _scalar_equiv(a, b)

    if (tool, field_name) in DERIVED_FROM and isinstance(a, str) and isinstance(b, str):
        sa = derived_signature(tool, field_name, a)
        sb = derived_signature(tool, field_name, b)
        return sa is not None and sa == sb

    if isinstance(a, str) and isinstance(b, str):
        # 同义词表（NOTE_EQUIV）：'疑似' ≡ '可能存在'。
        # 按**片段替换**判定，不要求整串等于同义词——备注里同义词总带着上下文。
        if _synonym_swap_equiv(a, b):
            return True
        if may_fold_whitespace(tool, field_name):
            return re.sub(r"\s+", " ", a.strip()) == re.sub(r"\s+", " ", b.strip())
        return a == b

    return False


def _synonym_swap_equiv(a: str, b: str) -> bool:
    """
    把 a 里出现的每个同义词都换成它的规范形式，看是否等于 b（反之亦然）。

    只做**声明过的**同义词，不做任何模糊匹配：
    备注 '温度偏差1度' 与 '温度偏差2度' 在这里必然不等，因为数字不在同义词表里。
    """
    def canon_one(s: str) -> str:
        out = s
        for canon, alts in NOTE_EQUIV.items():
            for alt in alts:
                if alt in out:
                    out = out.replace(alt, canon)
        return out

    return canon_one(a) == canon_one(b)


def derived_signature(tool: str, field_name: str,
                      value: str) -> Optional[Tuple[str, str, str]]:
    """
    把一个派生字段规范化成**签名**：把每个实体片段换成它的规范形式，
    丢掉分隔符。签名相同 = 这两串说的是同一件事。

    与 explain_field() 的分工：
      · explain_field 回答"能不能**替代**"——它要求与已声明槽位逐项一致，
        多一个实体就拒。这是进键前的守卫。
      · derived_signature 回答"这两串**是不是同一件事**"——它不需要外部声明，
        因为它把实体自身的规范形式写进签名。
        两个都合法的作业名，签名相同就该被认成保义改写。
    两个函数共用 collect_spans()，所以"认得出哪些实体"这件事只有一处实现。
    """
    if not isinstance(value, str) or not value:
        return None
    if "\u27e6" in value or "\u27e7" in value:
        return None
    spans = collect_spans(value)
    want = set(DERIVED_FROM.get((tool, field_name), ()))
    parts: List[str] = []
    cursor = 0
    seen: Dict[str, int] = {}
    for s in sorted(spans, key=lambda x: x.start):
        gap = value[cursor:s.start]
        if gap and not DERIVED_SEPARATORS.fullmatch(gap):
            return None                       # 有解释不了的片段 → 不是同一件事
        if s.kind not in want:
            return None                       # 有该字段不该出现的实体
        seen[s.kind] = seen.get(s.kind, 0) + 1
        if seen[s.kind] > 1:
            return None                       # 同一类实体出现两次 → 不是同一件事
        parts.append(s.norm if s.norm is not None else s.raw)
        cursor = s.end
    tail = value[cursor:]
    if tail and not DERIVED_SEPARATORS.fullmatch(tail):
        return None
    if set(seen) != want:
        return None                           # 缺槽位 → 不是同一件事
    order = [k for k in DERIVED_FROM[(tool, field_name)]]
    by = {}
    cursor = 0
    for s in sorted(spans, key=lambda x: x.start):
        by[s.kind] = s.norm if s.norm is not None else s.raw
    return tuple(by.get(k, "") for k in order)


def _scalar_equiv(a: Any, b: Any) -> bool:
    if isinstance(a, bool) or isinstance(b, bool):
        return _as_bool(a) is not None and _as_bool(a) == _as_bool(b)
    try:
        return float(str(a).strip()) == float(str(b).strip())
    except (TypeError, ValueError):
        return str(a).strip().lower() == str(b).strip().lower()


def _as_bool(v: Any):
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)) and v in (0, 1):
        return bool(v)
    if isinstance(v, str):
        low = v.strip().lower()
        if low in ("true", "1", "是", "yes", "t", "y"):
            return True
        if low in ("false", "0", "否", "no", "f", "n"):
            return False
    return None


def _sep_only_equiv(a: str, b: str) -> bool:
    """只差分隔符与大小写（不做别名归一）。用于解释不了时的兜底核对。"""
    f = lambda s: re.sub(r"[_\-/|,;:·.\s]+", "", s).lower()
    return f(a) == f(b)