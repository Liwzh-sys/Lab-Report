"""
contract_check.py — 契约一致性自检。

这是审阅方最核心的要求："你有没有一套独立于你自己的标准，
来判定这两次操作是不是同一次。"

本脚本把这个标准写成可执行的断言：凡是契约声明的保义关系，
归一化之后必须真的一致；凡是契约声明的变义关系，归一化之后必须仍然不同。
任何一条不满足就直接 FAIL 退出。

跑法：cd src && python contract_check.py
"""

from __future__ import annotations

import sys

import contract as C
from perturb import MonthSyn, RegionSyn, StationSyn
from structured import StructuredKey
from policy import KeyPolicy

FAILS = []
CHECKS = 0


def check(cond: bool, msg: str):
    global CHECKS
    CHECKS += 1
    if not cond:
        FAILS.append(msg)
        print(f"  FAIL  {msg}")
    else:
        print(f"  ok    {msg}")


# --------------------------------------------------------------------------
# 1. 时间契约：生成侧（MonthSyn）与判定侧（norm_month）必须一致
# --------------------------------------------------------------------------
def check_time_contract():
    print("\n[1] 时间语义契约：生成侧 vs 判定侧")
    print("    纪律：日精度代表不同操作，跨精度不得互折")

    # 1a. MonthSyn 里每条"保义替代写法"，归一化后必须与 canonical 相同
    for canon, alts in MonthSyn.items():
        for a in alts:
            got = C.norm_month(a)
            check(got == canon,
                  f"MonthSyn 保义项 {a!r} → 期望 {canon}，实得 {got}")

    # 1b. 跨精度必须**不**相等
    pairs = [("2026-08", "2026-08-01"), ("2026-08", "2026-08-15"),
             ("2026-09", "2026-09-01")]
    for a, b in pairs:
        check(C.norm_month(a) != C.norm_month(b),
              f"跨精度必须区分：{a} vs {b}（实得 {C.norm_month(a)} / {C.norm_month(b)}）")

    # 1c. 裸月不得无条件落到具体年份
    check(C.norm_month("8月") == "??-08",
          f"无年份'8月'必须标歧义，实得 {C.norm_month('8月')}")
    check(C.norm_month("8月") != C.norm_month("2026-08"),
          "无年份'8月'不得等同 2026-08")

    # 1d. MonthSyn 不得包含跨精度条目（这是 v1 的根因）
    bad = []
    for canon, alts in MonthSyn.items():
        for a in alts:
            pa, pb = C.precision_of(C.norm_month(a)), C.precision_of(canon)
            if pa != pb:
                bad.append((canon, a, pa, pb))
    check(not bad, f"MonthSyn 中不存在跨精度条目（违规项：{bad}）")


# --------------------------------------------------------------------------
# 2. 字段契约：schema 声明的字段必须真的进键
# --------------------------------------------------------------------------
def check_field_contract():
    print("\n[2] 字段契约：契约表声明的每个字段都必须参与键")

    samples = {
        "query_region_stats": {"region": "南海北部", "month": "2026-08",
                               "include_flag_dist": True},
        "query_station_stats": {"station": "S07", "month": "2026-08",
                                "include_qc": False},
        "geocode_region": {"region": "南海北部", "res": 9,
                           "coverage": "centroid_only"},
        "submit_batch_job": {"job_name": "recompute_S07_2026-08",
                             "station": "S07", "month": "2026-08", "cores": 64},
        "write_qc_note": {"station": "S07", "month": "2026-08",
                          "note": "温度偏差1度"},
        "send_email": {"to": "duty@lab.cn", "subject": "S07 告警",
                       "body_ref": "B-002"},
    }

    for tool, args in samples.items():
        declared = set(C.key_fields(tool))
        sk = StructuredKey(tool)
        used = set(sk.slots(args).keys())
        missing = declared - used
        check(not missing,
              f"{tool}: 契约声明字段全部进键（缺失 {sorted(missing)}）")

    # 逐个字段做"改一下必须换键"的验证
    print("\n    逐字段敏感度（改一个声明字段 → 键必须变）：")
    for tool, args in samples.items():
        sk = StructuredKey(tool)
        base = sk.key(args)
        for f in C.key_fields(tool):
            alt = dict(args)
            v = alt.get(f)
            # 造一个不同的值
            if isinstance(v, bool):
                alt[f] = not v
            elif isinstance(v, int):
                alt[f] = v + 1
            elif f == "month":
                alt[f] = "2026-09"
            elif f == "region":
                alt[f] = "南海中部"
            elif f == "station":
                alt[f] = "S12"
            elif f == "subject":
                alt[f] = str(v) + "（补充）"
            elif f == "to":
                alt[f] = "other@lab.cn"
            elif f in ("body_ref", "note", "job_name", "coverage"):
                alt[f] = str(v) + "_x"
            else:
                alt[f] = str(v) + "_x"
            check(sk.key(alt) != base, f"{tool}.{f} 参与键")


# --------------------------------------------------------------------------
# 3. 类型转换契约：不得无差别转换
# --------------------------------------------------------------------------
def check_type_contract():
    print("\n[3] 类型转换契约：只对白名单字段做转换")

    # 备注 "01" vs "1.0" 必须**不**相等（note 不可转换）
    a = {"station": "S07", "month": "2026-08", "note": "01"}
    b = {"station": "S07", "month": "2026-08", "note": "1.0"}
    ka = StructuredKey("write_qc_note").key(a)
    kb = StructuredKey("write_qc_note").key(b)
    check(ka != kb, f"备注 '01' vs '1.0' 必须区分（实得相同键：{ka}）")

    # 邮件主题 "S07" vs "S-07" 不得被站号别名折叠
    c = {"to": "duty@lab.cn", "subject": "S07", "body_ref": "B-001"}
    d = {"to": "duty@lab.cn", "subject": "S-07", "body_ref": "B-001"}
    kc = StructuredKey("send_email").key(c)
    kd = StructuredKey("send_email").key(d)
    check(kc != kd, f"主题 'S07' vs 'S-07' 必须区分（实得相同键：{kc}）")

    # 白名单字段的转换仍然要做（res 7 vs "7" 应等价）
    e = {"region": "南海北部", "res": 7, "coverage": "all_intersecting"}
    f = {"region": "南海北部", "res": "7", "coverage": "all_intersecting"}
    check(StructuredKey("geocode_region").key(e) ==
          StructuredKey("geocode_region").key(f),
          "白名单字段 res: 7 与 '7' 应等价（保义）")


# --------------------------------------------------------------------------
# 4. 命名空间契约：不同工具永不撞键
# --------------------------------------------------------------------------
def check_namespace():
    print("\n[4] 命名空间契约：工具名必须进键")
    args = {"region": "南海北部", "month": "2026-08"}
    k1 = StructuredKey("query_region_stats").key(args)
    k2 = StructuredKey("query_station_stats").key(
        {"station": "S07", "month": "2026-08"})
    check(k1 != k2, "不同工具的同形参数不得撞键")
    check("query_region_stats" in k1 or "tool" in k1,
          f"键内应含工具命名空间，实得 {k1}")

    # 用 universe 里真正的跨工具探针逐对验证：参数完全相同、只有工具不同
    from universe import build_namespace_probes
    probes = build_namespace_probes()
    bad = []
    for d in probes:
        ka = StructuredKey(d.src.tool).key(d.src.slots)
        kb = StructuredKey(d.decoy.tool).key(d.decoy.slots)
        if ka == kb:
            bad.append((d.src.tool, d.decoy.tool))
    check(not bad, f"跨工具探针 {len(probes)} 对全部区分（撞键：{bad}）")


# --------------------------------------------------------------------------
# 5. 残余契约：自由文本的数字必须保留
# --------------------------------------------------------------------------
def check_residual():
    print("\n[5] 残余契约：自由文本里的数字与顺序必须保留")
    a = {"station": "S07", "month": "2026-08", "note": "温度偏差1度"}
    b = {"station": "S07", "month": "2026-08", "note": "温度偏差2度"}
    check(StructuredKey("write_qc_note").key(a) !=
          StructuredKey("write_qc_note").key(b),
          "残余'偏差1度' vs '偏差2度' 必须区分")

    c = {"station": "S07", "month": "2026-08", "note": "8月3日复测通过"}
    d = {"station": "S07", "month": "2026-08", "note": "8月9日复测通过"}
    check(StructuredKey("write_qc_note").key(c) !=
          StructuredKey("write_qc_note").key(d),
          "残余'8月3日' vs '8月9日' 必须区分")

    # 语序必须保留：甲影响乙 ≠ 乙影响甲
    e = {"station": "S07", "month": "2026-08", "note": "温跃层影响声速"}
    f = {"station": "S07", "month": "2026-08", "note": "声速影响温跃层"}
    check(StructuredKey("write_qc_note").key(e) !=
          StructuredKey("write_qc_note").key(f),
          "语序'甲影响乙' vs '乙影响甲' 必须区分")


# --------------------------------------------------------------------------
# 6. 保义声明：契约说等价的，必须真的等价
# --------------------------------------------------------------------------
def check_equiv_declarations():
    print("\n[6] 保义声明：契约说不改变语义的写法必须真的一致")
    cases = [
        ("query_region_stats",
         {"region": "南海北部", "month": "2026-08"},
         {"region": "northern South China Sea", "month": "2026年8月"}),
        ("submit_batch_job",
         {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-08"},
         {"job_name": "recompute_S07_2026-08", "station": "s-07", "month": "202608"}),
    ]
    for tool, a, b in cases:
        sk = StructuredKey(tool)
        check(sk.key(a) == sk.key(b),
              f"{tool}: 保义写法应等价\n        A={sk.key(a)}\n        B={sk.key(b)}")


def check_decoy_minimality():
    print("\n[7] 诱饵最小性：每对只改一个维度")
    from universe import (build_baseline_ops, build_decoys,
                          build_namespace_probes)
    ops = build_baseline_ops()
    same = build_decoys(ops)
    bad = [(d.decoy.op_id, d.changed) for d in same if len(d.changed) != 1]
    check(not bad, f"同工具诱饵 {len(same)} 对，改多维度 {len(bad)} 对（{bad[:3]}）")

    # 实际 diff 校验：除了声明的那个字段，其余字段必须逐字节相同
    viol = []
    for d in same:
        f = d.changed[0]
        a, b = d.src.slots, d.decoy.slots
        diff = {k for k in set(a) | set(b) if a.get(k) != b.get(k)}
        if diff != {f}:
            viol.append((d.decoy.op_id, sorted(diff), f))
    check(not viol, f"实际字段 diff 与声明一致（违规 {len(viol)} 对：{viol[:3]}）")

    ns = build_namespace_probes()
    ok = all(d.src.slots == d.decoy.slots and d.src.tool != d.decoy.tool
             for d in ns)
    check(ok, f"跨工具探针 {len(ns)} 对：参数完全相同、工具不同")


# --------------------------------------------------------------------------
# 8. 事件三类：标签必须与参数差异解耦
# --------------------------------------------------------------------------
def check_event_labels():
    print("\n[8] 事件四类：身份标签不能由参数差异推出")
    from universe import build_baseline_ops, build_event_pairs, EVENT_TYPES
    ev = build_event_pairs(build_baseline_ops())

    counts = {t: sum(1 for e in ev if e.event_type == t) for t in EVENT_TYPES}
    for t, n in counts.items():
        check(n > 0, f"事件类型 {t:14s} 非空（{n} 对）")

    same_params = [e for e in ev if e.a == e.b]
    new_intent_same = [e for e in same_params if e.event_type == "new_intent"]
    replay_same = [e for e in same_params if e.event_type == "replay"]

    check(len(new_intent_same) > 0,
          f"存在「参数完全相同但身份不同」的负例（{len(new_intent_same)} 对）")
    check(len(replay_same) > 0,
          f"存在「参数完全相同且身份相同」的正例（{len(replay_same)} 对）")
    check(bool(new_intent_same) and bool(replay_same),
          "同一参数形态下同时存在正例与负例 ⇒ 任何只看参数的键都有不可消除的错误"
          "（这条是本报告最重要的局限，不是待修的 bug）")

    # ★ 第三轮 P0-4：重规划必须再分「保义」与「真实变义」，否则
    #   保义改写会被 a != b 一律判为冲突。两类都要非空。
    replan_eq = [e for e in ev if e.event_type == "replan_equiv"]
    replan_ch = [e for e in ev if e.event_type == "replan_change"]
    check(len(replan_eq) > 0,
          f"存在「同身份保义改写」事件（{len(replan_eq)} 对）")
    check(len(replan_ch) > 0,
          f"存在「同身份真实变义」事件（{len(replan_ch)} 对）")
    check(all(e.identity_same for e in replan_eq + replan_ch),
          "两类重规划的身份标记均为「同身份」")
    check(all(e.semantic_change for e in replan_ch)
          and not any(e.semantic_change for e in replan_eq),
          "「真实变义」类确实改了语义，「保义改写」类确实没改"
          "（判据是契约的 contract_equiv，不是我的直觉）")

    # 期望动作必须与事件类型一致，且四类里 reuse 出现在两个类型上
    from universe import EXPECTED_ACTION
    bad = [e for e in ev if e.expected_action != EXPECTED_ACTION.get(e.event_type)]
    check(not bad, f"期望动作与事件类型一致（不一致 {len(bad)} 对）")
    acts = {e.event_type: e.expected_action for e in ev}
    check(len(set(acts.values())) == 3,
          f"四类事件映射到 {len(set(acts.values()))} 种动作（reuse/reject/execute），"
          "其中 reuse 覆盖两类 ⇒ 动作不能反推事件类型")


def check_contract_equiv_consistency():
    """
    ★ 第三轮：contract_equiv 是标签核对与隐藏集判分的唯一基准，
    它自己必须先自洽。这里查三件事：
      1. 自反性：任何值与它自己的拷贝等价；
      2. 上述正例/负例声明里，正例必等价、负例必不等价；
      3. 对称性：equiv(a,b) == equiv(b,a)。
    """
    print("\n[9] contract_equiv 自洽性（标签核对与隐藏集的唯一基准）")
    import contract as C
    from holdout import build_holdout
    from universe import build_baseline_ops

    ops = build_baseline_ops()
    n_refl = 0
    for op in ops:
        for k, v in op.slots.items():
            n_refl += 1
            if not C.contract_equiv(op.tool, k, v, v):
                check(False, f"自反性失败：{op.tool}.{k} = {v!r}")
                return
    check(True, f"自反性：{n_refl} 个 (工具,字段,值) 与自身等价")

    # 对称性 + 隐藏集判分
    hold = build_holdout()
    asym, pos_bad, neg_bad = [], [], []
    for d in hold:
        for k in set(d.src.slots) | set(d.decoy.slots):
            a, b = d.src.slots.get(k), d.decoy.slots.get(k)
            if C.contract_equiv(d.src.tool, k, a, b) != C.contract_equiv(
                    d.src.tool, k, b, a):
                asym.append((d.kind, k))
    check(not asym, f"对称性：隐藏集 {len(hold)} 对里不对称 {len(asym)} 处 {asym[:3]}")

    for d in hold:
        all_same = all(C.contract_equiv(d.src.tool, k,
                                        d.src.slots.get(k), d.decoy.slots.get(k))
                       for k in set(d.src.slots) | set(d.decoy.slots))
        if getattr(d, "polarity", "负例") == "正例":
            if not all_same:
                pos_bad.append(d.kind)
        else:
            if all_same:
                neg_bad.append(d.kind)
    check(not pos_bad, f"8 条正例在 contract_equiv 下全部判为等价（违例 {pos_bad}）")
    check(not neg_bad, f"20 条负例在 contract_equiv 下全部判为不等价（违例 {neg_bad}）")


def main():
    print("=" * 78)
    print("语义契约自检")
    print("=" * 78)
    check_time_contract()
    check_field_contract()
    check_type_contract()
    check_namespace()
    check_residual()
    check_equiv_declarations()
    check_decoy_minimality()
    check_event_labels()
    check_contract_equiv_consistency()

    print("\n" + "=" * 78)
    if FAILS:
        print(f"结果：{len(FAILS)} / {CHECKS} 项失败")
        for f in FAILS:
            print(f"  · {f.splitlines()[0]}")
        sys.exit(1)
    print(f"结果：全部 {CHECKS} 项通过")
    print("=" * 78)


if __name__ == "__main__":
    main()