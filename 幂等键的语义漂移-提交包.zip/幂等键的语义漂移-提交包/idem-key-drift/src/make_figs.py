"""
make_figs.py — 八张图，全部从 data/results.json 与 data/e3_lambda_scan.json 现场读。

第三轮重画的三条纪律
--------------------
1. **不画"总代价"第三根柱。** dup 与 miss 能否相加依赖 COST_MODEL="additive"
   与假设 A1–A5；把它们压成一根柱会让读者以为"38.2 < 42.1 可以排序"，
   那是测试集分数冒充指标。图 1 只并排画两个分量，总分排序交给图 8 的二维帕累托校验。
2. **方向不能标反。** 第二轮 fig5(b) 把"错合并"与"漏合并"的颜色标反过，
   读者会得出相反结论。本轮所有颜色在文件顶部集中定义一次，每张图另标文字方向说明。
3. **图例必须与数据同源。** 每根柱的数值直接来自 results.json 的字段，
   不在画图脚本里二次计算或改名。

图目录
------
fig1  策略并排：两个代价分量（不相加）+ 二维错误方向
fig2  单因素归因：三根 Δ 柱，每根只归给一个因素
fig3  λ 扫描：总代价曲线与最优规则数切换，交点给解析值
fig4  单条规则审计：Δ重复 vs Δ漏做
fig5  四类事件 × 期望动作判分
fig6  副作用分级 + 隐藏集三数（正例合并 / 负例误合 / 选择性拒绝）
fig7  算子五计数：调用 ≠ 改成功
fig8  成本模型校验：二维帕累托与 36 组出现率检查
"""

from __future__ import annotations

import json
import os

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")
FIG = os.path.join(HERE, "..", "figs")
os.makedirs(FIG, exist_ok=True)

# ---- 颜色：只在这里定义一次 -----------------------------------------------
C_SAFE = "#2B6CB0"     # 蓝：安全/正确
C_MID = "#4C9BE8"
C_WARN = "#DD6B20"     # 橙：风险
C_BAD = "#C53030"      # 红：错误
C_GREY = "#8A94A6"
C_DARK = "#1A202C"
C_TXT = "#4A5568"
C_GRID = "#E2E8F0"
C_BG = "#FFFFFF"

for _f in ("Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "Source Han Sans SC"):
    if any(_f.lower() in f.name.lower() for f in font_manager.fontManager.ttflist):
        plt.rcParams["font.sans-serif"] = [_f]
        break
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 150
plt.rcParams["savefig.bbox"] = "tight"

with open(os.path.join(DATA, "results.json"), encoding="utf-8") as f:
    R = json.load(f)
with open(os.path.join(DATA, "e3_lambda_scan.json"), encoding="utf-8") as f:
    SCAN = json.load(f)


def style(ax, title=None, xlabel=None, ylabel=None, grid_axis="y"):
    ax.set_facecolor(C_BG)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color("#CBD5E0")
    ax.grid(axis=grid_axis, color=C_GRID, lw=0.8, zorder=0)
    ax.set_axisbelow(True)
    if title:
        ax.set_title(title, fontsize=12, pad=12, color=C_DARK, fontweight="bold")
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=10, color=C_TXT)
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=10, color=C_TXT)
    ax.tick_params(colors=C_TXT, labelsize=9)


def foot(fig, text, y=-0.04):
    fig.text(0.5, y, text, fontsize=8.2, color=C_TXT, ha="center", va="top")


# --------------------------------------------------------------------------
# 图 1 策略并排：只有两个分量，不画总分
# --------------------------------------------------------------------------
def fig1():
    summ = {s["strategy"]: s for s in R["E4_strategies"]["summary"]}
    names = ["裸参数哈希", "仅 SAFE", "SAFE+全部RISKY",
             "槽位投影（不含替代）", "槽位投影（含守卫替代）"]
    short = ["裸哈希", "仅 SAFE", "SAFE+全 RISKY", "槽位投影\n(无替代)", "槽位投影\n(含守卫)"]
    dup = [summ[n]["dup_mean"] for n in names]
    miss = [summ[n]["miss_mean"] for n in names]
    fn = [summ[n]["fn_mean"] for n in names]
    fp = [summ[n]["fp_mean"] for n in names]

    fig, (ax, ax2) = plt.subplots(1, 2, figsize=(13.4, 5.4),
                                  gridspec_kw={"width_ratios": [1.25, 1]})
    x = np.arange(len(names))
    w = 0.36
    b1 = ax.bar(x - w / 2, dup, w, color=C_WARN,
                label="保义重复 dup（只数该复用却拆开）", zorder=3)
    b2 = ax.bar(x + w / 2, miss, w, color=C_BAD,
                label="漏做/错吃 miss（单次大额）", zorder=3)
    ax.set_xticks(x)
    ax.set_xticklabels(short, fontsize=9)
    style(ax, "两个代价分量：并排，不相加", ylabel="代价（8 种子均值，λ=1）")
    ax.legend(fontsize=9, frameon=False, loc="upper right")
    for bs in (b1, b2):
        for r in bs:
            h = r.get_height()
            if h > 0.4:
                ax.annotate(f"{h:.2f}", (r.get_x() + r.get_width() / 2, h),
                            ha="center", va="bottom", fontsize=8, color=C_DARK)

    ax2.scatter(fn, fp, s=150, c=[C_BAD, C_SAFE, C_MID, C_GREY, C_DARK],
                zorder=4, edgecolors="white", linewidths=1.3)
    # 标签防重叠。★ 第四轮又发现一处：第五轮口径下"仅 SAFE"与"槽位投影(无替代)"
    # 坐标完全相同（FN 0.408 / FP 0），原来靠纵向推开会让两行字挨在一起。
    # 坐标相同的点合并成一个标签，比推开清楚。
    pts = {}
    for i, n in enumerate(names):
        pts.setdefault((round(fn[i], 4), round(fp[i], 4)), []).append(i)
    order = sorted(pts.items(), key=lambda kv: (kv[0][1], kv[0][0]))
    used = []
    for (fx, fy), idx in order:
        label = " ／ ".join(short[i].replace("\n", " ") for i in idx)
        off = 14
        while any(abs(fx - u[0]) < 0.18 and abs(off - u[1]) < 17 for u in used):
            off += 17
        used.append((fx, off))
        ax2.annotate(label, (fx, fy),
                     textcoords="offset points", xytext=(11, off), fontsize=8.5,
                     color=C_TXT,
                     arrowprops=dict(arrowstyle="-", color="#CBD5E0", lw=0.8,
                                     shrinkA=0, shrinkB=4))
    ax2.set_xlim(-0.06, 1.12)
    ax2.set_ylim(-0.04, max(fp) * 1.45 + 0.04)
    # ★ 第四轮（定稿修订单 5-3）：右轴原来是"FN 漏合并率（该并的没并）"，
    #   名不副实——fn 统计的是**所有** episode 分裂过的比例，其中包含
    #   "正确区分了真实变义"和"正确区分了新意图"的那些，那些不是失误。
    #   现在统一叫"episode 分裂率（诊断量）"。同一指标在图和表里叫两个
    #   名字，比叫错名字更伤，所以 §0 主表表头与 §2.3 定义表必须一起改。
    style(ax2, "错误有两个方向，不能混成一个",
          xlabel="episode 分裂率 fn（诊断量：分裂过就算，不求该不该）",
          ylabel="FP 误合并率（不该并的也并了）", grid_axis="both")
    ax2.annotate("越靠左下越好", xy=(0.04, 0.93), xycoords="axes fraction",
                 fontsize=9, color=C_TXT)

    foot(fig,
         "★ 本图不画“总代价 = dup + miss”这根柱：两块代价相加依赖 COST_MODEL='additive' 与\n"
         "假设 A1–A5（contract.py 第七节）。压成一根柱会让读者以为总分可以排序，那是测试集分数冒充指标。\n"
         "dup 为“仅保义重复代价”：只数该复用却另起新键的样本，真实变义被正确拒绝时不计入（第四轮口径）。\n"
         "总分排序的自洽性见 fig8（36 组出现率，off-pareto 0 个）。右图越靠左下越好；FP 分母 = 同工具诱饵 113 对。",
         y=-0.06)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig1_strategy_totals.png"))
    plt.close(fig)


# --------------------------------------------------------------------------
# 图 2 单因素归因
# --------------------------------------------------------------------------
def fig2():
    att = R["E0_dedup"]["attribution"]
    labels = [a["label"] for a in att]
    bare = [a["bare_dup_delta"] for a in att]
    slot = [a["slot_dup_delta"] for a in att]

    # ★ 第四轮：脚注多了一行（说明不引用旧口径数），画布加高、底部留 27%。
    fig, ax = plt.subplots(figsize=(10.6, 6.5))
    x = np.arange(len(labels))
    w = 0.36
    b1 = ax.bar(x - w / 2, bare, w, color=C_WARN, label="裸参数哈希", zorder=3)
    b2 = ax.bar(x + w / 2, slot, w, color=C_SAFE, label="槽位投影", zorder=3)
    ax.axhline(0, color="#A0AEC0", lw=1)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=9.5)
    style(ax, "一次只动一个因素：每个 Δ 只归给一个因素",
          ylabel="保义重复代价 Δ（相对上一配置，8 种子均值）")
    ax.legend(fontsize=9.5, frameon=False)
    for bs in (b1, b2):
        for r in bs:
            h = r.get_height()
            ax.annotate(f"{h:+.2f}", (r.get_x() + r.get_width() / 2, h),
                        ha="center", va="bottom" if h >= 0 else "top",
                        fontsize=8.5, color=C_DARK)

    it = R["E0_dedup"]
    foot(fig,
         "★ 三根柱来自三对相邻配置（F0a→F0b、F0b→F1、F1→F2），每对只改一个因素。"
         "v2 曾把“取消去重 + 加进重放”的整段下降记在“取消去重”头上，是把两个因素合起来记在一个头上。\n"
         "（那一整段的具体数值是旧口径的，本图不引用——新旧口径的数不能并排放在一张图里。）\n"
         f"交互项 裸 {it['interaction']['bare_dup_delta']:+.4f} / "
         f"槽位 {it['interaction']['slot_dup_delta']:+.4f}。{it['interaction_note']}"
         "所以这三根柱只回答“各因素各自贡献多少”，不回答“因素之间有没有耦合”。\n"
         "纵轴是这个口径下的保义重复代价：真实变义被正确拒绝时不计入损失，"
         "所以加入变义这一步的 Δ 不再是正数。",
         y=0.20)
    # ★ 脚注用**图内**坐标（正数）而不是负的图外坐标：负坐标在保存时会被裁掉，
    #   上一次这里就裁掉了前两行。底部留 26% 给它，脚注顶部放 0.19。
    fig.tight_layout(rect=(0, 0.27, 1, 1))
    fig.savefig(os.path.join(FIG, "fig2_dedup_effect.png"))
    plt.close(fig)


# --------------------------------------------------------------------------
# 图 3 λ 扫描
# --------------------------------------------------------------------------
def fig3():
    scan = SCAN["scan"]
    lams = [p["lam"] for p in scan]
    tot = [p["total"] for p in scan]
    ns = [p["n"] for p in scan]

    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(10.6, 7.2), sharex=True,
                                  gridspec_kw={"height_ratios": [2.1, 1]})
    ax.plot(lams, tot, color=C_SAFE, lw=2.0, zorder=3)
    ax.fill_between(lams, 0, tot, color=C_SAFE, alpha=0.08, zorder=2)
    for s in SCAN.get("switches", []):
        ls = s.get("lam_star")
        if ls:
            ax.axvline(ls, color=C_BAD, ls="--", lw=1.3, zorder=4)
            ax.annotate(f"解析交点 λ*={ls:.3f}", (ls, max(tot) * 0.88),
                        rotation=90, fontsize=8.5, color=C_BAD,
                        ha="right", va="top")
    style(ax, "λ 标定：最优子集的保义总代价随 λ 变化",
          ylabel="保义总代价（λ·dup + miss）")
    # sharex 下上子图会留一排没有标签的刻度线，看着像脏点，直接去掉
    ax.tick_params(axis="x", bottom=False, labelbottom=False)

    ax2.step(lams, ns, where="post", color=C_WARN, lw=2.0, zorder=3)
    ax2.set_yticks(sorted(set(ns)))
    style(ax2, "最优规则数随 λ 的切换", xlabel="λ", ylabel="最优子集规则数")

    foot(fig,
         f"★ 本文件由 run_experiments.e3_lambda_scan() 生成（{SCAN['n_points']} 点，"
         f"λ∈[{SCAN['lam_range'][0]}, {SCAN['lam_range'][1]}]，"
         f"网格 {SCAN['grid_resolution']:.4f}）。v2 时它存在于 data/ 但没有任何代码生成它，"
         "是数据链断裂；现在每次运行重算并覆盖。\n"
         "切换点给的是两条直线的解析交点，不是“格子落在哪”——"
         "v2 的“ρ≈2”是把网格分辨率当成了物理量。",
         y=0.075)
    fig.tight_layout(rect=(0, 0.11, 1, 1))
    fig.savefig(os.path.join(FIG, "fig3_lambda_frontier.png"))
    plt.close(fig)


# --------------------------------------------------------------------------
# 图 4 单条规则审计
# --------------------------------------------------------------------------
def fig4():
    rows = sorted(R["E7_audit"]["single"], key=lambda x: x["d_total"])
    names = [r["rule"] for r in rows]
    dd = [r["d_dup"] for r in rows]
    dm = [r["d_miss"] for r in rows]

    fig, ax = plt.subplots(figsize=(11.0, 6.2))
    y = np.arange(len(names))
    h = 0.36
    # ★ 配色与 fig1 对准：dup 一律橙、miss 一律红。v2/本版初稿这里把 dup 画成蓝色，
    #   同一个量在两张图里不同颜色，读者会以为说的不是同一件事。
    b1 = ax.barh(y + h / 2, dd, h, color=C_WARN,
                 label="Δ 保义重复代价 dup", zorder=3)
    b2 = ax.barh(y - h / 2, dm, h, color=C_BAD, label="Δ 漏做代价 miss", zorder=3)
    ax.axvline(0, color="#A0AEC0", lw=1)
    ax.set_yticks(y)
    ax.set_yticklabels([f"{n}（危险度 {r['danger']:.2f}）"
                        for n, r in zip(names, rows)], fontsize=9)
    style(ax, "单条 RISKY 规则相对“仅 SAFE”的净效应",
          xlabel="代价变化（负 = 这条规则划得来）", grid_axis="x")
    # 图例放左上：右侧会被最长条形的数值标签撞上，左上是唯一稳定空白区
    ax.legend(fontsize=9.5, frameon=False, loc="upper left",
              bbox_to_anchor=(0.005, 0.995))
    # 条形不标数值，读者只能靠估读 x 轴；这里补齐，横向条向右/向左各自留白
    for bs in (b1, b2):
        for r in bs:
            wv = r.get_width()
            ax.annotate(f"{wv:+.2f}",
                        (wv, r.get_y() + r.get_height() / 2),
                        ha="left" if wv >= 0 else "right",
                        va="center", fontsize=8, color=C_DARK,
                        xytext=(4 if wv >= 0 else -4, 0),
                        textcoords="offset points")
    lo, hi = ax.get_xlim()
    ax.set_xlim(lo - 0.7, hi + 0.7)

    foot(fig,
         "★ 单条边际效应不能相加：规则之间不独立，E3 的 32 子集穷举已证。"
         "本图只说明“单独加这一条会怎样”，不能推出“加这几条会怎样”。\n"
         "纵向排序用的是同一条规则内部的 d_total = Δdup + Δmiss，这只在 COST_MODEL='additive' 下成立；\n"
         "跨规则相加没有依据，所以这里只拿它排序，不拿它报数。"
         "危险度是人工审定的先验，不是从数据里学出来的；它只用来排序，不参与任何判分。",
         y=0.055)
    fig.tight_layout(rect=(0, 0.10, 1, 1))
    fig.savefig(os.path.join(FIG, "fig4_rule_audit.png"))
    plt.close(fig)


# --------------------------------------------------------------------------
# 图 5 四类事件 × 期望动作
# --------------------------------------------------------------------------
def fig5():
    rows = R["E8_events"]["rows"]
    types = R["E8_events"]["types"]
    nb = R["E8_events"]["n_by_type"]
    CN = {"replay": "原样重放", "replan_equiv": "同身份\n保义改写",
          "replan_change": "同身份\n真实变义", "new_intent": "不同身份\n新意图"}
    ACT = {"replay": "复用", "replan_equiv": "复用",
           "replan_change": "拒绝", "new_intent": "执行"}
    strategies = []
    for r in rows:
        if r["strategy"] not in strategies:
            strategies.append(r["strategy"])

    fig, axes = plt.subplots(1, len(strategies),
                             figsize=(3.4 * len(strategies), 5.4), sharey=True)
    if len(strategies) == 1:
        axes = [axes]
    # ★ 第四轮修：这个子循环里的循环变量叫 `ax`，被覆盖后下面的 `fig.legend`
    #   与 `foot` 拿到的还是旧变量。改名避免再踩。同时把 y 上限抬到 118，
    #   给 100% 满格柱的数值标签留出垂直空间。
    for axx, s in zip(axes, strategies):
        sub = {r["event_type"]: r for r in rows if r["strategy"] == s}
        ok = [sub[t]["ok"] / sub[t]["n"] * 100 for t in types]
        wr = [sub[t]["wrong"] / sub[t]["n"] * 100 for t in types]
        x = np.arange(len(types))
        axx.bar(x, ok, 0.62, color=C_SAFE, zorder=3, label="判对")
        axx.bar(x, wr, 0.62, bottom=ok, color=C_BAD, zorder=3, label="判错")
        axx.set_xticks(x)
        axx.set_xticklabels([f"{CN[t]}\n期望{ACT[t]}\nn={nb[t]}" for t in types],
                            fontsize=8)
        axx.set_ylim(0, 118)
        style(axx, s, ylabel="占该类事件比例 (%)" if axx is axes[0] else None)
        for i, (a, b) in enumerate(zip(ok, wr)):
            if b > 3:
                axx.annotate(f"{b:.0f}%", (i, a + b / 2), ha="center",
                             va="center", fontsize=8.5, color="white",
                             fontweight="bold")
    # 图例放在整图顶部，不放进第一个子图（第一栏柱子是满格的，放进去必然压字）。
    # ★ 必须放在 tight_layout 之后再定位，否则会被子图标题顶掉。
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, fontsize=9, frameon=False, ncol=2,
               loc="upper center", bbox_to_anchor=(0.5, 1.005))

    fig.suptitle("四类事件 × 期望动作：谁在哪一类上失效", fontsize=13,
                 color=C_DARK, fontweight="bold", y=1.075)
    foot(fig,
         "蓝色 = 判对（符合期望动作），红色 = 判错，红在上叠加，方向不会被误读。\n"
         "v2 的 E8 只有三类，且用“a != b”把 53 个保义改写全算成冲突——"
         "那是把自己的成功记成事故。现在“冲突”只留给第三类：同身份 + 真变义 + 键却并上。\n"
         "★ 注意最右栏“持久化操作 ID”：第四类（新意图）全对，第三类（真实变义）全红——"
         "它分得开“不同身份”，分不开“同身份下的语义变化”（信息条件不同，代价也不同），"
         "不能只读它的正确率。",
         y=0.085)
    fig.tight_layout(rect=(0, 0.16, 1, 0.95))
    fig.savefig(os.path.join(FIG, "fig5_three_event_types.png"))
    plt.close(fig)


# --------------------------------------------------------------------------
# 图 6 副作用分级 + 隐藏集三数
# --------------------------------------------------------------------------
def fig6():
    by = R["E5_side_effect"]["by_side_effect"]
    hold = R["E5_side_effect"]["holdout"]
    san = R["E5_side_effect"]["sanity"]

    fig, (ax, ax2) = plt.subplots(1, 2, figsize=(13.8, 5.6),
                                  gridspec_kw={"width_ratios": [1, 1.15]})

    levels, strategies = [], []
    for r in by:
        if r["level"] not in levels:
            levels.append(r["level"])
        if r["strategy"] not in strategies:
            strategies.append(r["strategy"])
    x = np.arange(len(levels))
    w = 0.8 / max(1, len(strategies))
    for i, s in enumerate(strategies):
        vals = [next((r["dup"] for r in by
                      if r["level"] == lv and r["strategy"] == s), 0)
                for lv in levels]
        ax.bar(x + (i - (len(strategies) - 1) / 2) * w, vals, w,
               label=s, zorder=3, color=[C_BAD, C_SAFE, C_WARN, C_DARK][i % 4])
    ax.set_xticks(x)
    ax.set_xticklabels(levels, fontsize=9.5)
    style(ax, "副作用分级：保义重复代价", ylabel="保义重复代价（8 种子均值）")
    ax.legend(fontsize=8.5, frameon=False)
    # 只读一级四条臂全为 0：这是 c_dup=0 的设定推论，不是测量结果，必须标出来，
    # 否则读者会以为"只读没有重复执行"是发现。
    n_ro = next((r["n_ops"] for r in by if r["level"] == "只读"), 0)
    ax.annotate(f"只读级 {n_ro} 个操作，四条臂合计 0.00\n"
                "（只读工具 c_dup = 0，这是设定推论，\n不是测出来的结论）",
                xy=(0, 0), xytext=(0.02, 0.62), textcoords="axes fraction",
                fontsize=8.5, color=C_TXT,
                bbox=dict(boxstyle="round,pad=0.4", fc="#F7FAFC",
                          ec="#CBD5E0", lw=0.8))

    short = [h["strategy"].replace("槽位投影（不含替代）", "槽位(无替代)")
             .replace("槽位投影", "槽位投影") for h in hold]
    cm = [h["correct_merge_rate"] * 100 for h in hold]
    wm = [h["wrong_merge_rate"] * 100 for h in hold]
    sr = [h["selective_reject_rate"] * 100 for h in hold]
    y = np.arange(len(short))
    hh = 0.26
    # ★ 三个数必须同图，不能只画两个方向。旧版只画"正确合并/错误合并"，
    #   读者看不到"选择性拒绝"，于是"全 RISKY 误合 20%"旁边没有对照量——
    #   fact 上它是拿 16/20 的选择性拒绝换来的。少画一个数就等于少报一项权衡。
    ax2.barh(y + hh, cm, hh, color=C_SAFE, zorder=3,
             label=f"正确合并率（正例 {hold[0]['n_pos']} 条，越高越好）")
    ax2.barh(y, wm, hh, color=C_BAD, zorder=3,
             label=f"错误合并率（负例 {hold[0]['n_neg']} 条，越低越好）")
    ax2.barh(y - hh, sr, hh, color=C_GREY, zorder=3,
             label=f"选择性拒绝率（负例 {hold[0]['n_neg']} 条，越接近 100% 越好）")
    ax2.set_yticks(y)
    ax2.set_yticklabels(short, fontsize=9)
    ax2.set_xlim(0, 125)
    style(ax2, "隐藏集：三个数分开报", xlabel="百分比 (%)", grid_axis="x")
    # 图例必须放到轴外：放右内会被最长的那根灰柱压住，放下内会盖住最后一行。
    ax2.legend(fontsize=7.6, frameon=False, loc="upper center",
               bbox_to_anchor=(0.5, -0.17), ncol=1,
               handlelength=1.4, borderaxespad=0.0)
    # 0% 的标签会顶到 y 轴文字上，零值不标（读者看得到那根条根本不存在）
    for i, (a, b, c) in enumerate(zip(cm, wm, sr)):
        for val, yy in ((a, i + hh), (b, i), (c, i - hh)):
            if val <= 0.05:
                continue
            ax2.annotate(f"{val:.0f}%", (val, yy), va="center", fontsize=7.5,
                         color=C_DARK, xytext=(3, 0), textcoords="offset points")

    fz = R["holdout_freeze"]
    foot(fig,
         "★ 右图为什么必须三个数一起报：一个“永不合并”的策略错误合并率 = 0，"
         f"碰撞率也是 0，在旧口径下是满分（实测正例 {san[0]['correct_merge']}/{san[0]['n_pos']}）；"
         "而“恒为同键”正确合并 100% 却把 20 条负例全吃掉。\n"
         "少报第三个数就看不见权衡：全 RISKY 的 20% 误合并，是拿 16/20 的选择性拒绝换来的。\n"
         f"冻结 v{fz['version']} sha256={fz['sha256'][:16]}…，其中 {fz['n_used_in_dev']} 条正例"
         f"已用于开发（首跑暴露契约实现不一致后据此改过），扣除后正例 {fz['clean_n_pos']} 条 / "
         f"负例 {fz['clean_n_neg']} 条。这 26 条未标记为开发使用；"
         "缺少独立保管记录，所以不当作严格盲测泛化证明。"
         "冻结哈希只证明“之后没改过”，不证明“只评一次、不参与设计”。",
         y=0.055)
    fig.tight_layout(rect=(0, 0.14, 1, 1))
    fig.savefig(os.path.join(FIG, "fig6_side_effect_holdout.png"))
    plt.close(fig)


# --------------------------------------------------------------------------
# 图 7 算子五计数
# --------------------------------------------------------------------------
def fig7():
    per = R["E0_activation"]["per_op"]
    order = ["probed", "chosen", "returned", "changed", "on_label"]
    CN = {"probed": "探测到", "chosen": "被抽中", "returned": "返回非空",
          "changed": "真的变了", "on_label": "变化合标签"}
    names = [r["name"] for r in per]
    mat = np.array([[r[k] for k in order] for r in per], dtype=float)

    fig, ax = plt.subplots(figsize=(12.6, 6.8))
    x = np.arange(len(names))
    w = 0.16
    cols = [C_GREY, C_MID, C_SAFE, C_WARN, C_DARK]
    for i, k in enumerate(order):
        ax.bar(x + (i - 2) * w, mat[:, i], w, label=CN[k], color=cols[i], zorder=3)
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=38, ha="right", fontsize=8.5)
    # 纵轴留 12% 顶部余量，否则最高的 probed 柱顶会被画布切掉
    ax.set_ylim(0, mat.max() * 1.14)
    style(ax, "算子的五个计数：调用 ≠ 改成功",
          ylabel="次数（8 种子 × 全部 episode）")
    ax.legend(fontsize=9, frameon=False, ncol=5, loc="upper right")

    # 把"被抽中但一次都没改成功"的算子直接标在图上，
    # 否则读者只会看到五组高度差不多，看不出 0 的那一根。
    # 标注框放到右侧空白区（x 轴末尾那几个算子本来就只有几十次），
    # 不放在柱子上方，避免压住相邻的 probed 柱。
    for i, r in enumerate(per):
        if r["chosen"] > 0 and r["changed"] == 0:
            ax.annotate(f"{r['name']}：被抽中 {r['chosen']} 次，改成功 0 次\n"
                        f"（它只把字典键序重排，字段值一个都没改）",
                        xy=(i + 0.06, r["probed"]), xytext=(len(names) * 0.52,
                                                           mat.max() * 0.72),
                        fontsize=8.6, color=C_BAD, ha="left",
                        bbox=dict(boxstyle="round,pad=0.42", fc="#FFF5F5",
                                  ec=C_BAD, lw=0.9),
                        arrowprops=dict(arrowstyle="->", color=C_BAD, lw=1.1,
                                        connectionstyle="arc3,rad=-0.18"))

    a = R["E0_activation"]
    bve = a["branch_vs_effect"]
    foot(fig,
         f"★ 共 {a['n_ops_total']} 个算子：被抽中 {a['n_chosen']}、真的改了字段 {a['n_changed']}、"
         f"变化合标签 {a['n_on_label']}。三个数不同才是实情——"
         "key_order 只改字典键序，不改任何字段值，所以“真的变了”为 0："
         "它确实被调用过，也确实没改变任何内容。\n"
         "v2 把 self.calls 当 applied 输出，名字还叫“生效率”，撑不起“覆盖了 N 种语义扰动”。\n"
         f"分支/效果交叉表：drift 抽中却没变 {bve['drift_no_change']} 次、"
         f"rewrite 抽中却没变 {bve['rewrite_no_change']} 次、replay 却变了 {bve['replay_changed']} 次。"
         "照抄分支标签会凭空造出这些“变义被吞”与“保义误杀”，本版一律以实际变化为准。",
         y=0.055)
    fig.tight_layout(rect=(0, 0.13, 1, 1))
    fig.savefig(os.path.join(FIG, "fig7_operator_activation.png"))
    plt.close(fig)


# --------------------------------------------------------------------------
# 图 8 成本模型校验：二维帕累托
# --------------------------------------------------------------------------
def fig8():
    pts = R["E10_cost_model"]["points"]
    n_off = R["E10_cost_model"]["n_off_pareto"]
    ngrid = R["E10_cost_model"]["n_grid"]

    fig, ax = plt.subplots(figsize=(10.4, 6.2))

    # 同坐标的点会被完全盖住（仅 SAFE 与 槽位投影(无替代) 都是 11.25, 0.00）。
    # 按 (dup, miss) 分组，一组只画一个点，标签合并，并在图注里写明。
    groups = {}
    for p in pts:
        k = (round(p["dup"], 3), round(p["miss"], 3))
        groups.setdefault(k, {"pt": p, "names": []})
        groups[k]["names"].append(p["strategy"])
    n_collapsed = sum(len(g["names"]) - 1 for g in groups.values())

    # 标签落点手工指定：自动避让在这个尺度上会来回打架，
    # 四点位置是固定的（数据决定），一次排好更可靠。
    # ★ 第四轮：主指标换成"仅保义重复代价"后 x 坐标全变了，这里跟着改。
    KEY = {
        (1.875, 19.2): dict(xytext=(26, -4), ha="left", va="center"),
        (3.75, 0.0): dict(xytext=(6, 46), ha="center", va="bottom"),
        (7.625, 0.0): dict(xytext=(16, 16), ha="left", va="bottom"),
        (35.375, 3.1): dict(xytext=(-10, 14), ha="right", va="bottom"),
    }

    for (gd, gm), g in sorted(groups.items(), key=lambda kv: kv[0]):
        p = g["pt"]
        on = p["pareto"]
        ax.scatter(gd, gm, s=210 if on else 130,
                   c=C_SAFE if on else C_GREY, zorder=4 if on else 3,
                   edgecolors="white", linewidths=1.5)
        if len(g["names"]) > 1:
            label = " ／ ".join(g["names"]) + "\n（两者坐标完全相同，重叠绘制）"
        else:
            label = g["names"][0]
        kw = KEY.get((gd, gm), dict(xytext=(12, 10), ha="left", va="bottom"))
        ax.annotate(label, (gd, gm), textcoords="offset points",
                    fontsize=8.8,
                    color=C_DARK if on else C_TXT,
                    fontweight="bold" if on else "normal",
                    arrowprops=dict(arrowstyle="-", color="#CBD5E0", lw=0.8,
                                    shrinkA=0, shrinkB=6)
                    if len(g["names"]) > 1 else None, **kw)

    front = sorted([g["pt"] for g in groups.values() if g["pt"]["pareto"]],
                   key=lambda x: x["dup"])
    if len(front) > 1:
        ax.plot([p["dup"] for p in front], [p["miss"] for p in front],
                color=C_SAFE, ls="--", lw=1.4, alpha=0.7, zorder=2,
                label="帕累托前沿（连线只为看清谁被谁支配）")
        ax.legend(fontsize=8.8, frameon=False, loc="center left",
                  bbox_to_anchor=(0.30, 0.62))

    ax.set_xlim(0.2, 40.0)
    ax.set_ylim(-2.6, 22.5)
    style(ax, "二维帕累托：不靠总分也能排序",
          xlabel="保义重复代价 dup（只数该复用却拆开）",
          ylabel="漏做/错吃代价 miss", grid_axis="both")
    # 方向说明放右下角的空白区，右上角已经被前沿线占住
    ax.annotate("越靠左下越好\n左下 = 又少重复又少漏做", xy=(0.985, 0.055),
                xycoords="axes fraction", fontsize=9, color=C_TXT,
                ha="right", va="bottom",
                bbox=dict(boxstyle="round,pad=0.4", fc="#F7FAFC",
                          ec="#CBD5E0", lw=0.8))

    foot(fig,
         "★ 这张图替代 v2 的“总代价”柱。用总分排序需先声明可加模型"
         f"（COST_MODEL='{R['E10_cost_model']['cost_model']}'，"
         f"单位“{R['E10_cost_model']['unit']}”）与 A1–A5 五条假设；"
         f"在二维平面上排序不需要这些假设。\n"
         f"校验：{ngrid} 个出现率组合（p_retry × p_conflict）里，按总分选出的最优策略"
         f"落在前沿上的比例 = {ngrid - n_off}/{ngrid}（off-pareto {n_off} 个）。"
         "一致说明可加假设在这批数据上没把结论带偏；不一致就说明假设不成立。\n"
         f"本图有 {n_collapsed} 处坐标完全相同的策略被合并绘制（仅 SAFE 与槽位投影(无替代) "
         "都是 dup=7.63 / miss=0.00），已在标签里注明——否则读者会以为少画了两个点。",
         y=-0.05)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig8_pareto_check.png"))
    plt.close(fig)


def main():
    for fn in (fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8):
        fn()
        print(f"{fn.__name__} ok")


if __name__ == "__main__":
    main()