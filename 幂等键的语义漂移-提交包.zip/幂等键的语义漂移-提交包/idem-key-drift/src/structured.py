"""
structured.py — 槽位投影：键只由 **契约声明的字段** 构成。

v1 的三个缺陷与本版的对应改法
-----------------------------
缺陷 1：extract_slots(tool, args) 收了 tool 却不读 schema，硬编码
        station/month/region/to/subject 五个字段，于是 universe.py 里声明过的
        body_ref / res / coverage / include_qc / include_flag_dist / cores
        全部被无视。审阅方用"同收件人同主题不同 body_ref"和"不同 res 的落格"
        两撞即中。
    改法：字段集**只**来自 contract.FIELD_CONTRACT，并有 contract_check
        逐字段验证"改一下就换键"。忽略字段必须写进 IGNORABLE_FIELDS 并给理由。

缺陷 2：残余路径 `re.sub(r"D", " ", r)` 把所有数字删掉，导致
        "温度偏差1度" vs "温度偏差2度"、"8月3日" vs "8月9日" 同键。
    改法：**取消残余这个概念**。自由文本字段不是"抽完槽位后扔掉"，而是
        走带守卫的替代（见下）；替代不成立时**原样保留**。既然原样保留，
        就没有任何"归一化"能吃掉数字。

缺陷 3：键里没有工具命名空间，跨工具撞击被"评估时跳过"掩盖。
    改法：键 = tool + "|" + 字段字典。

带守卫的替代（本版的核心，也是 v1 最需要被纠正的地方）
----------------------------------------------------
v1 的立场是"自由文本永不进键"。这个立场本身就是错的：job_name 里
`_partial` / `_S07only` 是真实差别，直接丢弃等于把"只重算 S07"和
"全部重算"判成同一件事——这正是 report 里批判的错合并。

本版的立场是：**只有当字段的全部内容都能由已声明的结构化字段解释时，
才允许把它替换成结构化形式；一旦有解释不了的残余，必须原样保留。**

这样：
  recompute_S07_2026-08   → ⟦recompute|S07|2026-08⟧   （可解释，合并）
  RECOMPUTE-S07-202608    → ⟦recompute|S07|2026-08⟧   （同上，换个写法）
  重算_S07_2026-08        → ⟦recompute|S07|2026-08⟧   （同上，换中文动词）
  recompute_S07_2026-08_partial → 保留原文                （残余 partial，不合并）

即：槽位投影的收益来自"同一件事的不同写法"，风险则被守卫挡在门外。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

import contract as C
from policy import KeyPolicy, norm_field, safe_schema_project
from universe import TOOLS


# --------------------------------------------------------------------------
# 槽位抽取：字段集来自契约，不来自硬编码
# --------------------------------------------------------------------------

def extract_slots(tool: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """
    按契约抽取槽位。

    对每个声明字段：
      · 先按字段类别归一（month/station/region/bool/int/text）；
      · 若该字段在 DERIVED_FROM 里，走 canon_dict() 得到**带类型标签**的表示：
          {"kind": "derived", "value": "recompute|S07|2026-08"}   替代成功
          {"kind": "raw",     "value": "<原文>"}                  守卫不通过
      · 其余字段保留归一后的原值（数字、语序、否定词全部保留）。

    ★ 第三轮改动：键里的字段值不再是裸字符串。
      第二版把 job_name 换成 ⟦...⟧ 字面量，用户原文若恰好就是这个串会直接撞上。
      现在 derived 与 raw 在 JSON 结构上就不同（都是 dict，kind 不同，value 语义不同），
      所以"用户输入恰好等于内部标记"这条路被物理切断，不依赖特殊符号的稀缺性。
    """
    if tool not in C.FIELD_CONTRACT:
        raise KeyError(f"工具 {tool} 未在契约中声明字段")

    projected = safe_schema_project(tool, args)
    slots: Dict[str, Any] = {}
    declared = {k: norm_field(tool, k, projected.get(k)) for k in C.key_fields(tool)}

    for f in C.key_fields(tool):
        v = projected.get(f)
        nv = norm_field(tool, f, v)
        if (tool, f) in C.DERIVED_FROM:
            slots[f] = C.canon_dict(tool, f, nv, declared)
        else:
            slots[f] = nv

    return slots


# --------------------------------------------------------------------------
# 策略
# --------------------------------------------------------------------------

class StructuredKey:
    """
    槽位投影键。

    参数
    ----
    derive : 是否启用带守卫的替代（False 时等价于"只按字段归一"，用作消融基线）
    """

    def __init__(self, tool: str, derive: bool = True):
        self.tool = tool
        self.derive = derive

    def slots(self, args: Dict[str, Any]) -> Dict[str, Any]:
        if self.derive:
            return extract_slots(self.tool, args)
        # 消融：不替代，纯字段归一（安全但无法合并"作业名换写法"）
        projected = safe_schema_project(self.tool, args)
        return {f: norm_field(self.tool, f, projected.get(f))
                for f in C.key_fields(self.tool)}

    def key(self, args: Dict[str, Any]) -> str:
        body = json.dumps(self.slots(args), ensure_ascii=False, sort_keys=True,
                          separators=(",", ":"))
        return f"{self.tool}{C.KEY_NAMESPACE_SEP}{body}"


# --------------------------------------------------------------------------
# 策略注册表：所有可比方案都从这里取，避免"每个实验自己写一份 keyfn"
# --------------------------------------------------------------------------

def bare_key(tool: str, args: Dict[str, Any]) -> str:
    """裸参数哈希 —— 课件字面做法（键 = 参数哈希）。不带命名空间，故意保留原样。"""
    return json.dumps(args, ensure_ascii=False, sort_keys=True, default=str)


def safe_key(tool: str, args: Dict[str, Any]) -> str:
    return KeyPolicy(tool, 0.0).key(args)


def risky_all_key(tool: str, args: Dict[str, Any]) -> str:
    return KeyPolicy(tool, 1.0).key(args)


def slot_key(tool: str, args: Dict[str, Any]) -> str:
    return StructuredKey(tool, derive=True).key(args)


def slot_noderive_key(tool: str, args: Dict[str, Any]) -> str:
    return StructuredKey(tool, derive=False).key(args)


def opid_key(tool: str, args: Dict[str, Any], op_id: str = "") -> str:
    """持久化操作 ID 基线：键 = 应用侧生成并保存的 op_id，与参数无关。"""
    return f"opid{C.KEY_NAMESPACE_SEP}{op_id}"


STRATEGIES: Dict[str, Any] = {
    "bare": bare_key,
    "safe": safe_key,
    "risky_all": risky_all_key,
    "slot": slot_key,
    "slot_noderive": slot_noderive_key,
}


if __name__ == "__main__":
    from evaluate import make_episodes

    print("=" * 96)
    print("槽位投影示例：同一个逻辑操作的 5 种写法")
    print("=" * 96)
    eps = make_episodes(seed=0)
    ep = next(e for e in eps if e.op.tool == "submit_batch_job")
    sk = StructuredKey(ep.op.tool)
    for v in ep.variants:
        print(f"  {json.dumps(v, ensure_ascii=False)}")
        print(f"    slots: {json.dumps(sk.slots(v), ensure_ascii=False)}")
        print(f"    key  : {sk.key(v)}")

    print("\n" + "=" * 96)
    print("守卫演示：范围收窄必须拒绝替代")
    print("=" * 96)
    base = {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-08"}
    for jn in ("recompute_S07_2026-08", "RECOMPUTE-S07-202608",
               "重算_S07_2026年8月", "recompute_S07_2026-08_partial"):
        a = {**base, "job_name": jn}
        print(f"  {jn:34s} → {sk.key(a)}")