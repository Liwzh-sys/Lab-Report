"""
perturb.py — 把"一个逻辑操作"展开成"多次重试里模型实际写出的参数"。

本版相对 v1 的三处改动（都直接对应审阅意见）
-------------------------------------------
1. **MonthSyn 不再是手写的第二份真相源**，而是由 contract.MONTH_EQUIV 生成。
   v1 在这里放了 "2026-08-01" 和裸 "8月"，等于把日精度与缺年份写法
   标成"保义"，而 structured.py 又说月/日精度不能合并——标准自己打自己。

2. **保留原样重放**。v1 的 variants() 用序列化结果去重，尽量凑出 n 个
   不同的变体。真实重试里相当大比例是"参数一字不改地重放"。
   去重会把这类样本全部滤掉，于是数据集估的是"专门挑出不同写法之后的表现"，
   裸哈希的损失被人为放大——这是"槽位投影更好"整个论证的地基。
   本版改为**三项概率显式分开**：原样重放 / 保义改写 / 真实参数变化。

3. **算子真的会被调用，且调用次数可查**。v1 的 DriftOp.weight 从未被使用
   （rng.sample 不看权重），op_bool_as_str 把 False 也写成"真"，
   _applicable 的 except Exception 静默吞掉 NameError 长达整个第一版。
   本版：权重删掉（不打算用就不要留装饰品）；被调用次数逐算子计数；
   异常不再静默，会计入 op_errors 并打印。
"""

from __future__ import annotations

import copy
import json
import random
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import contract as C
from universe import LogicalOp, MONTHS, REGIONS, STATIONS, TOOLS

# --------------------------------------------------------------------------
# 保义写法表：**全部由契约派生**
# --------------------------------------------------------------------------

RegionSyn: Dict[str, List[str]] = {}
for _canon in REGIONS:
    _alts = [k for k, v in C.REGION_ALIAS.items() if v == _canon and k != _canon]
    RegionSyn[_canon] = _alts

# 只对基准月份构造；替代写法全部来自 MONTH_EQUIV（同精度内闭合）
MonthSyn: Dict[str, List[str]] = {
    m: list(C.MONTH_EQUIV.get(m, ())) for m in MONTHS
}

StationSyn: Dict[str, List[str]] = {}
for _canon in STATIONS:
    _alts = [k for k, v in C.STATION_ALIAS.items() if v == _canon and k != _canon]
    StationSyn[_canon] = _alts

NoteSyn = {k: list(v) for k, v in C.NOTE_EQUIV.items()}
# ★ 第三轮：NoteSyn 不再是生成器私有的第二份真相源（审阅方第七节（一））。
#   它现在由 contract.NOTE_EQUIV 派生，和月份/区域/站号别名同等待遇。

# 变义算子使用的目标值（必须与基准值不同，才能构成真实差异）
DECOY_MONTHS_FOR_DRIFT = ["2026-11", "2026-12"]

# 每个变义算子声明它**声称**改动的字段。用于在生成之后核对
# "这条样本真的改了它说要改的东西吗"——不核对的话，算子返回 None
# 或者链没跑起来时，一条"变义"样本其实什么都没变，却会被记成变义。
CHANGE_TARGET: Dict[str, str] = {
    "scope_drift": "job_name",
    "assert_strength": "note",
    "month_shift": "month",
    "station_shift": "station",
}


def _maybe(rng: random.Random, p: float) -> bool:
    return rng.random() < p


def _diff_fields(a: Dict[str, Any], b: Dict[str, Any]) -> tuple:
    """逐字段比较两份参数，返回真的变了的字段名（有序）。"""
    keys = set(a) | set(b)
    return tuple(sorted(k for k in keys if a.get(k) != b.get(k)))


def _matches_label(op: "DriftOp", tool: Optional[str],
                   before: Dict[str, Any], after: Dict[str, Any],
                   changed: tuple) -> bool:
    """
    这次变化符合算子的 kind 声明吗？判据一律来自 **contract.contract_equiv**，
    不在本文件里另写一套"我觉得等价"。

    · equiv   声称保义：每个变了的字段都必须 contract_equiv 保义。
    · change  声称变义：`CHANGE_TARGET` 声明的主字段必须在 changed 里，
              且该字段**不是** contract_equiv 保义的（真变了）。
    """
    if not changed:
        return False
    if op.kind == "change":
        tgt = CHANGE_TARGET.get(op.name)
        if tgt is None:
            return True
        if tgt not in changed:
            return False
        return not C.contract_equiv(tool or "", tgt, before.get(tgt), after.get(tgt))
    for f in changed:
        if not C.contract_equiv(tool or "", f, before.get(f), after.get(f)):
            return False
    return True


# --------------------------------------------------------------------------
# 算子
# --------------------------------------------------------------------------

@dataclass
class DriftOp:
    """
    一条漂移算子。

    kind:
      "equiv"  —— 保义。语义相同，只是写法不同。规范化应抹平它。
      "change" —— 变义。语义已变。规范化绝不能抹平它。

    tool:
      可选。需要读 schema 的算子（materialize_default）用它取该工具的
      真默认值。**不使用 functools.partial** —— v1 用 partial 绑定 tool
      时把 rng 的位置参数吃掉，算子在探测阶段全部报错、被 except 静默吞掉，
      表现就是"声称 11 个算子、实际只跑 9 个"。

    v1 还有一个 weight 字段，被赋予"先验权重"的名义但从未参与抽样。
    本版删除：如果不用，就不该出现在清单里假装有信息量。
    """
    name: str
    kind: str
    apply: Callable[[random.Random, Dict[str, Any]], Optional[Dict[str, Any]]]
    note: str = ""
    needs_tool: bool = False

    def run(self, rng: random.Random, s: Dict[str, Any],
            tool: Optional[str] = None) -> Optional[Dict[str, Any]]:
        if self.needs_tool:
            return self.apply(rng, s, tool=tool)
        return self.apply(rng, s)

    def bind(self, tool: Optional[str]) -> "DriftOp":
        return self


# ---- 保义算子 -------------------------------------------------------------

def op_key_order(rng, s):
    if len(s) < 2:
        return None
    items = list(s.items())
    rng.shuffle(items)
    return dict(items)


def op_region_synonym(rng, s):
    if "region" not in s or s["region"] not in RegionSyn or not RegionSyn[s["region"]]:
        return None
    return {**s, "region": rng.choice(RegionSyn[s["region"]])}


def op_month_format(rng, s):
    if "month" not in s or not MonthSyn.get(s["month"]):
        return None
    return {**s, "month": rng.choice(MonthSyn[s["month"]])}


def op_station_case(rng, s):
    if "station" not in s or not StationSyn.get(s["station"]):
        return None
    return {**s, "station": rng.choice(StationSyn[s["station"]])}


def op_num_as_str(rng, s, tool: Optional[str] = None):
    """
    数字写成字符串，或整数写成浮点。只对数值字段。

    为什么需要 tool：基准操作里**根本没有**显式数值字段（cores 是 optional，
    基准不写）。若只对"已存在的 int"生效，这个算子永远是死代码——这正是
    v1 "说有 11 个算子实际没跑那么多" 的一半原因。
    有 tool 时，先把该工具的数值型默认值展开（模拟模型顺手写出默认值），
    再把它写成字符串。这是真实重试里常见的一种写法。
    """
    out = dict(s)
    hit = False
    for k, v in list(s.items()):
        if isinstance(v, int) and not isinstance(v, bool):
            out[k] = rng.choice([str(v), float(v)])
            hit = True
    if not hit and tool in TOOLS:
        ints = {k: d for k, d in TOOLS[tool]["optional"].items()
                if isinstance(d, int) and not isinstance(d, bool)}
        if ints and rng.random() < 0.7:
            k, v = rng.choice(list(ints.items()))
            out[k] = rng.choice([str(v), float(v)])
            hit = True
    return out if hit else None


def op_bool_as_str(rng, s, tool: Optional[str] = None):
    """
    布尔写成字符串。**必须看原值**：v1 不管 True 还是 False 都挑"真"的
    表示（true/True/1/是），一旦碰上 False 就把 False 变成了 True，
    "保义"声明当场崩掉。本版按原值取对应词表。

    同样支持从工具默认值里取布尔字段（基准操作不带 include_qc 等）。
    """
    out = dict(s)
    hit = False
    for k, v in s.items():
        if isinstance(v, bool):
            out[k] = rng.choice(["true", "True", "1", "是"]) if v \
                else rng.choice(["false", "False", "0", "否"])
            hit = True
    if not hit and tool in TOOLS:
        bools = {k: d for k, d in TOOLS[tool]["optional"].items()
                 if isinstance(d, bool)}
        if bools and rng.random() < 0.7:
            k, v = rng.choice(list(bools.items()))
            out[k] = rng.choice(["true", "True", "1", "是"]) if v \
                else rng.choice(["false", "False", "0", "否"])
            hit = True
    return out if hit else None


def op_materialize_default(rng, s, tool: Optional[str] = None):
    """
    把 schema 默认值显式写出来。语义不变。

    **只能用该工具自己的 optional 表**。v1 用一张全局默认表（res/coverage/
    cores/include_qc/...），结果 submit_batch_job 被塞进 res=7、
    coverage=all_intersecting，geocode_region 被塞进 cores=32——这些字段
    该工具的 schema 里根本没有。那不是"展开默认值"，那是凭空造参数。
    """
    out = dict(s)
    if tool in TOOLS:
        defaults = dict(TOOLS[tool]["optional"])
    else:
        defaults = {}
    filled = False
    for k, dflt in defaults.items():
        if k not in out and rng.random() < 0.75:
            out[k] = dflt
            filled = True
    return out if filled else None


def op_extra_noise(rng, s):
    """加无意义的附加字段（trace id、模型自我说明）。"""
    return {**s,
            "__trace": f"req-{rng.randint(1000, 9999)}",
            "__note": "retrying after timeout"}


def op_whitespace(rng, s, tool: Optional[str] = None):
    """
    空白/前后缀扰动。**只对契约声明"可折叠空白"的字段生效。**

    ★ 第三轮修正。第二版对所有字符串字段一律加空白，包括 write_qc_note 的
      note。而契约（WHITESPACE_FOLDABLE）明确规定 note 是"人写的正文，
      逐字保留"。结果这条"保义算子"造出来的样本里，有 200 条左右其实是
      真实变义——笔记的首尾空白与连续空白被当成了噪声。
      这正是审阅方那条空白探针在语料层面的同一个病：生成器与契约说的不是
      同一件事。现在生成器去问契约，不再自己拍板。
    """
    out = {}
    hit = False
    for k, v in s.items():
        if isinstance(v, str) and (tool is None or C.may_fold_whitespace(tool, k)):
            out[k] = rng.choice([f" {v}", f"{v} ", v.replace(" ", "  ")])
            hit = True
        else:
            out[k] = v
    return out if hit else None


def op_note_paraphrase(rng, s):
    """备注换个说法，意思不变。"""
    if "note" not in s or not isinstance(s["note"], str):
        return None
    n = s["note"]
    for k, alts in NoteSyn.items():
        if k in n:
            return {**s, "note": n.replace(k, rng.choice(alts))}
    return {**s, "note": n + "（建议复核）"}


def op_jobname_style(rng, s):
    """作业名换写法：大小写、连接符、中文动词。语义不变。"""
    if "job_name" not in s or not isinstance(s["job_name"], str):
        return None
    jn = s["job_name"]
    cands = [jn.upper(), jn.replace("_", "-"),
             jn.replace("recompute", "重算"), jn.replace("recompute_", "recalc_")]
    cands = [c for c in cands if c != jn]
    if not cands:
        return None
    return {**s, "job_name": rng.choice(cands)}


# ---- 变义算子（模型真的会写错，属于"重规划"，不是重试） ------------------

def op_scope_drift(rng, s):
    """范围从"全部"悄悄缩成"部分"。真变义。"""
    if "job_name" not in s or not isinstance(s["job_name"], str):
        return None
    return {**s, "job_name": s["job_name"] + "_partial"}


def op_assert_strength(rng, s):
    """'疑似' → '确认'。措辞差一个字，责任差一个量级。"""
    if "note" not in s or not isinstance(s["note"], str):
        return None
    if "疑似" not in s["note"] and "可能存在" not in s["note"]:
        return None
    return {**s, "note": s["note"].replace("疑似", "确认").replace("可能存在", "已确认")}


def op_month_shift(rng, s):
    """月份真的改了（重规划到另一个月）。真变义。"""
    if "month" not in s or s["month"] not in MONTHS:
        return None
    return {**s, "month": rng.choice(DECOY_MONTHS_FOR_DRIFT)}


def op_station_shift(rng, s):
    """站号真的改了（重规划到另一个站）。真变义。"""
    if "station" not in s or s["station"] not in STATIONS:
        return None
    alts = [x for x in STATIONS if x != s["station"]]
    return {**s, "station": rng.choice(alts)}


EQUIV_OPS: List[DriftOp] = [
    DriftOp("key_order", "equiv", op_key_order, "字典键序不同"),
    DriftOp("region_synonym", "equiv", op_region_synonym, "区域名同义/简写/英译"),
    DriftOp("month_format", "equiv", op_month_format, "月份同精度换写法"),
    DriftOp("station_case", "equiv", op_station_case, "站号大小写/前缀"),
    DriftOp("num_as_str", "equiv", op_num_as_str, "数字写成字符串或浮点",
            needs_tool=True),
    DriftOp("bool_as_str", "equiv", op_bool_as_str, "布尔写成字符串（按原值）",
            needs_tool=True),
    DriftOp("materialize_default", "equiv", op_materialize_default,
            "显式写出默认值（按该工具 schema）", needs_tool=True),
    DriftOp("extra_noise", "equiv", op_extra_noise, "塞入无意义附加字段"),
    DriftOp("whitespace", "equiv", op_whitespace,
            "空白/前后缀（仅契约声明可折叠的字段）", needs_tool=True),
    DriftOp("note_paraphrase", "equiv", op_note_paraphrase, "备注换同义说法"),
    DriftOp("jobname_style", "equiv", op_jobname_style, "作业名大小写/连接符/中文动词"),
]

CHANGE_OPS: List[DriftOp] = [
    DriftOp("scope_drift", "change", op_scope_drift, "范围从全体缩成部分"),
    DriftOp("assert_strength", "change", op_assert_strength, "断言强度'疑似'→'确认'"),
    DriftOp("month_shift", "change", op_month_shift, "月份真的改到另一个月"),
    DriftOp("station_shift", "change", op_station_shift, "站号真的改到另一个站"),
]


# --------------------------------------------------------------------------
# 采样器
# --------------------------------------------------------------------------

@dataclass
class SampleConfig:
    """
    三项概率显式分开。v1 把前两项混在"凑 n 个不同变体"里，无法区分。

    p_replay   : 原样重放（参数一字不改）—— 真实重试里最常见
    p_rewrite  : 保义改写（同一件事换个写法）—— 智能体特有的问题
    p_drift    : 真实参数变化（重规划）—— 属于"同意图不同参数"，需要契约校验
    三者按概率抽一个分支；p_drift=0 时即"纯重试"场景。

    dedup      : **仅用于复现 v1 的采样偏置**，默认关闭。
                 v1 的 variants() 用序列化结果去重、尽量凑 n 个不同变体，
                 等于估计"专门挑出不同写法之后的表现"，不是自然重试分布。
                 保留这个开关，是为了在同一套数据上量化"去重把裸哈希的
                 损失放大了多少"——这是审阅方最在意的那 91.3% 的地基。
    """
    p_replay: float = 0.35
    p_rewrite: float = 0.55
    p_drift: float = 0.10
    k_min: int = 1
    k_max: int = 4
    dedup: bool = False

    def __post_init__(self):
        tot = self.p_replay + self.p_rewrite + self.p_drift
        if abs(tot - 1.0) > 1e-9:
            raise ValueError(f"三项概率之和必须为 1，实得 {tot}")


class RuleBasedPerturber:
    """可控模拟台。给定规范槽位，生成一次"重试时模型实际写出的参数"。"""

    def __init__(self, seed: int = 0, cfg: Optional[SampleConfig] = None,
                 equiv_only: bool = False):
        self.rng = random.Random(seed)
        self.cfg = cfg or SampleConfig()
        self.equiv_ops = list(EQUIV_OPS)
        self.change_ops = [] if equiv_only else list(CHANGE_OPS)
        # 逐算子计数（审阅方第六节（三）要"五个数分开记"）
        #   probed   适用性探测判定为适用
        #   chosen   在链上真的被抽中
        #   returned run() 返回非 None
        #   changed  返回值与该步输入逐字段不同（真的改了东西）
        #   on_label 那次变化符合该算子的 kind 声明
        _names = [op.name for op in EQUIV_OPS + CHANGE_OPS]
        self.attempts: Dict[str, int] = {n: 0 for n in _names}
        self.probed: Dict[str, int] = {n: 0 for n in _names}
        self.chosen: Dict[str, int] = {n: 0 for n in _names}
        self.returned: Dict[str, int] = {n: 0 for n in _names}
        self.changed: Dict[str, int] = {n: 0 for n in _names}
        self.on_label: Dict[str, int] = {n: 0 for n in _names}
        self.changed_fields: Dict[str, set] = {n: set() for n in _names}
        self.errors: Dict[str, int] = {}
        self.branch_counts = {"replay": 0, "rewrite": 0, "drift": 0}
        # 分支标签与"真的变了"的交叉表：两者不一致的次数必须能看见
        self.branch_vs_effect = {
            "drift_no_change": 0,     # 抽中 drift，但参数一个字段都没变
            "rewrite_no_change": 0,   # 抽中 rewrite，但参数一个字段都没变
            "replay_changed": 0,      # 抽中 replay，却变了（应为 0）
        }

    # -- 适用性探测 ---------------------------------------------------------
    def _applicable(self, ops, s: Dict[str, Any],
                    tool: Optional[str] = None) -> List[DriftOp]:
        """
        只挑对这个槽位组合**真的适用**的算子。

        探测必须用**独立的探针 RNG**：探测会消耗随机数，若与正式生成共用
        同一个 rng，"适用性探测"就会改变后续抽样结果——同一个 seed 下
        换个算子顺序就得到不同数据。分开之后 perturb() 的随机流才纯净。

        但探针**不能每条算子都用同一个种子**：
        `random.Random(0x5EED).random()` 的值是固定常数（约 0.709），
        凡是内部用 `rng.random() < p` 判定的算子（materialize_default 的
        p=0.6）就永久被判为"不适用"，生效次数恒为 0——而这正是审阅方
        在四（二）里说的"说有 11 个算子、实际没跑那么多"。
        本版给每条算子派生不同的探针种子，并额外做多次抽样：
        只要**至少一次**能产出结果，就算适用。
        """
        out = []
        for idx, op in enumerate(ops):
            ok = False
            for trial in range(4):
                probe = random.Random(0x5EED + 1009 * idx + 7919 * trial)
                try:
                    r = op.run(probe, copy.deepcopy(s), tool=tool)
                except Exception as e:                      # 不再静默
                    key = f"{op.name}:{type(e).__name__}"
                    self.errors[key] = self.errors.get(key, 0) + 1
                    r = None
                if r is not None:
                    ok = True
                    break
            self.attempts[op.name] += 1
            if ok:
                self.probed[op.name] += 1
                out.append(op)
        return out

    def _apply_chain(self, ops: List[DriftOp], s: Dict[str, Any],
                     tool: Optional[str] = None) -> Dict[str, Any]:
        """
        顺序链：**每应用一步就重新探测剩余算子的适用性**。

        v1 是"变换前一次性判断适用性"，后果是 num_as_str / bool_as_str
        永远轮不到：基准操作里没有显式数值/布尔字段，只有 materialize_default
        把默认值展开之后它们才适用。于是"11 个保义算子"实际只跑了 9 个。

        逐词重探测之后，一条链可以是：
            materialize_default（展开 cores=64）→ num_as_str（64 → "64"）
        这才是"重试时模型会怎么写"的真实形态。

        ★ 第三轮：五个计数分开记（审阅方第六节（三））。
        第二版在执行算子**之前**就 `self.calls += 1`，又把它当"生效"输出。
        可算子可能返回 None，也可能返回一个和输入相等的字典（比如只改了键序）。
        所以"15/15 生效"最多只能支撑"15 个算子都被调用过"。
        现在分开记：
          probed    —— 适用性探测时就判定它适用
          chosen    —— 在链上真的被抽中
          returned  —— run() 返回了非 None
          changed   —— 返回值与该步输入**逐字段不同**
          on_label  —— 那次变化符合该算子的 kind 声明
        """
        if not ops:
            return dict(s)
        cur = copy.deepcopy(s)
        remaining = list(ops)
        k = self.rng.randint(self.cfg.k_min, min(self.cfg.k_max, len(remaining)))
        done = 0
        while remaining and done < k:
            applicable = self._applicable(remaining, cur, tool)
            if not applicable:
                break
            op = self.rng.choice(applicable)
            remaining = [x for x in remaining if x.name != op.name]
            self.chosen[op.name] += 1
            r = op.run(self.rng, cur, tool=tool)
            if r is None:
                continue
            self.returned[op.name] += 1
            d = _diff_fields(cur, r)
            if d:
                self.changed[op.name] += 1
                self.changed_fields[op.name].update(d)
                if _matches_label(op, tool, cur, r, d):
                    self.on_label[op.name] += 1
            cur = r
            done += 1
        return cur

    def _ops_for(self, ops: List[DriftOp],
                 tool: Optional[str]) -> List[DriftOp]:
        """
        绑定工具上下文。materialize_default 必须知道工具才能取该工具 schema
        里的真默认值——v1 用一张全局默认表，导致 geocode_region 被塞进
        cores/include_qc 这类该工具根本没有的字段。

        本版不再用 functools.partial 绑定（那会吃掉 rng 的位置参数），
        而是把 tool 作为 run() 的具名参数传下去。
        """
        if tool is None:
            return [op for op in ops if not op.needs_tool]
        return ops

    def sample(self, slots: Dict[str, Any], tool: Optional[str] = None) -> Dict[str, Any]:
        """
        生成**一次**重试的参数。不做任何去重——重复是数据的一部分。
        """
        return self.sample_tagged(slots, tool=tool)[0]

    def sample_tagged(self, slots: Dict[str, Any],
                      tool: Optional[str] = None) -> Tuple[Dict[str, Any], str, tuple]:
        """
        生成一次重试，并**同时返回它的分支标签**。

        ★ 第三轮新增。这是审阅方第四节（一）的直接要求：
          "生成器知道什么叫变义，评估器不知道" —— 标签在中间被扔了。

        返回 (参数, 分支, 真的变了的字段)
          分支 ∈ {"replay", "rewrite", "drift"}
          真的变了的字段 = 与传入 slots 逐字段比较的结果

        为什么要回传"真的变了的字段"而不是直接相信分支标签：
        `_apply_chain` 在链上算子全部不适用时会**原样返回 dict(s)**，
        这时分支计数已经 +1 了 drift，但参数一个字段都没变。
        如果照抄分支标签，这条样本会被记成"真实变义"，而它其实什么都没变——
        评估器就会因为"键相同"把它算成"变义被吞掉"，凭空造出一个事故。
        本版以"字段是否真的变了"为准，分支标签只作为采样意图保留。
        """
        u = self.rng.random()
        c = self.cfg
        if u < c.p_replay:
            self.branch_counts["replay"] += 1
            out = copy.deepcopy(slots)
            d = _diff_fields(slots, out)
            if d:
                self.branch_vs_effect["replay_changed"] += 1
            return out, "replay", d

        if u < c.p_replay + c.p_rewrite:
            self.branch_counts["rewrite"] += 1
            ops = self._ops_for(self._applicable(self.equiv_ops, slots, tool), tool)
            out = self._apply_chain(ops, slots, tool)
            d = _diff_fields(slots, out)
            if not d:
                self.branch_vs_effect["rewrite_no_change"] += 1
            return out, "rewrite", d

        self.branch_counts["drift"] += 1
        ops = self._ops_for(self._applicable(self.change_ops, slots, tool), tool)
        out = self._apply_chain(ops, slots, tool)
        d = _diff_fields(slots, out)
        if not d:
            self.branch_vs_effect["drift_no_change"] += 1
        return out, "drift", d

    def branches(self, slots: Dict[str, Any], n: int,
                 tool: Optional[str] = None) -> List[Tuple[Dict[str, Any], str, tuple]]:
        """n 次抽样的 (参数, 分支, 变化字段) 三元组。dedup 只影响是否去重。"""
        if not self.cfg.dedup:
            return [self.sample_tagged(slots, tool=tool) for _ in range(n)]
        seen, out = set(), []
        for _ in range(n * 8):
            if len(out) >= n:
                break
            v = self.sample_tagged(slots, tool=tool)
            sig = json.dumps(v[0], sort_keys=True, ensure_ascii=False)
            if sig not in seen:
                seen.add(sig)
                out.append(v)
        return out

    # -- 兼容 v1 接口 -------------------------------------------------------
    def perturb(self, slots: Dict[str, Any], k_min: int = 1,
                k_max: int = 4) -> Dict[str, Any]:
        saved = (self.cfg.k_min, self.cfg.k_max)
        self.cfg.k_min, self.cfg.k_max = k_min, k_max
        try:
            return self.sample(slots)
        finally:
            self.cfg.k_min, self.cfg.k_max = saved

    def variants(self, slots: Dict[str, Any], n: int,
                 tool: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        生成 n 个重试样本。

        默认**不去重**：真实重试里参数常常一字不改，去掉这些样本会让
        裸哈希的损失被系统性放大——这是"槽位投影更好"整个论证的地基。

        cfg.dedup=True 时复现 v1 行为（凑 n 个不同变体），仅供对照实验：
        它估计的是"专门挑出不同写法之后的表现"，不是自然重试分布。
        """
        if not self.cfg.dedup:
            return [self.sample(slots, tool=tool) for _ in range(n)]

        seen, out = set(), []
        for _ in range(n * 8):
            if len(out) >= n:
                break
            v = self.sample(slots, tool=tool)
            sig = json.dumps(v, sort_keys=True, ensure_ascii=False)
            if sig not in seen:
                seen.add(sig)
                out.append(v)
        return out

    def activation_table(self) -> List[Dict[str, Any]]:
        """
        五个数分开输出。名字不再叫"生效"——它测的不是同一个东西。

        `applied` 这个键保留，值等于 `changed`（**真的改了字段**的次数），
        不是调用次数。下游若还在读 applied，拿到的是一个更弱但真的成立的数。
        """
        rows = []
        for op in EQUIV_OPS + CHANGE_OPS:
            rows.append({
                "name": op.name, "kind": op.kind,
                "attempted": self.attempts[op.name],
                "probed": self.probed[op.name],
                "chosen": self.chosen[op.name],
                "returned": self.returned[op.name],
                "changed": self.changed[op.name],
                "on_label": self.on_label[op.name],
                "applied": self.changed[op.name],      # 兼容：等于 changed
                "changed_fields": sorted(self.changed_fields[op.name]),
                "note": op.note,
            })
        return rows


# --------------------------------------------------------------------------
# 键生成阶梯（rung 0–6）：保留 v1 的设计，但加命名空间、修 rung5/6 串味
# --------------------------------------------------------------------------

def _canon_month(v: Any) -> Any:
    return C.norm_month(v)


def _canon_bool(v: Any) -> Any:
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        low = v.strip().lower()
        if low in ("true", "1", "是", "yes"):
            return True
        if low in ("false", "0", "否", "no"):
            return False
    if isinstance(v, (int, float)) and v in (0, 1):
        return bool(v)
    return v


def _canon_num(v: Any) -> Any:
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        try:
            f = float(v)
            return int(f) if f.is_integer() else f
        except ValueError:
            return v
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v


def _canon_str(v: Any) -> Any:
    if not isinstance(v, str):
        return v
    s = re.sub(r"\s+", " ", v.strip())
    low = re.sub(r"\s+", "", s).lower()
    if low in C.MONTH_ALIAS:
        return C.MONTH_ALIAS[low]
    if low in C.REGION_ALIAS:
        return C.REGION_ALIAS[low]
    if low in C.STATION_ALIAS:
        return C.STATION_ALIAS[low]
    return s


class KeyLadder:
    """
    幂等键生成器阶梯。rung 越高越激进：
      0 原样 JSON + 哈希
      1 键排序 + 剔除 __ 前缀噪声
      2 + 类型归一（str→num/bool、strip、空白压缩）
      3 + 词表别名归一
      4 + 只保留 schema 声明字段；剔除显式默认值
      5 + 文本字段按归一化词袋哈希（丢标点、按词排序）
      6 + 文本字段只留骨架（丢程度副词）—— **开始危险**
    """

    DEFAULT_KEYS = {"res": 7, "coverage": "all_intersecting", "cores": 32,
                    "include_flag_dist": False, "include_qc": True,
                    "body_ref": None}

    def __init__(self, tool: str, rung: int):
        self.tool = tool
        self.rung = rung
        schema = TOOLS[tool]
        self.allowed = set(schema["required"]) | set(schema["optional"])

    def project(self, args: Dict[str, Any]) -> Dict[str, Any]:
        a = dict(args)
        if self.rung >= 1:
            a = {k: v for k, v in a.items() if not k.startswith("__")}
        if self.rung >= 2:
            a = {k: _canon_num(_canon_bool(_canon_str(v))) for k, v in a.items()}
        if self.rung >= 3:
            a = {k: (_canon_month(v) if k == "month" else _canon_str(v))
                 for k, v in a.items()}
        if self.rung >= 4:
            a = {k: v for k, v in a.items() if k in self.allowed}
            a = {k: v for k, v in a.items()
                 if not (k in self.DEFAULT_KEYS
                         and self.DEFAULT_KEYS[k] == _canon_num(_canon_bool(v)))}
        # rung5/6 都在**归一化后的原始串**上加工，互不串味。
        # v1 把 rung6 接在 rung5 的分词结果后面：'疑似'被切成'疑 似'，
        # 整词替换失效 → 本该出现的假阳性一个都不出现，结论完全反转。
        if self.rung == 5:
            a = {k: (self._bag(v) if isinstance(v, str) else v) for k, v in a.items()}
        elif self.rung >= 6:
            a = {k: (self._skeleton(v) if isinstance(v, str) else v) for k, v in a.items()}
        return {k: a[k] for k in sorted(a)}

    # 中文必须按字切，不能按 \w+ 切（\w 在 Python 里匹配 Unicode 词字符，
    # 中文整句会变成一个 token，sorted() 什么也没干，词袋退化成整句哈希）
    _TOK = re.compile(r"[a-z0-9]+|[\u4e00-\u9fff]")

    @classmethod
    def _tokens(cls, s: str) -> List[str]:
        return cls._TOK.findall(s.lower())

    @classmethod
    def _bag(cls, s: str) -> str:
        return " ".join(sorted(cls._tokens(s)))

    @classmethod
    def _skeleton(cls, s: str) -> str:
        drop = ["疑似出现", "可能存在", "疑似", "疑为", "已确认", "确认",
                "建议", "复核", "suspected", "please", "retry", "again"]
        s2 = s.lower()
        for w in drop:
            s2 = s2.replace(w, " ")
        toks = cls._tokens(s2)
        return " ".join(sorted(toks)) if toks else " "

    def key(self, args: Dict[str, Any]) -> str:
        body = json.dumps(self.project(args), ensure_ascii=False, sort_keys=True,
                          separators=(",", ":"))
        return f"{self.tool}{C.KEY_NAMESPACE_SEP}{body}"


if __name__ == "__main__":
    from universe import build_baseline_ops

    ops = build_baseline_ops()
    p = RuleBasedPerturber(seed=42)
    print("=== 漂移算子清单 ===")
    for op in EQUIV_OPS + CHANGE_OPS:
        print(f"  [{op.kind:6s}] {op.name:22s} {op.note}")

    print("\n=== 同一个逻辑操作的 8 次重试（**保留重复**）===")
    demo = next(o for o in ops if o.tool == "submit_batch_job")
    print("规范:", json.dumps(demo.slots, ensure_ascii=False))
    for i, v in enumerate(p.variants(demo.slots, 8, tool=demo.tool), 1):
        print(f"  重试{i}: {json.dumps(v, ensure_ascii=False)}")

    print("\n=== 分支计数 ===", p.branch_counts)
    print("\n=== 算子激活表 ===")
    for r in p.activation_table():
        print(f"  {r['name']:22s} {r['kind']:6s} 探测{r['attempted']:4d} 生效{r['applied']:4d}")
    if p.errors:
        print("  异常:", p.errors)