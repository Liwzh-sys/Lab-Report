"""
run_experiments.py — 统一跑全部实验，输出 JSON + CSV。

实验清单（本版口径，与报告正文一一对应）
--------------------------------------
E0  算子实际激活表 + 采样改造前后对比   （审阅方四（一）（二））
E1  SAFE 的收益：裸哈希 → 仅 SAFe，含"去重/不去重"对照
E2  RISKY 阶梯：alpha 扫描，统一分母
E3  风险标定：λ（重复代价缩放量）→ 最优规则集，给 C_k(λ) 交点
E4  策略并排：裸哈希 / SAFE / RISKY全开 / 槽位投影(含/不含守卫) / 持久化ID
E5  按副作用分级 + 隐藏测试集（独立验证）
E6  重试次数敏感性（含原样重放比例的敏感性）
E7  逐条规则审计 + 32 子集穷举 + 顺序依赖
E8  三类事件：传输重试 / 重规划 / 独立新意图

口径纪律（每个数字旁边都写清）
----------------------------
  · FP 分母 = 同工具诱饵数（跨工具探针单列 ns_rate）
  · λ 只缩放 c_dup 侧，各工具真实比值 2.5 / 1.25 / 2.0
  · "±" 是样本标准差（ddof=1），不是置信区间
  · seed 只影响 episode 生成，不影响诱饵构造（诱饵是确定性的）
"""

from __future__ import annotations

import csv
import itertools
import json
import os
from collections import defaultdict
from typing import Any, Dict, List, Tuple

import numpy as np

import contract as C
import policy as P
from evaluate import (DEFAULT_CFG, Episode, dup_units, eval_opid_baseline,
                      eval_point, eval_strategy, make_episodes, make_pairs,
                      sweep_alphas)
from holdout import build_holdout, freeze_record, holdout_metrics
from perturb import (CHANGE_OPS, EQUIV_OPS, RuleBasedPerturber, SampleConfig)
from policy import KeyPolicy, RISKY_RULES
from structured import (STRATEGIES, StructuredKey, bare_key, slot_key,
                        slot_noderive_key)
from universe import (EVENT_CN, EVENT_TYPES, TOOLS, build_baseline_ops,
                      build_decoys, build_event_pairs, build_namespace_probes)

OUT = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(OUT, exist_ok=True)

SEEDS = tuple(range(8))


def _mp_ver():
    try:
        import matplotlib
        return matplotlib.__version__
    except Exception:
        return None


def mean(xs):
    return float(np.mean(xs)) if len(xs) else 0.0


def sd(xs):
    return float(np.std(xs, ddof=1)) if len(xs) > 1 else 0.0


def risky_all(t: str, a: Dict[str, Any]) -> str:
    return KeyPolicy(t, 1.0).key(a)


def mk_keyfn(rule_keys) -> Any:
    return lambda t, a: KeyPolicy(t, rule_keys=rule_keys).key(a)


# --------------------------------------------------------------------------
# E0 算子激活 + 采样改造对比
# --------------------------------------------------------------------------
def e0_activation():
    """
    算子激活表：**五个数分开记**（★ 第三轮重写）。

    ★ 第二版的问题：`_apply_chain` 在执行算子**之前**就 `self.calls += 1`，
      activation_table() 又把它当 "applied" 输出，报告写成"15/15 生效"。
      可算子可能返回 None，也可能返回一个和输入相等的字典（比如只改键序）。
      所以那个 15/15 最多只能支撑"15 个算子都被**调用**过"。

    现在分开记，名字也改掉，不再叫"生效"：

      probed    适用性探测判定它为适用
      chosen    在链上**被抽中**执行
      returned  run() 返回非 None
      changed   返回值与该步输入**逐字段不同**（真的改了东西）
      on_label  那次变化**符合该算子的 kind 声明**（判据来自 contract_equiv）

    "changed" 才是第二版想说的那个数；"on_label" 才是"语义扰动有效覆盖"。
    两者不相等，正是审阅方要的那个区分。
    """
    ops = build_baseline_ops()
    agg: Dict[str, Dict[str, Any]] = {}
    branches: Dict[str, int] = {"replay": 0, "rewrite": 0, "drift": 0}
    errors: Dict[str, int] = {}
    bve: Dict[str, int] = {"drift_no_change": 0, "rewrite_no_change": 0,
                           "replay_changed": 0}
    KEYS = ("attempted", "probed", "chosen", "returned", "changed", "on_label")
    for seed in SEEDS:
        p = RuleBasedPerturber(seed=seed, cfg=DEFAULT_CFG)
        for op in ops:
            for _ in range(DEFAULT_RETRIES):
                p.sample(op.slots, tool=op.tool)
        for r in p.activation_table():
            a = agg.setdefault(r["name"], {"name": r["name"], "kind": r["kind"],
                                           "note": r["note"],
                                           "changed_fields": [],
                                           **{k: 0 for k in KEYS}})
            for k in KEYS:
                a[k] += r[k]
            for f in r["changed_fields"]:
                if f not in a["changed_fields"]:
                    a["changed_fields"].append(f)
        for k in branches:
            branches[k] += p.branch_counts[k]
        for k, v in p.branch_vs_effect.items():
            bve[k] = bve.get(k, 0) + v
        for k, v in p.errors.items():
            errors[k] = errors.get(k, 0) + v
    # 按算子注册顺序输出（与 EQUIV_OPS + CHANGE_OPS 的声明次序一致）
    order = [r["name"] for r in RuleBasedPerturber(seed=0, cfg=DEFAULT_CFG).activation_table()]
    table = sorted(agg.values(), key=lambda r: order.index(r["name"]))
    return {
        "per_op": table,
        "branches": branches,
        "branch_vs_effect": bve,
        "errors": errors,
        "n_ops": len(ops),
        "retries": DEFAULT_RETRIES,
        "n_seeds": len(SEEDS),
        "n_samples": len(ops) * DEFAULT_RETRIES * len(SEEDS),
        # 三个层次分别计数，不再混成"激活了几个"
        "n_chosen": sum(1 for r in table if r["chosen"] > 0),
        "n_changed": sum(1 for r in table if r["changed"] > 0),
        "n_on_label": sum(1 for r in table if r["on_label"] > 0),
            "n_ops_total": len(table),
    }


def e0_dedup_compare():
    """
    采样改造前后对比，**一次只动一个因素**（★ 第三轮重写）。

    ★ 第二版这里同时动了好几样：去重开关、p_replay、p_drift、以及字段策略。
      于是整段下降被整体记在"取消去重"头上（当时是旧口径的 48.00 → 35.125；
      这两个数在本轮口径下已不再使用，此处只作历史说明，不要拿去和现在的表并排比较），
      而实际上第二行到第三行同时改了重放比例与变义比例。
      审阅方第六节（一）说得对：这个结果只能说"数据生成方式会影响分数"，
      说不了"每个修复各贡献多少"。

    现在固定：实现（v2 代码）、标签、请求总数（30 ops × 5 请求）、
    种子集（8 个），一次只动一个旋钮：

      F0  去重开关     dedup=True vs False，其余同为 纯改写(0/1/0)
      F1  重放比例     0% → 35%，其余同为 改写+变义、不去重
      F2  变义比例     0% → 10%，其余同为 35% 重放、不去重
      F3  三项一起     纯改写去重 → 35/55/10 不去重（= 第二版那个混合对比，
                       单独列出来，明确标注"这一行不是单因素"）

    每行的 Δ 只归给那一个因素。F3 不作归因，只作总览。
    """
    BASE = dict(seeds=SEEDS, retries=DEFAULT_RETRIES)

    def run(tag, cfg, factor, note):
        rows = []
        for seed in BASE["seeds"]:
            eps = make_episodes(seed=seed, retries=BASE["retries"], cfg=cfg)
            prs = make_pairs(seed=seed)
            row = {"config": tag, "factor": factor, "note": note, "seed": seed}
            for nm, fn in (("bare", bare_key),
                           ("safe", lambda t, a: KeyPolicy(t, 0.0).key(a)),
                           ("slot", slot_key)):
                pt = eval_strategy(eps, prs, nm, fn)
                row[f"{nm}_dup"] = pt.dup_cost
                row[f"{nm}_fn"] = pt.fn_rate
                row[f"{nm}_keys"] = pt.keys_per_episode
            rows.append(row)
        return rows

    CFG_DEDUP = SampleConfig(0.0, 1.0, 0.0, dedup=True)
    CFG_NODEDUP = SampleConfig(0.0, 1.0, 0.0, dedup=False)
    CFG_REPLAY = SampleConfig(0.35, 0.65, 0.0, dedup=False)
    CFG_DRIFT = SampleConfig(0.35, 0.55, 0.10, dedup=False)

    per_seed = []
    per_seed += run("F0a 纯改写+去重", CFG_DEDUP, "dedup", "去重开关：开")
    per_seed += run("F0b 纯改写+不去重", CFG_NODEDUP, "dedup", "去重开关：关")
    per_seed += run("F1 35%重放+65%改写", CFG_REPLAY, "p_replay", "重放比例 0%→35%")
    per_seed += run("F2 35%重放+55%改写+10%变义", CFG_DRIFT, "p_drift",
                    "变义比例 0%→10%")
    per_seed += run("F3 合并对比（非单因素）", CFG_DRIFT, "mixed",
                    "第二版的做法：一次动三个旋钮，不作归因")

    summ = []
    for tag in dict.fromkeys(r["config"] for r in per_seed):
        rs = [r for r in per_seed if r["config"] == tag]
        summ.append({
            "config": tag, "factor": rs[0]["factor"], "note": rs[0]["note"],
            "bare_dup": mean([r["bare_dup"] for r in rs]),
            "safe_dup": mean([r["safe_dup"] for r in rs]),
            "slot_dup": mean([r["slot_dup"] for r in rs]),
            "bare_fn": mean([r["bare_fn"] for r in rs]),
            "slot_fn": mean([r["slot_fn"] for r in rs]),
            "bare_keys": mean([r["bare_keys"] for r in rs]),
        })

    # 单因素归因：每对相邻的单因素配置
    by = {s["config"]: s for s in summ}
    attribution = []

    def delta(a, b, factor, label):
        sa, sb = by[a], by[b]
        attribution.append({
            "factor": factor, "label": label,
            "from": a, "to": b,
            "bare_dup_delta": sb["bare_dup"] - sa["bare_dup"],
            "slot_dup_delta": sb["slot_dup"] - sa["slot_dup"],
            "note": "只动这一个因素，Δ 归给它",
        })

    delta("F0a 纯改写+去重", "F0b 纯改写+不去重", "dedup", "取消去重")
    delta("F0b 纯改写+不去重", "F1 35%重放+65%改写", "p_replay",
          "加入 35% 原样重放")
    delta("F1 35%重放+65%改写", "F2 35%重放+55%改写+10%变义", "p_drift",
          "加入 10% 真实变义")

    # 三项合计 vs 各单因素之和。
    # ⚠ 注意：这三步是**首尾相接**的相邻配置（A→B→C→D），
    # 所以三个 Δ 之和按定义等于 D−A，交互项必然为 0。这是算术恒等，
    # **不能**据此宣称"因素之间无耦合"。要测耦合得做 2×2 因子设计
    # （例如 replay×drift 全组合），本实验没做，所以这里不下这个结论。
    total = {
        "bare_dup_delta": by["F2 35%重放+55%改写+10%变义"]["bare_dup"]
        - by["F0a 纯改写+去重"]["bare_dup"],
        "slot_dup_delta": by["F2 35%重放+55%改写+10%变义"]["slot_dup"]
        - by["F0a 纯改写+去重"]["slot_dup"],
    }
    sum_of_parts = {
        "bare_dup_delta": sum(a["bare_dup_delta"] for a in attribution),
        "slot_dup_delta": sum(a["slot_dup_delta"] for a in attribution),
    }
    interaction = {k: total[k] - sum_of_parts[k] for k in total}

    return {"per_seed": per_seed, "summary": summ,
            "attribution": attribution, "total": total,
            "sum_of_parts": sum_of_parts, "interaction": interaction,
            "interaction_note": (
                "相邻配置首尾相接，交互项按算术恒为 0；"
                "这既不证明也无否证因素间耦合。要测耦合需做 2×2 因子设计。")}


DEFAULT_RETRIES = 4


# --------------------------------------------------------------------------
# E1 SAFE 的收益
# --------------------------------------------------------------------------
def e1_safe():
    rows = []
    for seed in SEEDS:
        eps = make_episodes(seed=seed, retries=DEFAULT_RETRIES)
        prs = make_pairs(seed=seed)
        b = eval_strategy(eps, prs, "bare", bare_key)
        s = eval_strategy(eps, prs, "safe", lambda t, a: KeyPolicy(t, 0.0).key(a))
        rows.append({
            "seed": seed,
            "bare_dup": b.dup_cost, "bare_miss": b.miss_cost,
            "bare_fn": b.fn_rate, "bare_keys": b.keys_per_episode,
            "safe_dup": s.dup_cost, "safe_miss": s.miss_cost,
            "safe_fn": s.fn_rate, "safe_keys": s.keys_per_episode,
            "fp_denominator": s.fp_denominator,
        })
    return {
        "per_seed": rows,
        "summary": {
            "n_seeds": len(SEEDS),
            "bare_dup_mean": mean([r["bare_dup"] for r in rows]),
            "bare_dup_sd": sd([r["bare_dup"] for r in rows]),
            "safe_dup_mean": mean([r["safe_dup"] for r in rows]),
            "safe_dup_sd": sd([r["safe_dup"] for r in rows]),
            "bare_fn_mean": mean([r["bare_fn"] for r in rows]),
            "safe_fn_mean": mean([r["safe_fn"] for r in rows]),
            "bare_keys_mean": mean([r["bare_keys"] for r in rows]),
            "safe_keys_mean": mean([r["safe_keys"] for r in rows]),
            "reduction_pct": (1 - mean([r["safe_dup"] for r in rows])
                              / mean([r["bare_dup"] for r in rows])) * 100,
            "fp_denominator": rows[0]["fp_denominator"],
        },
    }


# --------------------------------------------------------------------------
# E2 RISKY 阶梯（统一分母）
# --------------------------------------------------------------------------
def e2_ladder(pivot: int = 0):
    rows = []
    for al in [i / 20 for i in range(21)]:
        fn, fp, dup, miss, nsplit, keys = [], [], [], [], [], []
        for seed in SEEDS:
            eps = make_episodes(seed=seed, retries=DEFAULT_RETRIES)
            prs = make_pairs(seed=seed, pivot=pivot)
            pt = eval_point(eps, prs, al, lam=1.0)
            fn.append(pt.fn_rate); fp.append(pt.fp_rate)
            dup.append(pt.dup_cost); miss.append(pt.miss_cost)
            nsplit.append(pt.n_split_episodes); keys.append(pt.keys_per_episode)
        pol = KeyPolicy("query_region_stats", al)
        rows.append({
            "alpha": al, "n_risky": pol.n_risky, "rule_keys": pol.rule_keys,
            "fn_mean": mean(fn), "fn_sd": sd(fn),
            "fp_mean": mean(fp), "fp_sd": sd(fp),
            "dup_mean": mean(dup), "miss_mean": mean(miss),
            "total_mean": C.total_cost(mean(dup), mean(miss)),
            "n_split_mean": mean(nsplit), "keys_mean": mean(keys),
            "fp_denominator": len([d for d in make_pairs(seed=0, pivot=pivot)
                                   if d.kind != "跨工具"]),
        })
    return rows


# --------------------------------------------------------------------------
# E3 风险标定：λ → 最优规则集
# --------------------------------------------------------------------------
def e3_lambda(lams=(0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50)):
    """
    对每个 λ，把 32 个 RISKY 子集全跑一遍，找总代价最小的那个。
    这比 v1 的 6 个 alpha 前缀强得多——审阅方要求"穷举 32 子集"。
    """
    subsets = []
    keys = [r.key for r in RISKY_RULES]
    for r in range(len(keys) + 1):
        for combo in itertools.combinations(keys, r):
            subsets.append(list(combo))

    # 先缓存每个子集的 (extra_keys, collisions, miss_cost)，λ 只影响 dup
    cache = {}
    eps_cache = {s: make_episodes(seed=s, retries=DEFAULT_RETRIES) for s in SEEDS}
    prs_cache = {s: make_pairs(seed=s) for s in SEEDS}

    for combo in subsets:
        kf = mk_keyfn(combo)
        extra = []
        missc = []
        for s in SEEDS:
            pt = eval_strategy(eps_cache[s], prs_cache[s], "x", kf, lam=0.0)
            # ★ 第四轮：不再自己数 len(keys)-1，改用唯一的 dup_units()。
            #   equiv_unit 就是主指标的单位量（未乘 lam / p_retry）。
            extra.append(dup_units(eps_cache[s], kf)["equiv_unit"])
            missc.append(pt.miss_cost)
        cache[tuple(combo)] = (mean(extra), mean(missc))

    rows = []
    for lam in lams:
        best = None
        for combo in subsets:
            du, mi = cache[tuple(combo)]
            tot = C.total_cost(du * lam, mi)
            if best is None or tot < best["total"]:
                best = {"total": tot, "dup": du * lam, "miss": mi,
                        "rule_keys": combo, "n_rules": len(combo)}
        rows.append({"lam": lam, **best})
    return {"rows": rows, "n_subsets": len(subsets), "cache": {
        ",".join(k) or "(none)": v for k, v in cache.items()}}


def e3_lambda_scan(n_points: int = 120,
                   lo: float = 0.2, hi: float = 6.2) -> Dict[str, Any]:
    """
    λ 细扫：在 32 个子集的缓存上密集取点，用来定位"最优规则集切换"发生在哪。

    ★ 第三轮补的缺口（审阅方：「图 3 的数据链断裂——e3_lambda_scan.json
      在 data/ 里存在，但没有任何代码会生成它」）

    这确实是断裂：仓库里有一份 120 点的扫描结果，make_figs 直接读它，
    但跑 run_experiments 永远不会重写这个文件。于是有两种情况都说得通：
      · 它是某次跑完后手工留下的（不可复现）；
      · 它是更早版本代码的结果（口径已变，图却还在用）。
    两种都不能接受。现在它由 run_experiments 每次重算并覆盖，
    口径与 e3_lambda() 共用同一份子集缓存，不可能再分叉。
    """
    subsets = []
    keys = [r.key for r in RISKY_RULES]
    for r in range(len(keys) + 1):
        for combo in itertools.combinations(keys, r):
            subsets.append(list(combo))

    eps_cache = {s: make_episodes(seed=s, retries=DEFAULT_RETRIES) for s in SEEDS}
    prs_cache = {s: make_pairs(seed=s) for s in SEEDS}

    cache = {}
    for combo in subsets:
        kf = mk_keyfn(combo)
        extra, missc = [], []
        for s in SEEDS:
            pt = eval_strategy(eps_cache[s], prs_cache[s], "x", kf, lam=0.0)
            # ★ 第四轮：与 e3_lambda() 共用同一个口径实现。细扫和粗扫
            #   必须同源，否则两张图会在同一个 λ 上给出不同的最优规则集。
            extra.append(dup_units(eps_cache[s], kf)["equiv_unit"])
            missc.append(pt.miss_cost)
        cache[tuple(combo)] = (mean(extra), mean(missc))

    scan = []
    for i in range(n_points):
        lam = lo + (hi - lo) * i / max(1, n_points - 1)
        best = None
        # ★ 第四轮（定稿修订单 5-5）：平局规则必须显式写出来，不能靠巧合。
        #   这里用严格的 `<` 比较，所以**同分时保留先遇到的那个**；而 subsets
        #   是按规则数从少到多（k = 0,1,...,5）枚举出来的，于是"先遇到的"
        #   就是"规则更少的那条"。这条平局规则（同分取规则更少）现在写进
        #   报告 E3 节，读者复算到边界时才对得上——原代码只是碰巧如此，
        #   注释里没写，改一次枚举顺序就会静默变掉。
        for combo in subsets:
            du, mi = cache[tuple(combo)]
            tot = C.total_cost(du * lam, mi)
            if best is None or tot < best["total"]:
                best = {"total": tot, "dup": du * lam, "miss": mi,
                        "n": len(combo), "combo": list(combo)}
        scan.append({"lam": round(lam, 6), **best})

    # 切换点：n 发生变化的位置，以及由此解析出的交点
    switches = []
    for a, b in zip(scan, scan[1:]):
        if a["n"] != b["n"]:
            # 两条直线 A1·λ+B1 与 A2·λ+B2 的交点
            # λ* = (B2-B1)/(A1-A2)，只在两条线都非退化时有意义
            a1, b1 = (a["dup"] / a["lam"], a["miss"]) if a["lam"] else (0, a["miss"])
            a2, b2 = (b["dup"] / b["lam"], b["miss"]) if b["lam"] else (0, b["miss"])
            lam_star = None
            if abs(a1 - a2) > 1e-12:
                lam_star = (b2 - b1) / (a1 - a2)
                if not (a["lam"] <= lam_star <= b["lam"]):
                    lam_star = None
            switches.append({
                "between": [a["lam"], b["lam"]],
                "from_n": a["n"], "to_n": b["n"],
                "from_combo": a["combo"], "to_combo": b["combo"],
                "lam_star": lam_star,
                "grid_resolution": round(b["lam"] - a["lam"], 6),
            })
    return {"scan": scan, "switches": switches,
            "n_points": len(scan), "lam_range": [lo, hi],
            "grid_resolution": round((hi - lo) / max(1, n_points - 1), 6),
            "n_subsets": len(subsets),
            "generator": "run_experiments.e3_lambda_scan"}


def e3_crosspoints(lam_rows) -> Dict[str, Any]:
    """
    成本交点：C_k(λ) = A_k·λ + B_k。
    只报"在采样网格内确实发生切换"的相邻两档，并给出解析交点，
    同时明确写出网格精度——v1 把网格的 1 vs 2 说成"ρ≈2"是夸大。
    """
    by_k = {}
    for r in lam_rows:
        k = r["n_rules"]
        by_k.setdefault(k, []).append(r)

    out = []
    for k, rs in sorted(by_k.items()):
        rs = sorted(rs, key=lambda x: x["lam"])
        A = (rs[-1]["dup"] / rs[-1]["lam"]) if rs[-1]["lam"] else 0.0
        B = rs[-1]["miss"]
        out.append({"n_rules": k, "A": A, "B": B,
                    "rule_keys": rs[-1]["rule_keys"],
                    "lam_min": rs[0]["lam"], "lam_max": rs[-1]["lam"]})
    # 相邻档位的解析交点
    pairs = []
    for i in range(len(out)):
        for j in range(i + 1, len(out)):
            a, b = out[i], out[j]
            dA, dB = a["A"] - b["A"], b["B"] - a["B"]
            if abs(dA) > 1e-12:
                x = dB / dA
                if x > 0:
                    pairs.append({"k_a": a["n_rules"], "k_b": b["n_rules"],
                                  "lam_star": x})
    return {"curves": out, "crosspoints": pairs}


# --------------------------------------------------------------------------
# E4 策略并排（含持久化 ID 基线）
# --------------------------------------------------------------------------
def e4_strategies():
    events = build_event_pairs(build_baseline_ops())
    rows = []
    for seed in SEEDS:
        eps = make_episodes(seed=seed, retries=DEFAULT_RETRIES)
        prs = make_pairs(seed=seed)
        for nm, fn in (("裸参数哈希", bare_key),
                       ("仅 SAFE", lambda t, a: KeyPolicy(t, 0.0).key(a)),
                       ("SAFE+全部RISKY", risky_all),
                       ("槽位投影（含守卫替代）", slot_key),
                       ("槽位投影（不含替代）", slot_noderive_key)):
            pt = eval_strategy(eps, prs, nm, fn)
            rows.append({
                "seed": seed, "strategy": nm,
                "fn": pt.fn_rate, "fp": pt.fp_rate, "ns": pt.ns_rate,
                "dup": pt.dup_cost, "miss": pt.miss_cost, "total": pt.total_cost,
                # 诊断量：旧口径成本与参数键分裂分数。只作对照与解释，
                # **不进任何结论**——真实变义把它们抬高，而那是对的。
                "dup_legacy": pt.dup_cost_legacy,
                "split_score": pt.split_score,
                "keys_per_ep": pt.keys_per_episode,
                "fp_denominator": pt.fp_denominator,
            })

    by = defaultdict(list)
    for r in rows:
        by[r["strategy"]].append(r)
    summary = []
    for nm, rs in by.items():
        summary.append({
            "strategy": nm,
            "fn_mean": mean([x["fn"] for x in rs]),
            "fn_sd": sd([x["fn"] for x in rs]),
            "fp_mean": mean([x["fp"] for x in rs]),
            "ns_mean": mean([x["ns"] for x in rs]),
            "dup_mean": mean([x["dup"] for x in rs]),
            "dup_sd": sd([x["dup"] for x in rs]),
            "dup_legacy_mean": mean([x["dup_legacy"] for x in rs]),
            "split_score_mean": mean([x["split_score"] for x in rs]),
            "miss_mean": mean([x["miss"] for x in rs]),
            "total_mean": mean([x["total"] for x in rs]),
            "total_sd": sd([x["total"] for x in rs]),
            "keys_per_ep": mean([x["keys_per_ep"] for x in rs]),
            "fp_denominator": rs[0]["fp_denominator"],
        })

    opid = eval_opid_baseline(None, None, events)
    return {"per_seed": rows, "summary": summary, "opid_baseline": opid,
            "n_events": len(events)}


# --------------------------------------------------------------------------
# E5 副作用分级 + 隐藏集
# --------------------------------------------------------------------------
def e5_side_effect_and_holdout():
    eps = make_episodes(seed=0, retries=DEFAULT_RETRIES)
    prs = make_pairs(seed=0)
    levels = {0: "只读", 2: "写正式", 3: "对外发送"}
    rows = []
    for lvl, nm in levels.items():
        sub = [e for e in eps if e.op.side_effect == lvl]
        if not sub:
            continue
        # ★ 第三轮修正：诱饵也必须按同一个副作用等级过滤。
        #   原来只过滤 episode、prs 仍是全量 113 对，于是三个等级的 miss 列
        #   是同一个全局值抄了三遍（都写着 19.20）。那张表会让读者以为
        #   "只读层的 miss 是 19.20"——它其实是全表的。
        sub_tools = {e.op.tool for e in sub}
        sub_prs = [d for d in prs
                   if d.src.tool in sub_tools and d.decoy.tool in sub_tools]
        for snm, fn in (("裸参数哈希", bare_key),
                        ("仅 SAFE", lambda t, a: KeyPolicy(t, 0.0).key(a)),
                        ("SAFE+全部RISKY", risky_all),
                        ("槽位投影", slot_key)):
            pt = eval_strategy(sub, sub_prs, snm, fn)
            rows.append({"side_effect": lvl, "level": nm, "strategy": snm,
                         "n_ops": len(sub), "n_pairs": len(sub_prs),
                         "fn": pt.fn_rate, "fp": pt.fp_rate,
                         "dup": pt.dup_cost, "miss": pt.miss_cost,
                         "total": pt.total_cost})

    # ---- 隐藏集：正负例分开，报三个数 -----------------------------------
    # 只报碰撞率的漏洞：永不合并的策略碰撞率恒为 0，看上去"最安全"。
    # 必须同时给 correct_merge / wrong_merge / selective_reject。
    hold = build_holdout()
    hrows = []
    for snm, fn in (("裸参数哈希", bare_key),
                    ("仅 SAFE", lambda t, a: KeyPolicy(t, 0.0).key(a)),
                    ("SAFE+全部RISKY", risky_all),
                    ("槽位投影", slot_key),
                    ("槽位投影（不含替代）", slot_noderive_key)):
        m = holdout_metrics(hold, lambda t, a, _f=fn: _f(t, a))
        m["strategy"] = snm
        m["n_pairs"] = len(hold)
        # 旧口径的"碰撞率"仍保留，方便与 v2 的报告对照，但不作为结论依据
        m["collide_all"] = m["correct_merge"] + m["wrong_merge"]
        hrows.append(m)

    # 一个"永不合并"的极端策略，用来自证三个数确实关掉了漏洞
    never = holdout_metrics(hold, lambda t, a: f"{t}|never|{id(a)}")
    always_same = holdout_metrics(hold, lambda t, a: "SAME")
    sanity = [
        {"strategy": "永不合并（极端对照）", **never},
        {"strategy": "恒为同键（极端对照）", **always_same},
    ]
    return {"by_side_effect": rows, "holdout": hrows, "sanity": sanity,
            "n_holdout": len(hold),
            "n_pos": sum(1 for d in hold if getattr(d, "polarity", "负例") == "正例"),
            "n_neg": sum(1 for d in hold if getattr(d, "polarity", "负例") == "负例")}


# --------------------------------------------------------------------------
# E6 重试次数 + 原样重放比例敏感性
# --------------------------------------------------------------------------
def e6_sensitivity():
    rows = []
    for rt in (1, 2, 4, 8):
        for seed in SEEDS:
            eps = make_episodes(seed=seed, retries=rt)
            prs = make_pairs(seed=seed)
            row = {"retries": rt, "seed": seed}
            for nm, fn in (("bare", bare_key),
                           ("safe", lambda t, a: KeyPolicy(t, 0.0).key(a)),
                           ("slot", slot_key)):
                pt = eval_strategy(eps, prs, nm, fn)
                row[f"{nm}_dup"] = pt.dup_cost
                row[f"{nm}_keys"] = pt.keys_per_episode
            rows.append(row)

    by_rt = []
    for rt in (1, 2, 4, 8):
        rs = [r for r in rows if r["retries"] == rt]
        bd = mean([r["bare_dup"] for r in rs])
        sd_ = mean([r["safe_dup"] for r in rs])
        ld = mean([r["slot_dup"] for r in rs])
        by_rt.append({
            "retries": rt,
            "bare_dup": bd, "safe_dup": sd_, "slot_dup": ld,
            "bare_keys": mean([r["bare_keys"] for r in rs]),
            # retries=1 时每次重试只取 1 个样本，不会产生额外键 → 分母为 0，
            # 降幅无定义。写 None 而不是 0，避免"看起来有降幅"。
            "gain": (1 - ld / bd) * 100 if bd > 1e-12 else None,
        })

    # 原样重放比例敏感性：p_replay 从 0 到 0.9
    replay = []
    for p_rep in (0.0, 0.2, 0.4, 0.6, 0.8, 0.9):
        rest = 1.0 - p_rep
        cfg = SampleConfig(p_rep, rest, 0.0, dedup=False)
        acc = defaultdict(list)
        for seed in SEEDS:
            eps = make_episodes(seed=seed, retries=DEFAULT_RETRIES, cfg=cfg)
            prs = make_pairs(seed=seed)
            for nm, fn in (("bare", bare_key), ("safe", lambda t, a: KeyPolicy(t, 0.0).key(a)),
                           ("slot", slot_key)):
                pt = eval_strategy(eps, prs, nm, fn)
                acc[nm].append(pt.dup_cost)
        bd = mean(acc["bare"])
        ld = mean(acc["slot"])
        replay.append({
            "p_replay": p_rep,
            "bare_dup": bd, "safe_dup": mean(acc["safe"]), "slot_dup": ld,
            "gain": (1 - ld / bd) * 100 if bd > 1e-12 else None,
        })
    return {"by_retries": by_rt, "per_seed": rows, "by_replay": replay}


# --------------------------------------------------------------------------
# E7 规则审计：单条 + 32 子集 + 顺序依赖
# --------------------------------------------------------------------------
def _audit(eps_list, prs_list, rule_keys, lam=1.0):
    kf = mk_keyfn(rule_keys)
    dup, dup_legacy, split, miss, nsplit, collide = 0.0, 0.0, 0.0, 0.0, 0, 0
    for eps, prs in zip(eps_list, prs_list):
        # ★ 第四轮：E7 原来自己重算 (nk-1)*c_dup，与主表口径脱节。
        #   现在统一走 dup_units()，三个量一次算完。
        du = dup_units(eps, kf)
        dup += du["equiv_unit"] * lam
        dup_legacy += du["legacy_unit"] * lam
        split += du["extra_keys"]
        nsplit += sum(1 for ep in eps
                      if len({kf(ep.op.tool, v) for v in ep.variants}) > 1)
        pt = eval_strategy(eps, prs, "x", kf, lam=0.0)
        miss += pt.miss_cost
        collide += round(pt.fp_rate * pt.fp_denominator)
    n_ep = sum(len(e) for e in eps_list)
    n_pairs = sum(len([d for d in p if d.kind != "跨工具"]) for p in prs_list)
    n_seed = len(eps_list)
    return {"dup": dup / n_seed, "dup_legacy": dup_legacy / n_seed,
            "split_score": split / n_seed,
            "miss": miss / n_seed,
            "total": C.total_cost(dup / n_seed, miss / n_seed),
            "fn": nsplit / n_ep, "fp": collide / n_pairs if n_pairs else 0.0,
            "collide": collide, "n_pairs": n_pairs}


def e7_rule_audit():
    eps_list = [make_episodes(seed=s, retries=DEFAULT_RETRIES) for s in SEEDS]
    prs_list = [make_pairs(seed=s) for s in SEEDS]

    base = _audit(eps_list, prs_list, [])
    single = []
    for r in RISKY_RULES:
        m = _audit(eps_list, prs_list, [r.key])
        single.append({
            "rule": r.name, "key": r.key, "danger": r.dangerousness,
            "eats": r.eats, **m,
            "d_dup": m["dup"] - base["dup"],
            "d_miss": m["miss"] - base["miss"],
            "d_total": m["total"] - base["total"],
            "d_fp": m["fp"] - base["fp"],
        })

    # 32 子集
    keys = [r.key for r in RISKY_RULES]
    subs = []
    single_d = {s["key"]: s["d_total"] for s in single}
    for k in range(len(keys) + 1):
        for combo in itertools.combinations(keys, k):
            m = _audit(eps_list, prs_list, list(combo))
            d_tot = m["total"] - base["total"]
            subs.append({"rule_keys": list(combo), "n_rules": len(combo), **m,
                         "d_total": d_tot,
                         # 协同项：组合的实际增益减去各成员单独增益之和。
                         # 负值 = 规则相互掩盖；正值 = 单独看不出、一起才有效。
                         "synergy": d_tot - sum(single_d[c] for c in combo)
                         if combo else 0.0})

    # ★ 第四轮：把前沿判定写进数据，不再让人（包括我自己）手算。
    #   上一版报告里我手算出"2 条以上 31 个组合全部被严格支配"，两处都错了：
    #   (a) 多开组合是 26 个不是 31 个（31 把 5 个单开也算进了"2 条以上"）；
    #   (b) strip_intensity+text_bag 与单开 strip_intensity 坐标完全重合，
    #       它不被严格支配，是并列前沿点。手算漏掉并列情形，这里用代码判定。
    def _dominated(p):
        return any((q["dup"] <= p["dup"] and q["miss"] <= p["miss"])
                   and (q["dup"] < p["dup"] or q["miss"] < p["miss"])
                   for q in subs if q is not p)

    for s in subs:
        s["pareto"] = not _dominated(s)

    front = [s for s in subs if s["pareto"]]
    multi = [s for s in subs if s["n_rules"] >= 2]
    pareto_stats = {
        "n_subsets": len(subs),
        "n_empty": sum(1 for s in subs if s["n_rules"] == 0),
        "n_single": sum(1 for s in subs if s["n_rules"] == 1),
        "n_multi": len(multi),
        "n_strictly_dominated": sum(1 for s in subs if not s["pareto"]),
        "n_front": len(front),
        "n_front_unique_xy": len({(round(s["dup"], 6), round(s["miss"], 6))
                                  for s in front}),
        "n_multi_dominated": sum(1 for s in multi if not s["pareto"]),
        "n_multi_on_front": sum(1 for s in multi if s["pareto"]),
        # 关键结论用代码说，不靠肉眼："没有任何多开组合严格优于单开最好的那条"
        "any_multi_better_than_best_single": any(
            (m["dup"] < b["dup"] and m["miss"] <= b["miss"])
            or (m["miss"] < b["miss"] and m["dup"] <= b["dup"])
            for m in multi
            for b in [min((s for s in subs if s["n_rules"] == 1),
                          key=lambda s: (s["dup"] + s["miss"]))]),
    }

    # 顺序依赖：直接调换执行顺序，看结果是否变化。
    #   v1 的坑在这里：EXEC_ORDER 是模块级常量，只反转 RISKY_RULES 列表
    #   并不会改变实际执行顺序（KeyPolicy 仍按旧 EXEC_ORDER 排序），
    #   于是"顺序无关"是自己造出来的假结论。本版显式构造 KeyPolicy 的
    #   执行序列，绕过 EXEC_ORDER。
    order_tests = []
    all_keys = [r.key for r in RISKY_RULES]

    def run_order(combo, reverse: bool):
        """按给定顺序跑一遍（结构级/文本级顺序被打破）。"""
        rules = [P.RULE_BY_KEY[k] for k in combo]
        if reverse:
            rules = list(reversed(rules))

        def kk(tool, slots):
            a = P.safe_drop_noise(slots)
            a = P.safe_schema_project(tool, a)
            a = P.safe_normalize(tool, a)
            a = P.safe_drop_explicit_default(tool, a)
            for r in rules:                 # 顺序在这里生效
                a = r.fn(tool, a)
            a = {k: a[k] for k in sorted(a)}
            return f"{tool}|" + json.dumps(a, ensure_ascii=False, sort_keys=True)

        dup, dup_legacy, split, miss, collide = 0.0, 0.0, 0.0, 0.0, 0
        for eps, prs in zip(eps_list, prs_list):
            # ★ 第四轮：这里原来手抄了一遍 kk 的规则链、又手算 (len-1)*c_dup，
            #   是项目里第三处重复实现。现在 keyfn 只写一份，代价只算一份。
            du = dup_units(eps, kk)
            dup += du["equiv_unit"]
            dup_legacy += du["legacy_unit"]
            split += du["extra_keys"]
            for d in prs:
                if d.kind == "跨工具":
                    continue
                if kk(d.src.tool, d.src.slots) == kk(d.decoy.tool, d.decoy.slots):
                    collide += 1
                    miss += d.decoy.c_miss
        n_pairs = sum(len([d for d in p if d.kind != "跨工具"]) for p in prs_list)
        return {"dup": dup / len(eps_list), "dup_legacy": dup_legacy / len(eps_list),
                "split_score": split / len(eps_list),
                "miss": miss / len(eps_list),
                "total": C.total_cost(dup / len(eps_list), miss / len(eps_list)),
                "fp": collide / n_pairs if n_pairs else 0.0}

    for combo in (all_keys, all_keys[:3], all_keys[1:4], ["text_bag", "time_coarse"]):
        m_fwd = run_order(combo, False)
        m_rev = run_order(combo, True)
        order_tests.append({
            "rule_keys": combo,
            "forward_total": m_fwd["total"], "reversed_total": m_rev["total"],
            "forward_fp": m_fwd["fp"], "reversed_fp": m_rev["fp"],
            "delta": m_rev["total"] - m_fwd["total"],
            "order_dependent": abs(m_rev["total"] - m_fwd["total"]) > 1e-9
            or abs(m_rev["fp"] - m_fwd["fp"]) > 1e-9,
        })

    return {"baseline": base, "single": single, "subsets": subs,
            "order_tests": order_tests, "n_subsets": len(subs),
            "pareto_stats": pareto_stats}


# --------------------------------------------------------------------------
# E8 四类事件（★ 第三轮重写）
# --------------------------------------------------------------------------
def e8_events():
    """
    四类事件上按**期望动作**判对错。

    ★ 第二版的问题：标签只有"身份是否相同"，于是判"变了"只能靠 `a != b`。
      而 replan 那一类的 53 对全部来自 `_drift_alt()`，只是保义等价写法。
      结果：键把它们并起来（**正确**）被判成 53 次语义冲突。
      报告接着宣称"这 53 次必须上报，否则就是把冲突吞掉"——
      把目标达成写成了事故。

    现在的判分：

      事件类型            期望动作   键相同 →  键不同 →
      原样重放            复用      ✓ 对       ✗ 重复执行
      同身份保义改写       复用      ✓ 对       ✗ 重复执行（误杀好请求）
      同身份真实变义       拒绝      ✗ 变义被吞  ✓ 冲突已拦
      不同身份新意图       执行      ✗ 新意图被抑 ✓ 对

    于是"冲突"这个词只留给第三类：真的变了、身份又相同、键却并上了。
    第一、二类并起来是对的，不再叫冲突。
    """
    events = build_event_pairs(build_baseline_ops())
    rows = []
    for nm, fn in (("裸参数哈希", bare_key),
                   ("仅 SAFE", lambda t, a: KeyPolicy(t, 0.0).key(a)),
                   ("SAFE+全部RISKY", risky_all),
                   ("槽位投影", slot_key),
                   ("持久化操作 ID", None)):
        by_type = {}
        for et in EVENT_TYPES:
            by_type[et] = {"n": 0, "ok": 0, "wrong": 0,
                           "dup": 0, "miss": 0, "conflict": 0,
                           "false_reject": 0, "swallowed": 0}
        for e in events:
            if fn is None:
                same = (e.id_a == e.id_b)          # 键 = 持久化身份
            else:
                same = fn(e.tool, e.a) == fn(e.tool, e.b)
            r = by_type[e.event_type]
            r["n"] += 1
            exp = e.expected_action
            if exp == "reuse":
                if same:
                    r["ok"] += 1
                else:
                    r["wrong"] += 1
                    r["dup"] += 1              # 该合并没合并 → 重复执行
            elif exp == "reject":
                if same:
                    r["wrong"] += 1
                    r["swallowed"] += 1        # 真变义被吞进同一个键
                    r["conflict"] += 1         # 这才是"冲突"，只属于这一类
                else:
                    r["ok"] += 1
            else:                              # execute
                if same:
                    r["wrong"] += 1
                    r["miss"] += 1             # 新意图被抑制
                else:
                    r["ok"] += 1
            # "合法请求被错误拒绝"只能靠 on_miss=reject 才会发生，
            # 这里记的是**键判定的方向**，故只有语义上的误杀 = 该复用却没并。
            if exp == "reuse" and not same:
                r["false_reject"] = r.get("false_reject", 0) + 1
        for et in EVENT_TYPES:
            r = by_type[et]
            rows.append({"strategy": nm, "event_type": et, **r,
                         "ok_rate": r["ok"] / r["n"] if r["n"] else 0.0,
                         "wrong_rate": r["wrong"] / r["n"] if r["n"] else 0.0})
    return {"rows": rows, "n_events": len(events),
            "types": list(EVENT_TYPES),
            "n_by_type": {et: sum(1 for e in events if e.event_type == et)
                          for et in EVENT_TYPES}}


# --------------------------------------------------------------------------
# E9 受控样本：五个计数到底能不能抓到东西（★ 第三轮新增）
# --------------------------------------------------------------------------
def e9_controlled():
    """
    自然采样数据里"真实变义被吞"几乎总是 0，因为变义同时改了键里的字段，
    键自然就分开了。**一个永远为 0 的计数器什么也证明不了。**
    所以必须构造受控样本，把"键把真变义并掉了"这件事逼出来。

    四组受控样本，对应审阅方第四节（一）举的例子和 E8/隐藏集里的边界：

      C1 混合 episode：原月份 2026-08 + 真改到 2026-11，身份相同。
         期望：评估器记 change_swallowed（若键并了）/ conflict_rejected（若分开了）。
         第二版在这里记的是 dup_cost=1、FP=0 —— 把工具做对记成浪费。

      C2 断言强度翻转：「疑似」→「确认」。全 RISKY 的 strip_intensity 会抹平它。
         期望：SAFE 判不同键（对），全 RISKY 判同键（吞掉）。

      C3 范围收窄：job_name 加 _partial。
         期望：scope_drop 会抹平 → 吞掉。

      C4 保义改写对照：同一个月换成 '2026年8月'。
         期望：任何键都不该把它拆开 → 不得出现 equiv_split。

    每组直接构造 Sample 列表，不经过采样器，因此可以精确声明标签。
    """
    from evaluate import (L_CHANGE, L_EQUIV, L_SAME, A_REJECT, A_REUSE,
                          Episode, Sample, _summarize)
    from universe import LogicalOp

    def mk(op_id, tool, a, b, label, action, changed):
        base = LogicalOp(op_id, tool, dict(a), op_id)
        samples = [Sample(op_id, dict(a), "first", L_SAME, A_REUSE, ()),
                   Sample(op_id, dict(b), "controlled", label, action, changed)]
        return Episode(base, samples)

    cases = {
        "C1 混合episode：真改月份（S07 08→11）": mk(
            "c1", "submit_batch_job",
            {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-08"},
            {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-11"},
            L_CHANGE, A_REJECT, ("month",)),
        "C2 断言强度：疑似→确认": mk(
            "c2", "write_qc_note",
            {"station": "S07", "month": "2026-08", "note": "S07 温度传感器疑似漂移"},
            {"station": "S07", "month": "2026-08", "note": "S07 温度传感器确认漂移"},
            L_CHANGE, A_REJECT, ("note",)),
        "C3 范围收窄：加 _partial": mk(
            "c3", "submit_batch_job",
            {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-08"},
            {"job_name": "recompute_S07_2026-08_partial", "station": "S07",
             "month": "2026-08"},
            L_CHANGE, A_REJECT, ("job_name",)),
        "C4 保义改写对照：2026-08 → 2026年8月": mk(
            "c4", "submit_batch_job",
            {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-08"},
            {"job_name": "recompute_S07_2026-08", "station": "S07",
             "month": "2026年8月"},
            L_EQUIV, A_REUSE, ("month",)),
    }

    strategies = (("裸参数哈希", bare_key),
                  ("仅 SAFE", lambda t, a: KeyPolicy(t, 0.0).key(a)),
                  ("SAFE+全部RISKY", risky_all),
                  ("槽位投影", slot_key))
    rows = []
    for tag, ep in cases.items():
        for nm, fn in strategies:
            keys = [fn(ep.op.tool, v) for v in ep.variants]
            p = _summarize([len(set(keys))], [ep], [], fn, 1.0, 1.0, 1.0)
            c = p.counts
            if ep.samples[1].expected_action == "reject":
                verdict = ("吞掉" if c["change_swallowed"] else
                           "拦下" if c["conflict_rejected"] else "异常")
            else:
                verdict = ("误杀" if c["equiv_split"] else
                           "并上" if c["ok_reuse"] else "异常")
            rows.append({"case": tag, "strategy": nm, "verdict": verdict,
                         "same_key": keys[0] == keys[1],
                         "key_a": keys[0], "key_b": keys[1],
                         "equiv_split": c["equiv_split"],
                         "change_swallowed": c["change_swallowed"],
                         "conflict_rejected": c["conflict_rejected"],
                         "ok_reuse": c["ok_reuse"]})

    # 需求书给的那组数：outcome 计数在受控样本上非零，就说明指标是活的
    live = {
        "change_swallowed>0": sum(1 for r in rows if r["change_swallowed"] > 0),
        "conflict_rejected>0": sum(1 for r in rows if r["conflict_rejected"] > 0),
        "equiv_split>0": sum(1 for r in rows if r["equiv_split"] > 0),
    }
    return {"rows": rows, "live": live, "n_cases": len(cases)}


# --------------------------------------------------------------------------
# E10 成本模型二选一的校验：可加模型 vs 二维帕累托（★ 第三轮新增）
# --------------------------------------------------------------------------
def e10_cost_model():
    """
    审阅方第六节（二）：文档说不能相加，代码在相加。必须二选一。

    本项目的选择是"可加模型为主、二维前沿为校验"，理由与假设写在
    contract.COST_ASSUMPTIONS。这里做的是**校验**，不是再来一次选择：

      1. 把 5 种策略画在 (dup, miss) 平面上，算帕累托前沿。
      2. 用可加模型在 p_retry × p_conflict 网格上找最优策略，
         检查它是否落在前沿上。
      3. 如果某个出现率组合下的"最优"落在**被支配**的位置，
         说明成本参数与数据不自洽——那个组合下的结论必须作废。

    这一步的价值：把"总分最优"从一句宣称变成一个**可被推翻**的检查。
    """
    eps_list = [make_episodes(seed=s, retries=DEFAULT_RETRIES) for s in SEEDS]
    prs_list = [make_pairs(seed=s) for s in SEEDS]
    strategies = (("裸参数哈希", bare_key),
                  ("仅 SAFE", lambda t, a: KeyPolicy(t, 0.0).key(a)),
                  ("SAFE+全部RISKY", risky_all),
                  ("槽位投影（含守卫替代）", slot_key),
                  ("槽位投影（不含替代）", slot_noderive_fn()))

    # 先在 (dup, miss) 平面上取种子平均
    pts = []
    for nm, fn in strategies:
        ds, ms = [], []
        for eps, prs in zip(eps_list, prs_list):
            pt = eval_strategy(eps, prs, nm, fn, lam=1.0)
            ds.append(pt.dup_cost)
            ms.append(pt.miss_cost)
        pts.append({"strategy": nm, "dup": mean(ds), "miss": mean(ms)})

    # 帕累托前沿：没有别的点在两维上都不差且至少一维更好
    def dominated(p):
        return any((q["dup"] <= p["dup"] and q["miss"] <= p["miss"])
                   and (q["dup"] < p["dup"] or q["miss"] < p["miss"])
                   for q in pts if q is not p)

    for p in pts:
        p["pareto"] = not dominated(p)

    # 在出现率网格上，用可加模型选最优，检查是否落在前沿上
    grid = []
    n_off = 0
    for pr in C.P_RETRY_GRID:
        for pc in C.P_CONFLICT_GRID:
            scored = [{"strategy": p["strategy"],
                       "cost": C.total_cost(p["dup"] * pr, p["miss"] * pc),
                       "pareto": p["pareto"]}
                      for p in pts]
            best = min(scored, key=lambda x: x["cost"])
            on = best["pareto"]
            if not on:
                n_off += 1
            grid.append({"p_retry": pr, "p_conflict": pc,
                         "best": best["strategy"], "cost": best["cost"],
                         "on_pareto": on})
    return {"points": pts, "grid": grid,
            "n_grid": len(grid), "n_off_pareto": n_off,
            "cost_model": C.COST_MODEL, "unit": C.COST_UNIT,
            "assumptions": list(C.COST_ASSUMPTIONS)}


def slot_noderive_fn():
    return lambda t, a: StructuredKey(t, derive=False).key(a)


# --------------------------------------------------------------------------
def main():
    print("E0 算子五计数与采样对照 ...")
    e0a = e0_activation()
    e0b = e0_dedup_compare()

    print("E1 SAFE 收益 ...")
    e1 = e1_safe()

    print("E2 RISKY 阶梯 ...")
    e2 = e2_ladder()

    print("E3 λ → 最优规则集（32 子集穷举）...")
    e3 = e3_lambda()
    e3x = e3_crosspoints(e3["rows"])

    print("E3b λ 细扫（图 3 的数据来源，现在由本脚本生成）...")
    e3s = e3_lambda_scan()

    print("E4 策略并排 + 持久化 ID 基线 ...")
    e4 = e4_strategies()

    print("E5 副作用分级 + 隐藏集 ...")
    e5 = e5_side_effect_and_holdout()

    print("E6 敏感性 ...")
    e6 = e6_sensitivity()

    print("E7 规则审计 + 32 子集 + 顺序依赖 ...")
    e7 = e7_rule_audit()

    print("E8 四类事件 ...")
    e8 = e8_events()

    print("E9 受控样本：五个计数能不能抓到东西 ...")
    e9 = e9_controlled()

    print("E10 成本模型：可加 vs 二维帕累托 ...")
    e10 = e10_cost_model()

    res = {
        "meta": {
            "n_seeds": len(SEEDS), "seeds": list(SEEDS),
            "n_base_ops": len(build_baseline_ops()),
            "retries": DEFAULT_RETRIES,
            "n_tools": len(TOOLS),
            "fp_denominator": len([d for d in make_pairs(seed=0)
                                   if d.kind != "跨工具"]),
            "n_namespace_probes": len(build_namespace_probes()),
            "n_holdout": e5["n_holdout"],
            "lam_semantics": ("lam 只缩放 c_dup 侧；lam=1 时各工具真实代价比 "
                              + ", ".join(f"{t}={c['c_dup']/c['c_miss']:.2f}"
                                          for t, c in TOOLS.items()
                                          if c["c_miss"] and c["c_dup"])),
            "sd_meaning": "样本标准差 ddof=1，不是置信区间",
            "seed_scope": "seed 影响 episode 生成；诱饵构造是确定性的，seed 不参与",
            "sample_cfg": {"p_replay": DEFAULT_CFG.p_replay,
                           "p_rewrite": DEFAULT_CFG.p_rewrite,
                           "p_drift": DEFAULT_CFG.p_drift,
                           "dedup": DEFAULT_CFG.dedup},
            "risky_rules": [{"key": r.key, "name": r.name,
                             "danger": r.dangerousness, "eats": r.eats}
                            for r in RISKY_RULES],
            "cost_model": C.COST_MODEL,
            "cost_unit": C.COST_UNIT,
            "cost_assumptions": list(C.COST_ASSUMPTIONS),
            "p_retry_baseline": C.P_RETRY_BASELINE,
            "p_conflict_baseline": C.P_CONFLICT_BASELINE,
            "episode_scope": ("n_requests = retries + 1，含首次请求；"
                              "与第二版'n 次重试'不是同一个总体"),
            # ★ 第三轮：把生成环境写进结果文件本身。
            #   否则"我这个环境跑出来的"只是一句无法对账的话。
            "python": __import__("platform").python_version(),
            "python_full": __import__("sys").version,
            "platform": __import__("platform").platform(),
            "packages": {"numpy": __import__("numpy").__version__,
                         "matplotlib": _mp_ver()},
            "numpy_used_in": "所有均值/标准差计算（np.mean / np.std）",
        },
        "E0_activation": e0a, "E0_dedup": e0b,
        "E1_safe": e1, "E2_ladder": e2, "E3_lambda": e3,
        "E3_crosspoints": e3x, "E3_scan_summary": {
            "n_points": e3s["n_points"], "lam_range": e3s["lam_range"],
            "grid_resolution": e3s["grid_resolution"],
            "switches": e3s["switches"],
            "generator": e3s["generator"]},
        "E4_strategies": e4,
        "E5_side_effect": e5, "E6_sensitivity": e6,
        "E7_audit": e7, "E8_events": e8, "E9_controlled": e9, "E10_cost_model": e10,
    }
    path = os.path.join(OUT, "results.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print(f"\n写出 {path}")

    # ---- 隐藏集冻结记录：每次运行都校验，不一致就报 --------------------
    fz_path = os.path.join(OUT, "holdout_freeze.json")
    fz_now = freeze_record(build_holdout())
    fz_now["frozen_at"] = __import__("datetime").datetime.now().isoformat(
        timespec="seconds")
    fz_now["note"] = ("本文件只证明「冻结之后没被改过」；不能证明"
                      "「只评一次、不参与策略设计」——后者需外部保管。")
    if os.path.exists(fz_path):
        with open(fz_path, encoding="utf-8") as f:
            prev = json.load(f)
        if prev.get("sha256") != fz_now["sha256"]:
            print("\n" + "!" * 96)
            print("!! 隐藏集被动过：哈希与 data/holdout_freeze.json 不一致")
            print(f"!!   冻结时 {prev.get('sha256')}  (v{prev.get('version')}, "
                  f"n={prev.get('n')}, {prev.get('frozen_at', '—')})")
            print(f"!!   现在   {fz_now['sha256']}  (v{fz_now['version']}, "
                  f"n={fz_now['n']})")
            print("!! 旧成绩作废：改了隐藏集之后必须重跑全部结果，并在报告里记一笔。")
            print("!" * 96)
        else:
            print(f"隐藏集冻结校验通过：v{prev.get('version')} "
                  f"{prev['sha256'][:16]}… n={prev['n']} "
                  f"(正 {prev.get('n_pos')} / 负 {prev.get('n_neg')})")
        # 保留最初的 frozen_at，不被覆盖（冻结时刻不能被后来者改写）
        fz_now["frozen_at"] = prev.get("frozen_at", fz_now["frozen_at"])
        fz_now["sha256_history"] = prev.get("sha256_history", []) + (
            [] if prev.get("sha256") == fz_now["sha256"]
            else [{"sha256": prev.get("sha256"), "version": prev.get("version"),
                   "n": prev.get("n"), "frozen_at": prev.get("frozen_at")}])
    else:
        print(f"隐藏集首次冻结：v{fz_now['version']} {fz_now['sha256'][:16]}… "
              f"n={fz_now['n']}")
    with open(fz_path, "w", encoding="utf-8") as f:
        json.dump(fz_now, f, ensure_ascii=False, indent=2)
    print(f"写出 data/holdout_freeze.json")
    res["holdout_freeze"] = fz_now
    with open(path, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)

    def dump_csv(name, rows, exclude=()):
        if not rows:
            return
        fields = [k for k in rows[0] if k not in exclude]
        with open(os.path.join(OUT, name), "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for r in rows:
                w.writerow({k: r[k] for k in fields})
        print(f"写出 data/{name}")

    dump_csv("e2_ladder.csv", e2, ("rule_keys",))
    dump_csv("e3_lambda.csv", e3["rows"], ("rule_keys",))
    dump_csv("e4_summary.csv", e4["summary"])
    dump_csv("e0_activation.csv", e0a["per_op"])
    # ★ 第四轮：加一列可读的组合名。只有 n_rules 的话，读者没法从 CSV
    #   认出哪一行是 strip_intensity、哪一行是那个与它同坐标的两条组合。
    for _s in e7["subsets"]:
        _s["rules"] = "+".join(_s["rule_keys"]) if _s["rule_keys"] else "(空集)"
    dump_csv("e7_subsets.csv", e7["subsets"], ("rule_keys",))

    # ★ 图 3 的数据出口：每次运行都重写，口径与 e3_lambda() 共用同一个缓存
    scan_path = os.path.join(OUT, "e3_lambda_scan.json")
    with open(scan_path, "w", encoding="utf-8") as f:
        json.dump({k: v for k, v in e3s.items() if k != "cache"},
                  f, ensure_ascii=False, indent=2)
    print(f"写出 data/e3_lambda_scan.json（{e3s['n_points']} 点，"
          f"切换 {len(e3s['switches'])} 次，由 run_experiments 生成）")

    # ★ 旧口径文件：不删，但必须自己说明"已过期"，否则会被当成现行结果
    rho_path = os.path.join(OUT, "e3_rho.csv")
    if os.path.exists(rho_path):
        with open(rho_path, encoding="utf-8") as f:
            body = f.read()
        if not body.startswith("#"):
            banner = (
                "# ⚠️ 已过期（ARCHIVED）：本文件是**旧口径**的结果，不再由任何脚本生成，\n"
                "#    保留仅供与第二版报告对照。现行指标是 λ 标定（见 e3_lambda.csv 与\n"
                "#    e3_lambda_scan.json），ρ 这个符号在报告正文中已不再使用。\n"
                "#    更要紧的原因：ρ 表的行里混有不同版本的运行结果（见 REPORT 第 6 节\n"
                "#    「过程可核验性」），不能作为任何结论的依据。\n")
            with open(rho_path, "w", encoding="utf-8") as f:
                f.write(banner + body)
            print("data/e3_rho.csv 已加归档标注（旧口径，不再生成）")

    # 控制台摘要
    print("\n" + "=" * 100)
    print("E0a 算子五计数（不再把'被调用'写成'生效'）")
    print("=" * 100)
    print(f"{'算子':22s}{'kind':7s}{'探测':>6}{'抽中':>6}{'返回':>6}"
          f"{'真变了':>7}{'合标签':>7}   变了的字段")
    for r in e0a["per_op"]:
        print(f"{r['name']:22s}{r['kind']:7s}{r['probed']:>6}{r['chosen']:>6}"
              f"{r['returned']:>6}{r['changed']:>7}{r['on_label']:>7}   "
              f"{','.join(r['changed_fields']) or '—'}")
    print()
    print(f"  抽中过: {e0a['n_chosen']}/{e0a['n_ops_total']}   "
          f"真的改了字段: {e0a['n_changed']}/{e0a['n_ops_total']}   "
          f"变化合标签: {e0a['n_on_label']}/{e0a['n_ops_total']}")
    print("  三个数不同才是实情：key_order 只改键序，不改任何字段值，"
          "所以 changed=0——它确实被调用过，但没有改变任何内容。")
    bve = e0a["branch_vs_effect"]
    print(f"  分支标签与真实效果的不一致：drift 抽中却没变 {bve['drift_no_change']}，"
          f"rewrite 抽中却没变 {bve['rewrite_no_change']}，"
          f"replay 却变了 {bve['replay_changed']}")
    print("  （前两个数是照抄分支标签会凭空造出'变义被吞'的次数；"
          "本版以实际变化为准，所以它们不进任何指标）")

    print("\n" + "=" * 96)
    print("E0b 采样改造：一次只动一个因素（★ 归因已拆开）")
    print("=" * 96)
    print(f"{'配置':30s} {'裸dup':>8} {'SAFEdup':>9} {'SLOTdup':>9} "
          f"{'裸FN':>7} {'SLOTFN':>7}")
    for s in e0b["summary"]:
        print(f"{s['config']:30s} {s['bare_dup']:>8.2f} {s['safe_dup']:>9.2f} "
              f"{s['slot_dup']:>9.2f} {s['bare_fn']:>7.3f} {s['slot_fn']:>7.3f}")
    print()
    print("  单因素归因（每行的 Δ 只归给那一个因素）:")
    for a in e0b["attribution"]:
        print(f"    {a['label']:22s} 裸dup Δ={a['bare_dup_delta']:>+7.2f}  "
              f"槽位dup Δ={a['slot_dup_delta']:>+7.2f}")
    it = e0b["interaction"]
    print(f"    三项合计 裸dup Δ={e0b['total']['bare_dup_delta']:>+7.2f}  "
          f"槽位dup Δ={e0b['total']['slot_dup_delta']:>+7.2f}  "
          f"（各单因素之和 "
          f"{e0b['sum_of_parts']['bare_dup_delta']:+.2f} / "
          f"{e0b['sum_of_parts']['slot_dup_delta']:+.2f}）")
    print(f"    交互项     裸dup {it['bare_dup_delta']:>+7.2f}  "
          f"槽位dup {it['slot_dup_delta']:>+7.2f}"
          f"  ← 不为 0，说明因素之间有耦合，不能把总差额平均摊给三项")

    print("\n" + "=" * 96)
    print("E4 策略并排（lam=1，FP 分母=同工具诱饵）")
    print("=" * 96)
    print(f"{'策略':26s} {'FN':>7} {'FP':>7} {'跨工具':>7} {'键/ep':>7} "
          f"{'重复':>8} {'漏做':>8} {'总代价':>8}")
    for s in e4["summary"]:
        print(f"{s['strategy']:26s} {s['fn_mean']:>7.3f} {s['fp_mean']:>7.3f} "
              f"{s['ns_mean']:>7.3f} {s['keys_per_ep']:>7.2f} "
              f"{s['dup_mean']:>8.2f} {s['miss_mean']:>8.2f} {s['total_mean']:>8.2f}")

    print("\n" + "=" * 96)
    print("E4 持久化操作 ID 基线（三类事件）")
    print("=" * 96)
    print(f"{'工具':22s} {'策略':20s} {'事件':>5} {'重复':>5} {'漏做':>5} {'冲突':>5} {'总代价':>8}")
    for r in e4["opid_baseline"]["rows"]:
        print(f"{r['tool']:22s} {r['strategy']:20s} {r['n_events']:>5} "
              f"{r['dup']:>5} {r['miss']:>5} {r['conflict']:>5} {r['total']:>8.2f}")

    print("\n" + "=" * 96)
    print(f"E5 隐藏测试集（{e5['n_holdout']} 对 = 正例 {e5['n_pos']} + 负例 {e5['n_neg']}）")
    print("  ★ 其中 2 条正例已被用于开发（首跑 6/8 暴露契约实现不一致后据此改过代码），")
    print("    下面同时给「全量」与「扣除已污染项」两行；后者才是泛化证据。")
    print("=" * 96)
    print(f"{'策略':24s} {'正例合并':>12s} {'负例误合并':>12s} {'选择性拒绝':>12s} {'漏合并':>7s}")
    for r in e5["holdout"]:
        print(f"  {r['strategy']:22s} "
              f"{r['correct_merge']:>3}/{r['n_pos']:<3}({r['correct_merge_rate']:.2f}) "
              f"{r['wrong_merge']:>3}/{r['n_neg']:<3}({r['wrong_merge_rate']:.2f}) "
              f"{r['selective_reject']:>3}/{r['n_neg']:<3}({r['selective_reject_rate']:.2f}) "
              f"{r['miss_merge']:>3}")
        if r["wrong_kinds"]:
            print(f"{'':26s}误合并: {r['wrong_kinds']}")
        if r["n_used_in_dev"]:
            print(f"{'':26s}扣除已污染项后: "
                  f"正例 {r['correct_merge_clean']}/{r['n_pos_clean']}, "
                  f"负例误合 {r['wrong_merge_clean']}/{r['n_neg_clean']}, "
                  f"选择性拒绝 {r['selective_reject_clean']}/{r['n_neg_clean']}")
    print("\n  极端对照（自证三个数确实关掉了「只报碰撞率」的漏洞）:")
    for r in e5["sanity"]:
        print(f"  {r['strategy']:24s} "
              f"正例合并 {r['correct_merge']:>2}/{r['n_pos']:<2} "
              f"负例误合 {r['wrong_merge']:>2}/{r['n_neg']:<2} "
              f"选择性拒绝 {r['selective_reject']:>2}/{r['n_neg']:<2}")
    print("  —— 永不合并的策略负例误合 0、碰撞率 0，看上去最安全，但它一次都没合并成；")
    print("     恒为同键的策略正例合并 8/8，却是靠把 20 条负例全并掉换来的。")
    print("     这两个极端正是第二版只报碰撞率时无法区分的。")

    print("\n" + "=" * 96)
    print("E3 λ → 最优规则集（32 子集穷举）")
    print("=" * 96)
    print(f"{'lam':>6} {'规则数':>6} {'重复':>8} {'漏做':>8} {'总代价':>9}  规则")
    for r in e3["rows"]:
        print(f"{r['lam']:>6.2f} {r['n_rules']:>6} {r['dup']:>8.2f} "
              f"{r['miss']:>8.2f} {r['total']:>9.2f}  "
              f"{','.join(r['rule_keys']) or '(none)'}")

    print("\n" + "=" * 96)
    print("E7 单条规则审计（相对仅 SAFE）")
    print("=" * 96)
    print(f"{'规则':16s} {'危险度':>6} {'Δ重复':>8} {'Δ漏做':>8} {'Δ总代价':>9} {'ΔFP':>8}")
    for s in sorted(e7["single"], key=lambda x: x["d_total"]):
        print(f"{s['rule']:16s} {s['danger']:>6.2f} {s['d_dup']:>+8.2f} "
              f"{s['d_miss']:>+8.2f} {s['d_total']:>+9.2f} {s['d_fp']:>+8.3f}")

    print("\n顺序依赖测试:")
    for t in e7["order_tests"]:
        print(f"  {','.join(t['rule_keys']) or '(none)':40s} "
              f"正序 {t['forward_total']:.2f} 反序 {t['reversed_total']:.2f} "
              f"Δ={t['delta']:+.3f} {'（依赖顺序）' if t['order_dependent'] else '（无关）'}")

    # E8 是报告里最关键的失效边界证据，必须打印出来，不能只写进 json。
    print("\n" + "=" * 100)
    print(f"E8 四类事件上的按期望动作判分（{e8['n_events']} 对事件）")
    print("=" * 100)
    print("事件构成: " + "，".join(
        f"{EVENT_CN[et]} {e8['n_by_type'][et]}" for et in EVENT_TYPES))
    print()
    print("期望动作: 原样重放=复用  保义改写=复用  真实变义=拒绝  新意图=执行")
    print("✓ 对 / ✗ 错。'误杀'=该复用却没并；'吞掉'=真变义被并进同一个键")
    print()
    for nm in ("裸参数哈希", "仅 SAFE", "SAFE+全部RISKY", "槽位投影", "持久化操作 ID"):
        print(f"  {nm}")
        for et in EVENT_TYPES:
            r = next((x for x in e8["rows"]
                      if x["strategy"] == nm and x["event_type"] == et), None)
            if r is None:
                continue
            detail = ""
            if et in ("replay", "replan_equiv"):
                detail = f"误杀 {r['false_reject']}"
            elif et == "replan_change":
                detail = f"吞掉 {r['swallowed']}"
            else:
                detail = f"抑制 {r['miss']}"
            print(f"    {EVENT_CN[et]:14s} {r['ok']:>3}/{r['n']:<4} 对"
                  f"   {detail}")
        print()
    print("要点一：'冲突'这个词现在只留给第三类（同身份 + 真变义 + 键却并上）。")
    print("        第二版把 53 次**保义改写**也算进冲突，那是把自己的成功记成事故。")
    print("要点二：任何只看参数键的策略，在第四类（新意图）上必然全错——")
    print("        参数可能完全相同，只有持久化身份能分开。这是原理性上界。")


if __name__ == "__main__":
    main()