"""
refute_log.py — 反例复现包：在**同一张表**里并排放 v1 与 v2 的键。

跑法：
    cd src && python refute_log.py

输出：data/refutation.json + 控制台表格

为什么不是"写一段话承认错误"
--------------------------
审阅方第三节要求："上面每一处各写一个最小反例——三五行参数就够——跑一遍，
把生成的键打印出来。" 一段话无法被独立核验，一个能重跑的对照表可以。

v1 代码从哪里来（第四轮改，定稿修订单第六章）
--------------------------------------------------
第三版是从**固定提交** 31961e12 现场取出并核对 blob SHA，理由是"不用 HEAD"——
HEAD 会随提交移动，那时"v1 会撞"就变成对另一份代码的断言。

但那个做法有一个交付级缺陷：它假设**收件人手里有那个 commit**。
定稿修订单收到的是 ZIP，解压后 `git log` 直接返回 not a git repository，
于是 `git show 31961e12:src/universe.py` 抛 128，历史反例入口在收件人手里是断的。
更糟的是：那时候脚本打印了两行 `!!` 之后 `return`，**退出码仍然是 0**——
一个失败被记成了一次成功。修订单专门点了这一条。

现在按修订单给的路线 B 改（承认没有 Git，改用快照），取码顺序变成：

  1. 先试 git。能取到，并且 blob SHA 与声明一致 → 判为 `verified_git`
     （这是最强的一种：证明"内容等于该提交"）。
  2. git 取不到（没有仓库、没有那个 commit、没有装 git），退回读**随包快照**
     src/_v1_snapshot/，用 `git hash-object` 现算 blob SHA 比对 → 判为 `verified_snapshot`
     （这只证明"内容未被改动"，不证明"来自那个提交"——两种强度必须分开写）。
  3. 两条路都失败 → 打印 `!!`，**以非零退出码结束**。

第 2 条之所以现在成立，是因为 .gitignore 里那个 `src/_v1_snapshot/` 已经去掉：
既然改用快照，快照就得真的在包里。
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import subprocess
import sys
from typing import Any, Dict, List, Optional

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "data")
V1DIR = os.path.join(HERE, "_v1_snapshot")


class SnapshotError(RuntimeError):
    """v1 快照取不到或校验不过。**必须**转成非零退出码，不能只打印警告。"""

CASES: List[Dict[str, Any]] = []


def case(cid: str, claim: str, section: str, tool: str,
         a: Dict[str, Any], b: Dict[str, Any],
         expect: str = "collide", why: str = "",
         tool_b: Optional[str] = None):
    """
    expect:
      'collide' —— 审阅方称 v1 会把这两个不同操作并成一个键（缺陷，v2 必须分开）
      'differ'  —— 审阅方称 v1 丢掉了这个差别（缺陷，v2 必须分开）
      'merge'   —— 审阅方称 v1 没合并这两个同义写法（缺陷，v2 必须合并）
    """
    CASES.append({"id": cid, "claim": claim, "section": section, "tool": tool,
                  "tool_b": tool_b or tool,
                  "a": a, "b": b, "expect": expect, "why": why})


# --------------------------------------------------------------------------
# 第二节 · 时间语义（三条）
# --------------------------------------------------------------------------
case("T1", "MonthSyn 把 2026-08-01 当成 2026-08 的保义写法", "2-1",
     "query_region_stats",
     {"region": "南海北部", "month": "2026-08"},
     {"region": "南海北部", "month": "2026-08-01"},
     "differ", "月精度与日精度是两次不同操作，不该并")

case("T2", "同一月份内两天（8/01 与 8/15）的两份统计", "2-2",
     "query_region_stats",
     {"region": "南海北部", "month": "2026-08-01"},
     {"region": "南海北部", "month": "2026-08-15"},
     "differ", "如果采日精度，这两天是不同操作")

case("T3", "无年份的'8月'是否被无条件等同于 2026-08", "2-3",
     "query_region_stats",
     {"region": "南海北部", "month": "2026-08"},
     {"region": "南海北部", "month": "8月"},
     "differ", "缺年份不能猜，必须标 ??-08 而不是落到 2026-08")

case("T4", "同一年 8 月的四种真·同义写法", "2-3",
     "query_region_stats",
     {"region": "南海北部", "month": "2026-08"},
     {"region": "南海北部", "month": "2026年8月"},
     "merge", "这一组才是真正保义的别名，必须合并")

# --------------------------------------------------------------------------
# 第三节（一）· schema 声明的字段被无视（四条）
# --------------------------------------------------------------------------
case("S1", "同收件人同主题、不同 body_ref 的两封邮件", "3-1",
     "send_email",
     {"to": "duty@lab.cn", "subject": "S07 异常告警", "body_ref": "B-001"},
     {"to": "duty@lab.cn", "subject": "S07 异常告警", "body_ref": "B-002"},
     "differ", "body_ref 在 schema 里，指向不同正文")

case("S2", "不同 res 的落格请求", "3-1",
     "geocode_region",
     {"region": "南海北部", "res": 7},
     {"region": "南海北部", "res": 9},
     "differ", "res 决定格网密度，7 与 9 是不同产物")

case("S3", "不同 cores 的批作业", "3-1",
     "submit_batch_job",
     {"job_name": "重算_S07_2026-08", "station": "S07", "month": "2026-08",
      "cores": 32},
     {"job_name": "重算_S07_2026-08", "station": "S07", "month": "2026-08",
      "cores": 64},
     "differ", "cores 是资源声明，改变产物形态与配额")

case("S4", "不同 coverage 的落格请求", "3-1",
     "geocode_region",
     {"region": "南海北部", "coverage": "all_intersecting"},
     {"region": "南海北部", "coverage": "centroid_only"},
     "differ", "覆盖口径不同，结果集不同")

case("S5", "include_flag_dist 布尔开关（是否附带标志分布）", "3-1",
     "query_region_stats",
     {"region": "南海北部", "month": "2026-08", "include_flag_dist": True},
     {"region": "南海北部", "month": "2026-08", "include_flag_dist": False},
     "differ", "是否返回标志分布列，改变决议所依赖的信息")

# --------------------------------------------------------------------------
# 第三节（二）· 残余把数字删了（两条）
# --------------------------------------------------------------------------
case("S6", "备注'温度偏差1度' vs '温度偏差2度'", "3-2",
     "write_qc_note",
     {"station": "S07", "month": "2026-08", "note": "温度偏差1度"},
     {"station": "S07", "month": "2026-08", "note": "温度偏差2度"},
     "differ", "r\"\\d\" 把 1 和 2 一起删了")

case("S7", "备注里两个不同日期的自由文本", "3-2",
     "write_qc_note",
     {"station": "S07", "month": "2026-08", "note": "采集异常，8月3日复测通过"},
     {"station": "S07", "month": "2026-08", "note": "采集异常，8月9日复测通过"},
     "differ", "日信息在残余归一里被删")

case("S8", "自由文本语序相反：'温跃层影响声速' vs '声速影响温跃层'", "3-2",
     "write_qc_note",
     {"station": "S07", "month": "2026-08", "note": "温跃层影响声速"},
     {"station": "S07", "month": "2026-08", "note": "声速影响温跃层"},
     "differ", "字符集合相同、关系相反，词袋化会并掉")

# --------------------------------------------------------------------------
# 第三节（三）· SAFE 是名字不是性质（两条）
# --------------------------------------------------------------------------
case("S9", "备注 '01' 与 '1.0' 是否被转成同一个数", "3-3",
     "write_qc_note",
     {"station": "S07", "month": "2026-08", "note": "01"},
     {"station": "S07", "month": "2026-08", "note": "1.0"},
     "differ", "备注若存原文或编码，01 与 1.0 是两个内容")

case("S10", "邮件主题 'S07' 与 'S-07' 被站号别名套上", "3-3",
     "send_email",
     {"to": "duty@lab.cn", "subject": "S07"},
     {"to": "duty@lab.cn", "subject": "S-07"},
     "differ", "站号别名规则不该无差别套到邮件主题")

# --------------------------------------------------------------------------
# 第三节（四）· 工具命名空间（一条）
# --------------------------------------------------------------------------
case("S11", "两个不同工具、参数恰好完全相同", "3-4", "query_region_stats",
     {"region": "南海北部", "month": "2026-08"},
     {"region": "南海北部", "month": "2026-08"},
     "differ", "跨工具不该共用命名空间；v1 靠评估时跳过掩盖",
     tool_b="query_station_stats")


# --------------------------------------------------------------------------
# v1 快照：固定提交 + blob 校验，**不依赖 HEAD**
# --------------------------------------------------------------------------
# ★ 第三轮修正（审阅方：「第二版改动没有新提交；refute_log.py 依赖可变 HEAD，
#   下一次提交就会出问题」）
#
# 原来写的是 git show HEAD:src/universe.py —— 只要我提交一次，
# "v1" 就变成了"那次提交时的当前版本"，反例包当场失真，而且是**静默失真**：
# 它照样跑、照样打印"v1 撞了"，只是撞的那个东西已经不是 v1 了。
#
# 现在固定到 v1 那次提交的完整 SHA，并逐个文件核对 blob SHA。
# 任何一个对不上就直接报错退出，不降级、不猜测。
V1_COMMIT = "31961e1277722885051f875110c57cb6eb223dfb"
V1_BLOBS = {
    "universe.py": "a90344c019f73a9fcd8595abb7a3c130925d2e0b",
    "policy.py": "2fcd8d781ebc421d2a646e9a8cabff5fb236e9d1",
    "structured.py": "29eda1ef61dcc4cf2158f4dee059f08ef3e77527",
}


def _blob_sha1(path: str) -> str:
    """
    Git blob SHA-1：对 "blob <len>\\0<content>" 求 SHA-1。

    这里自己算而不是调 `git hash-object`，是为了在**完全没装 git** 的机器上
    也能校验——那正是路线 B 要覆盖的场景。算法与 git 完全一致，
    可以用 `git hash-object <file>` 交叉验证（verify_env.py 里做了这件事）。
    """
    with open(path, "rb") as f:
        data = f.read()
    h = hashlib.sha1()
    h.update(b"blob %d\0" % len(data))
    h.update(data)
    return h.hexdigest()


def _try_git(v1root: str):
    """
    路线 1：从固定提交现场取。返回 (文件名->字节, 说明)；任一环节失败返回 (None, 原因)。
    """
    got = {}
    for name, want in V1_BLOBS.items():
        try:
            blob = subprocess.check_output(
                ["git", "show", f"{V1_COMMIT}:src/{name}"],
                cwd=v1root, stderr=subprocess.PIPE)
            sha = subprocess.check_output(
                ["git", "rev-parse", f"{V1_COMMIT}:src/{name}"],
                cwd=v1root, stderr=subprocess.PIPE).decode().strip()
        except Exception as e:
            return None, f"git 取 {name} 失败：{e}"
        if sha != want:
            return None, f"git 中 src/{name} 的 blob SHA 不符：期望 {want}，实际 {sha}"
        got[name] = blob
    return got, "ok"


def materialize_v1() -> tuple:
    """
    按定稿修订单路线 B 取 v1 代码。返回 (目录, 判定, 说明)。

    判定取值：
      'verified_git'      —— 从固定提交取出且 blob SHA 一致（最强）
      'verified_snapshot' —— 读随包快照且 blob SHA 一致（较弱：只证明未被改动）
    失败时抛 SnapshotError，由 main() 转成非零退出码。
    """
    root = os.path.join(HERE, "..")

    # ---- 路线 1：git ----
    got, why = _try_git(root)
    if got is not None:
        os.makedirs(V1DIR, exist_ok=True)
        for name, blob in got.items():
            with open(os.path.join(V1DIR, name), "wb") as f:
                f.write(blob)
        return V1DIR, "verified_git", "从固定提交取出，blob SHA 已校验"

    git_fail = why

    # ---- 路线 2：随包快照 ----
    missing = [n for n in V1_BLOBS if not os.path.exists(os.path.join(V1DIR, n))]
    if missing:
        raise SnapshotError(
            f"{git_fail}；随包快照也缺文件：{', '.join(missing)}")
    bad = []
    for name, want in V1_BLOBS.items():
        actual = _blob_sha1(os.path.join(V1DIR, name))
        if actual != want:
            bad.append(f"{name}: 期望 {want} 实际 {actual}")
    if bad:
        raise SnapshotError(
            f"{git_fail}；随包快照 blob SHA 不符：" + "；".join(bad))

    return V1DIR, "verified_snapshot", (
        f"{git_fail}；改用随包快照，blob SHA 已校验"
        "（注意：这证明内容未被改动，不证明它来自那个提交）")


def load_v1(v1dir: str):
    """把 v1 三个模块以 _v1_ 前缀载入当前进程，互不污染。"""
    saved = sys.path[:]
    sys.path.insert(0, v1dir)
    for m in ("universe", "policy", "structured"):
        sys.modules.pop(m, None)
    try:
        import policy as v1policy
        import structured as v1structured
    finally:
        # 立刻把 v1 模块改名固定下来，再恢复 v2 的模块
        sys.path[:] = saved
        sys.modules.pop("policy", None)
        sys.modules.pop("structured", None)
        sys.modules.pop("universe", None)
    return v1policy, v1structured


# --------------------------------------------------------------------------
# v2 键
# --------------------------------------------------------------------------
def v2_keys(tool: str, args: Dict[str, Any]) -> Dict[str, str]:
    from contract import KEY_NAMESPACE_SEP            # noqa
    from policy import KeyPolicy
    from structured import StructuredKey

    # 跨工具用例：B 侧其实换了工具，这里用 tool_b 覆盖
    return {
        "SAFE": KeyPolicy(tool, 0.0).key(args),
        "RISKY_ALL": KeyPolicy(tool, 1.0).key(args),
        "SLOT": StructuredKey(tool, derive=True).key(args),
        "SLOT_NODERIVE": StructuredKey(tool, derive=False).key(args),
    }


def v1_keys(v1policy, v1structured, tool: str, args: Dict[str, Any]) -> Dict[str, str]:
    return {
        "SAFE": v1policy.KeyPolicy(tool, 0.0).key(args),
        "RISKY_ALL": v1policy.KeyPolicy(tool, 1.0).key(args),
        "SLOT": v1structured.StructuredKey(tool).key(args),
        "SLOT_NODERIVE": v1structured.StructuredKey(tool, include_residual=False).key(args),
    }


def _ok(expect: str, collide: bool) -> bool:
    if expect == "merge":
        return collide
    return not collide


def main() -> int:
    """
    返回进程退出码：0 = 复现走通；2 = 快照取不到或校验不过。

    ★ 第四轮：这个函数以前返回 None，`return` 掉之后进程仍是 0。
      定稿修订单第六章把这件事写成了交付阻断——"打印了失败，退出码却是 0"，
      等于自己给自己发了一张假的合格证。现在必须显式返回非零。
    """
    try:
        v1dir, verdict, detail = materialize_v1()
    except SnapshotError as e:
        print("!" * 96)
        print("!! 历史反例无法重算，本次运行判为失败（退出码 2）")
        print(f"!! {e}")
        print("!!")
        print("!! 这不是可以忽略的警告：v1 那一侧的键没有被真正算出来，")
        print("!! 下面任何'v1 会撞'的结论都缺证据。修好之前不要把本包算作可复现。")
        print("!" * 96)
        return 2

    v1policy, v1structured = load_v1(v1dir)

    strategies = ["SAFE", "RISKY_ALL", "SLOT", "SLOT_NODERIVE"]
    rows = []

    print("=" * 116)
    print("反例复现包　撞 = 两键相同；分 = 两键不同")
    if verdict == "verified_git":
        print(f"v1 代码取自固定提交 {V1_COMMIT[:8]}（blob SHA 已校验），"
              "在本进程内独立加载（不共享模块状态）")
        print("来源强度：内容等于该提交（最强判据）")
    else:
        print(f"v1 代码取自随包快照 src/_v1_snapshot/（blob SHA 已校验），"
              "在本进程内独立加载（不共享模块状态）")
        print(f"来源强度：内容未被改动，但**不证明**它来自 {V1_COMMIT[:8]}。")
        print(f"退回原因：{detail}")
        print("本包没有 Git 历史，这是路线 B 的正常工作方式，不是异常。")
    print("=" * 116)
    head = (f"{'ID':5s}{'节':6s}{'工具':19s}{'要求':6s}"
            + "".join(f"{'v1·'+s:15s}" for s in strategies)
            + "".join(f"{'v2·'+s:15s}" for s in strategies))
    print(head)
    print("-" * 116)

    for c in CASES:
        tb = c.get("tool_b") or c["tool"]
        ka1 = v1_keys(v1policy, v1structured, c["tool"], c["a"])
        kb1 = v1_keys(v1policy, v1structured, tb, c["b"])
        ka2 = v2_keys(c["tool"], c["a"])
        kb2 = v2_keys(tb, c["b"])
        col1 = {s: ka1[s] == kb1[s] for s in strategies}
        col2 = {s: ka2[s] == kb2[s] for s in strategies}

        cells = ""
        for s in strategies:
            mark = "撞" if col1[s] else "分"
            good = _ok(c["expect"], col1[s])
            cells += f"{mark} {'.' if good else 'X':13s}"
        for s in strategies:
            mark = "撞" if col2[s] else "分"
            good = _ok(c["expect"], col2[s])
            cells += f"{mark} {'.' if good else 'X':13s}"
        tshow = c["tool"] if tb == c["tool"] else f"{c['tool']}→{tb}"
        print(f"{c['id']:5s}{c['section']:6s}{tshow[:19]:19s}{c['expect']:6s}{cells}")

        rows.append({
            **c,
            "v1": {"key_a": ka1, "key_b": kb1, "collide": col1,
                   "correct": {s: _ok(c["expect"], col1[s]) for s in strategies}},
            "v2": {"key_a": ka2, "key_b": kb2, "collide": col2,
                   "correct": {s: _ok(c["expect"], col2[s]) for s in strategies}},
        })

    print("-" * 116)
    print("图例：撞=同键　分=不同键　.= 符合要求　X = 不符合要求")
    print(f"（要求列：differ/collide=必须分开；merge=必须合并）")

    print("\n" + "=" * 116)
    print("按策略统计：有多少条通过了审阅方给的要求")
    print("=" * 116)
    n = len(rows)
    for s in strategies:
        ok1 = sum(1 for r in rows if r["v1"]["correct"][s])
        ok2 = sum(1 for r in rows if r["v2"]["correct"][s])
        print(f"  {s:14s}  v1 {ok1:2d}/{n}   →   v2 {ok2:2d}/{n}")

    print("\n" + "=" * 116)
    print("v1 里最直接的几条：键的原样打印")
    print("=" * 116)
    for r in rows:
        if r["v1"]["collide"]["SLOT"] and r["expect"] != "merge":
            print(f"\n  [{r['id']}] {r['claim']}")
            print(f"    A: {r['v1']['key_a']['SLOT']}")
            print(f"    B: {r['v1']['key_b']['SLOT']}")
            print(f"    → v2 SLOT 已分开：")
            print(f"    A: {r['v2']['key_a']['SLOT']}")
            print(f"    B: {r['v2']['key_b']['SLOT']}")

    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, "refutation.json")
    # v1_snapshot 写成**相对仓库根**的路径，不是绝对路径。
    # 绝对路径会把"我本机的 E:\WorkBuddy\..."写进证据文件：换一台机器解压后
    # 这个字段指向一个不存在的位置，读者会误以为校验失败；而且它泄漏了与本
    # 实验无关的本机目录结构。相对路径在任何解压位置都成立。
    repo_root = os.path.join(HERE, "..")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"cases": rows,
                   "v1_snapshot": os.path.relpath(v1dir, repo_root).replace(os.sep, "/"),
                   "v1_commit": V1_COMMIT,
                   "v1_blobs": V1_BLOBS,
                   "v1_source": verdict,
                   "v1_source_detail": detail,
                   "n_cases": len(rows)}, f, ensure_ascii=False, indent=2)
    print(f"\n写出 {os.path.abspath(path)}")

    # 汇总：这三个策略在 v2 上应当全对。RISKY_ALL 不在此列——它是"全开"的
    # 对照臂，本来就有已知偏差（v2 12/15），拿它当合格线会把正常结果判成失败。
    strict = ["SAFE", "SLOT", "SLOT_NODERIVE"]
    failed = [(r["id"], s) for r in rows for s in strict
              if not r["v2"]["correct"][s]]
    if failed:
        print(f"\n!! v2 自身有 {len(failed)} 处不符合要求：{failed}")
        return 3
    print(f"\nv2 在全部 {len(rows)} 条用例上通过了 {strict} 三种策略的判定；"
          "RISKY_ALL 是已知有偏差的对照臂，不计入合格线。")
    return 0


if __name__ == "__main__":
    sys.exit(main())