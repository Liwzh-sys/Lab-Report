"""
evaluate.py — 在同一套数据、同一把尺子上量所有策略。

本版修正的口径问题（审阅方第五节）
--------------------------------
1. **两个分母并存**。v1 的 E2 用全部 93 对当分母（跨工具虽跳过但分母没减），
   E4 只用 84 对。同一个 31 次碰撞于是给出 0.3333 与 0.3690 两个数。
   本版统一为 `fp_denominator = 同工具诱饵数`，并在结果里显式写出两个数字：
     n_pairs_total / n_pairs_same_tool / fp_denominator
   跨工具碰撞单独作为 `ns_rate` 报告——它衡量的是"键里有没有工具名"，
   与参数归一化不是一回事，混进同一个分母是错的。

2. **fn_by_kind 与 fp_by_kind 填的是同一份数据**。v1 这是个纯粹的 bug：
   FN 的分解恒等于 FP 的分解。本版 fn_by_kind 按"该工具"分解，
   fp_by_kind 按"诱饵类型"分解，两个字段互不相干。

3. **make_pairs(seed) 忽略 seed**。八轮复用的是同一组诱饵，FP 的零标准差
   只说明确定性函数对相同输入给相同输出。本版 make_pairs 显式接受 seed
   并支持 pivot（换一个诱饵对象），或在 seed 不可变时**明确标注**为
   "确定性诱饵集，seed 不参与"。

4. **λ 不是 ρ**。实现里 `dup += extra * c_dup * lam`，lam 只缩放重复侧。
   所以 lam=1 时各工具的真实代价比是 2.5 / 1.25 / 2.0，不是同一个数。
   本版把 lam 的含义写进结果元数据，并给出 C_k(lam) 的解析形式。

目标函数（本版采用审阅方给出的形式）
----------------------------------
    期望损失 = p_retry · E[额外执行] · c_dup
             + p_conflict · P(错误抑制) · c_miss
             + 惩罚项（延迟/核对/拒绝合法请求/维护）

`p_retry` 与 `p_conflict` 是两个**独立**的出现率参数。v1 把 30 个 episode 的
重复损失和诱饵碰撞损失直接相加，等于隐含假设"每个诱饵对出现一次"——
多加一类诱饵最优策略就变，哪怕真实业务一点没变。本版把两个出现率
显式提到外面，默认 baseline 设为 1.0（与 v1 可比），并在敏感性里扫它们。
"""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np

import contract as C
from perturb import RuleBasedPerturber, SampleConfig
from policy import KeyPolicy, RISKY_RULES
from structured import (STRATEGIES, StructuredKey, bare_key, opid_key,
                        safe_key, slot_key)
from universe import (TOOLS, Decoy, EventPair, LogicalOp, build_baseline_ops,
                      build_decoys, build_event_pairs, build_namespace_probes)


# --------------------------------------------------------------------------
# 场景
# --------------------------------------------------------------------------

# 语义标签（这条样本相对首次请求意味着什么）
L_EQUIV = "equiv"        # 保义：同一件事的不同写法 → 期望动作 = 复用
L_CHANGE = "change"      # 变义：同一次操作被重新规划成不同参数 → 期望动作 = 拒绝/报冲突
L_SAME = "same"          # 与首次请求逐字相同 → 期望动作 = 复用
L_NEW = "new_intent"     # 不同身份的新意图 → 期望动作 = 执行

# 期望动作
A_REUSE = "reuse"        # 复用同一个键（合并）
A_REJECT = "reject"      # 拒绝复用，报冲突交上层处置
A_EXECUTE = "execute"    # 必须真的执行（不能合并）

LABEL_CN = {L_SAME: "原样重放", L_EQUIV: "保义改写",
            L_CHANGE: "真实变义", L_NEW: "新意图"}
ACTION_CN = {A_REUSE: "复用", A_REJECT: "拒绝", A_EXECUTE: "执行"}


@dataclass
class Sample:
    """
    一条重试样本，**带身份、语义标签、期望动作**。

    ★ 第三轮新增。第二版的 Episode 只存 `List[Dict]`，于是：
        · 生成器 10% 的 p_drift 真的改了月份/站号，
        · 但到了评估器那里，"真实变义"和"保义改写的另一种写法"
        · 长得一模一样，都被算成"多出一个键 = 重复执行"。
      结果是"工具做对了（拒绝复用），评分表却记成浪费"。

    现在每条样本自带三样东西，判定按期望动作做：
        identity          —— 它属于哪个逻辑操作（op_id）
        semantic_label    —— 保义 / 变义 / 原样 / 新意图
        expected_action   —— 复用 / 拒绝 / 执行
    """
    identity: str
    args: Dict[str, Any]
    branch: str                  # 采样分支：replay / rewrite / drift（采样意图，不是语义）
    semantic_label: str          # 语义标签（按**实际变化**判定，不照抄采样意图）
    expected_action: str
    changed: Tuple[str, ...] = ()


@dataclass
class Episode:
    """
    一个逻辑操作 + 它全部 n 次请求（**含首次请求**）。

    ★ 第三轮修正：第二版 `make_episodes()` 只保留 `p.variants(..., retries)`，
      首次请求被删掉了，后面还在用"不同键数 − 1"算额外执行。于是
      retries=1 时每个 episode 只有一个样本，分裂数结构上必然是 0——
      那个 0 不是算出来的，是被减数丢了。报告又把它解释成"降幅无定义"。
      本版 samples[0] 恒为首次请求。

    口径（写在表头，不靠读者猜）：
      n_requests = len(samples) = retries + 1
      其中 samples[0] 是首次请求，其余是 retries 次重试。
      与"上一版 n 次重试"不是同一个总体，不能直接比。
    """
    op: LogicalOp
    samples: List[Sample]

    # -- 兼容旧调用点 ---------------------------------------------------
    @property
    def variants(self) -> List[Dict[str, Any]]:
        """参数列表（含首次请求）。旧代码按 variants 遍历的地方语义不变。"""
        return [s.args for s in self.samples]

    @property
    def n_requests(self) -> int:
        return len(self.samples)

    @property
    def retries(self) -> int:
        return max(0, len(self.samples) - 1)

    def of_label(self, *labels: str) -> List[Sample]:
        return [s for s in self.samples if s.semantic_label in labels]


DEFAULT_CFG = SampleConfig(p_replay=0.35, p_rewrite=0.55, p_drift=0.10)


def _label_and_action(base: Dict[str, Any], args: Dict[str, Any],
                      branch: str, changed: Tuple[str, ...],
                      cfg: SampleConfig) -> Tuple[str, str]:
    """
    按**实际变化**给出语义标签与期望动作。

    这里不照抄采样分支，因为 `_apply_chain` 在链上算子全都不适用时会原样返回，
    此时分支已计为 drift 但参数一个字段没变。照抄分支会凭空造出"变义被吞掉"。

    判定顺序：
      1. 逐字段完全相同          → 原样重放 → 复用
      2. 抽中 drift 且**真的变了** → 真实变义 → 拒绝（参数已漂移，不能静默复用）
      3. 抽中 rewrite 且真的变了  → 保义改写 → 复用
      4. 抽中 drift 但没变       → 退化为原样重放 → 复用（采样意图落空，如实记为 replay）
    """
    if not changed:
        return (L_SAME if branch == "replay" else L_SAME), A_REUSE
    if branch == "drift":
        return L_CHANGE, A_REJECT
    return L_EQUIV, A_REUSE


def make_episodes(seed: int = 0, retries: int = 4,
                  cfg: Optional[SampleConfig] = None,
                  include_first: bool = True,
                  with_new_intent: bool = False) -> List[Episode]:
    """
    构造 episode。**samples[0] 恒为首次请求。**

    参数
    ----
    retries        : 重试次数。总请求数 = retries + 1（include_first=True 时）
    include_first  : 是否保留首次请求。默认 True；设 False 可复现第二版口径
                     （用于在报告里量化"漏掉首次请求"的影响，不是主口径）
    with_new_intent: 是否给每个 episode 追加一条**参数相同、身份不同**的新意图样本。
                     它检验的是"任何只看参数的键都会把两次独立请求并成一次"，
                     属原理性上界，因此默认不进主结果，由单独实验报告。
    """
    ops = build_baseline_ops()
    p = RuleBasedPerturber(seed=seed, cfg=cfg or DEFAULT_CFG)
    out: List[Episode] = []
    for op in ops:
        samples: List[Sample] = []
        if include_first:
            samples.append(Sample(
                identity=op.op_id, args=dict(op.slots), branch="first",
                semantic_label=L_SAME, expected_action=A_REUSE, changed=()))
        for args, branch, changed in p.branches(op.slots, retries, tool=op.tool):
            lab, act = _label_and_action(op.slots, args, branch, changed,
                                         cfg or DEFAULT_CFG)
            samples.append(Sample(
                identity=op.op_id, args=args, branch=branch,
                semantic_label=lab, expected_action=act, changed=changed))
        if with_new_intent:
            samples.append(Sample(
                identity=f"{op.op_id}#2", args=dict(op.slots), branch="new_intent",
                semantic_label=L_NEW, expected_action=A_EXECUTE))
        out.append(Episode(op, samples))
    return out


def make_pairs(seed: int = 0, pivot: int = 0) -> List[Decoy]:
    """
    诱饵集。

    注意：构造是**确定性的**——同一批基准操作产生同一批诱饵，与 seed 无关。
    v1 的 `make_pairs(seed)` 假装接受 seed 却完全不用，导致"八种子平均"
    的 FP 标准差恒为 0 被解读成"稳定"，其实只是确定性函数的必然结果。
    本版保留 seed 参数（接口不变），但**如实标注** seed 不参与构造，
    并额外提供 pivot 参数：换一个诱饵对象值，让 FP 真的有变异来源。
    """
    ops = build_baseline_ops()
    same = build_decoys(ops)
    if pivot:
        # pivot 只改诱饵那一侧的对象取值，用于检验 FP 对具体取值的敏感性
        same = [_pivot_decoy(d, pivot) for d in same]
    return same + build_namespace_probes()


_PIVOT_POOL = {
    "month": ["2026-11", "2026-12", "2027-01", "2027-02"],
    "region": ["白令海", "马六甲海峡", "东海陆架"],
    "station": ["S31", "B04", "S12"],
    "job_name": ["_all", "_partial", "_only", "_subset"],
    "note": ["温度偏差2度", "温度偏差3度", "盐度异常"],
    "subject": ["补发", "更正", "再次告警"],
    "body_ref": ["B-002", "B-003", "B-004"],
    "res": [5, 9, 11],
    "coverage": ["centroid_only", "all_intersecting", "touching_only"],
    "cores": [64, 128, 16],
    "include_qc": [True, False],
    "include_flag_dist": [True, False],
}


def _pivot_decoy(d: Decoy, pivot: int) -> Decoy:
    """把诱饵那一侧的差异值换成池子里的另一个值。保持"只改一个字段"。"""
    f = d.changed[0] if d.changed else None
    if f is None or f not in _PIVOT_POOL:
        return d
    vals = _PIVOT_POOL[f]
    v = vals[pivot % len(vals)]
    slots = dict(d.decoy.slots)
    slots[f] = v
    if slots == d.src.slots:
        return d
    return Decoy(d.src, LogicalOp(d.decoy.op_id, d.decoy.tool, slots,
                                  d.decoy.family), d.changed, d.kind, d.why)


# --------------------------------------------------------------------------
# 单点评估
# --------------------------------------------------------------------------

@dataclass
class Point:
    """
    一个策略在一套带标签 episode 上的汇总。

    ★ 第四轮（收尾）改动：`dup_cost` 的口径换了。

      第三版及以前：dup_cost = Σ(该 ep 不同键数 − 1) × c_dup
      第四版起    ：dup_cost = Σ{ 该复用却另起了新键的样本 } × c_dup

    旧口径把两件方向相反的事加进同一个数：
      · "该合并却没并"  → 是损失
      · "该分开且分开了"（真实变义被正确拒绝）→ 是**做对了**
    于是工具正确拒绝一次变义，评分表就记一次重复执行损失。
    最小的反例是两次同身份请求、第二次真改了月份：conflict_rejected=1
    的同时 dup_cost=1，同一件事两个判断互相矛盾。

    旧口径没有删除，改名为 `dup_cost_legacy`，只用于与历史数值对表；
    它的计数部分 `split_score` 保留为**诊断量**，正名为"参数键分裂分数"。
    """
    alpha: float
    n_risky: int
    label: str
    fn_rate: float
    fp_rate: float
    ns_rate: float
    dup_cost: float              # ★ 主指标：仅保义重复代价（该复用却拆开）
    miss_cost: float
    total_cost: float
    n_split_episodes: int
    keys_per_episode: float
    fp_denominator: int
    fn_by_tool: Dict[str, float] = field(default_factory=dict)
    fp_by_kind: Dict[str, float] = field(default_factory=dict)
    fp_examples: List[Dict[str, Any]] = field(default_factory=list)
    # ★ 第三轮：五个必须分开的计数（审阅方第四节（三））
    #   1 保义重试被错误拆开   equiv_split
    #   2 真实变义被静默吞掉   change_swallowed
    #   3 合法新意图被抑制     newintent_suppressed
    #   4 冲突被正确拒绝       conflict_rejected
    #   5 合法请求被错误拒绝   legit_rejected
    counts: Dict[str, int] = field(default_factory=dict)
    n_requests: int = 0
    n_episodes: int = 0
    # ---- 诊断量（不是结论，不能当重复成本用）--------------------------------
    # 参数键分裂分数：全样本额外键数 Σ(不同键数 − 1)。
    # 它衡量"键分得多细"，与"多花了多少次执行"不是同一个量：
    # 真实变义、不同身份新意图都会让它升高，而那两种分开是**正确行为**。
    split_score: float = 0.0
    # 旧口径成本，只与第三版及以前的数值对表用
    dup_cost_legacy: float = 0.0


# --------------------------------------------------------------------------
# ★ 第四轮：重复代价的**唯一**实现
# --------------------------------------------------------------------------
# 终审单第三节（一）第二段：「E3 的规则搜索、细扫，还有 E7 的规则审计，
# 又各自直接用全样本的 len(keys)-1 重算了一遍旧代价。」
# 三处各自重写同一个量，改一处漏两处是必然的。所以本版把它收敛成一个函数，
# E3 / E7 / 主表全部调用它，不再有任何一处自己数键。
#
# 返回三个量，单位都是"单次重复成本 c_dup"，还没乘 lam 与 p_retry：
#   equiv_unit —— 仅"该复用却另起新键"的那些样本，Σ c_dup      ← 主指标用这个
#   legacy_unit—— 全样本额外键 Σ(nk−1)·c_dup                  ← 历史对照用
#   extra_keys —— 全样本额外键数 Σ(nk−1)                       ← 诊断量用

def dup_units(episodes: Sequence[Episode],
              keyfn: Callable[[str, Dict[str, Any]], str]) -> Dict[str, float]:
    """
    算一个 keyfn 在给定 episode 上的重复侧三个量。**全项目只此一份**。

    逐样本判定的原因：只有看到每条样本的 expected_action，才能区分
    "这个新键是损失"还是"这个新键是做对了"。只看键数根本分不出来。
    """
    equiv_unit = 0.0
    legacy_unit = 0.0
    extra_keys = 0.0
    for ep in episodes:
        first_key = keyfn(ep.op.tool, ep.samples[0].args)
        seen = {first_key}
        for s in ep.samples:
            k = keyfn(ep.op.tool, s.args)
            if k in seen:
                continue
            seen.add(k)
            # 这个新键该不该出现？只有期望动作为"复用"时，多出一个键才是损失。
            # 期望动作是 reject / execute 的样本另起键，是策略**执行正确**。
            if s.expected_action == A_REUSE:
                equiv_unit += ep.op.c_dup
        ex = len(seen) - 1
        extra_keys += ex
        legacy_unit += ex * ep.op.c_dup
    return {"equiv_unit": equiv_unit, "legacy_unit": legacy_unit,
            "extra_keys": extra_keys}


def _summarize(keys_per_ep: List[int], episodes, pairs: List[Decoy],
               keyfn: Callable[[str, Dict[str, Any]], str],
               lam: float, p_retry: float, p_conflict: float,
               alpha: float = 0.0, rule_keys=None,
               on_miss: str = "execute") -> Point:
    """
    汇总一个策略在**一套带标签的 episode** 上的表现。

    on_miss 决定"键没对上时调用方做什么"，这是策略之外的一层选择，
    但它决定了同一个事件该记成哪一种错：
        execute —— 当成新操作再执行一次（默认，也是第二版隐含的行为）
        reject  —— 报冲突拒绝复用，等上层处置（严格字节冻结就是这种）
    同一次"保义改写生成新键"，在 execute 下是**重复执行**，
    在 reject 下是**误杀好请求**。两种代价方向相反，不能混在一个数里。
    """
    n_ep = len(episodes)
    n_split = 0
    by_tool_hit: Dict[str, int] = defaultdict(int)
    by_tool_tot: Dict[str, int] = defaultdict(int)

    # ---- 五个计数 ---------------------------------------------------------
    cnt = {
        "equiv_split": 0,          # 1 保义重试被错误拆开 → 重复执行
        "change_swallowed": 0,     # 2 真实变义被静默吞掉
        "newintent_suppressed": 0, # 3 合法新意图被抑制
        "conflict_rejected": 0,    # 4 冲突被正确拒绝（没并进同一个键）
        "legit_rejected": 0,       # 5 合法请求被错误拒绝（误判成冲突）
        "ok_reuse": 0,             #    该复用且复用了
        "ok_execute": 0,           #    该执行且执行了
        "drift_dup_merge": 0,      #    （中性）两次相同漂移并成一键：不算错
    }
    # 额外执行按**引起它的那条样本的语义**归因，而不是笼统算成一堆
    extra_by_label = {L_SAME: 0, L_EQUIV: 0, L_CHANGE: 0, L_NEW: 0}
    n_requests = 0

    for ep, nk in zip(episodes, keys_per_ep):
        by_tool_tot[ep.op.tool] += 1
        if nk > 1:
            n_split += 1
            by_tool_hit[ep.op.tool] += 1

        samples = ep.samples
        n_requests += len(samples)
        first_key = keyfn(ep.op.tool, samples[0].args)
        seen = {first_key}
        for s in samples[1:]:
            k = keyfn(ep.op.tool, s.args)
            at_first = (k == first_key)      # 与**首次请求**同键
            seen_before = k in seen
            if not seen_before:
                seen.add(k)
                extra_by_label[s.semantic_label] += 1

            if s.expected_action == A_REUSE:
                if at_first or seen_before:
                    cnt["ok_reuse"] += 1
                elif on_miss == "reject":
                    cnt["legit_rejected"] += 1     # 该复用却被拒 → 误杀
                else:
                    cnt["equiv_split"] += 1        # 该复用却另起一次 → 重复执行
            elif s.expected_action == A_REJECT:
                if at_first:
                    # 参数已经漂移，键却和首次请求完全一样 → 变义被吞
                    cnt["change_swallowed"] += 1
                elif seen_before:
                    # 与另一条**同样漂移过**的样本合并：漂移方向一致，不算事故
                    cnt["drift_dup_merge"] += 1
                else:
                    cnt["conflict_rejected"] += 1  # 没并 → 冲突没被吞
            else:                                   # A_EXECUTE
                if seen_before:
                    cnt["newintent_suppressed"] += 1
                else:
                    cnt["ok_execute"] += 1

    # ---- 重复侧：唯一实现，见 dup_units() --------------------------------
    # ★ 第四轮：主指标切到"仅保义重复代价"（终审单第三节 P0）。
    #   旧口径保留为 dup_cost_legacy / split_score 两个诊断量。
    _du = dup_units(episodes, keyfn)
    dup_cost = _du["equiv_unit"] * lam * p_retry
    dup_cost_legacy = _du["legacy_unit"] * lam * p_retry
    split_score = _du["extra_keys"]

    # FP：分母**只**数同工具诱饵；跨工具探针单独算 ns_rate
    same_tool = [d for d in pairs if d.kind != "跨工具"]
    ns = [d for d in pairs if d.kind == "跨工具"]

    collide = 0
    miss_cost = 0.0
    kind_hit: Dict[str, int] = defaultdict(int)
    kind_tot: Dict[str, int] = defaultdict(int)
    examples: List[Dict[str, Any]] = []
    for d in same_tool:
        kind_tot[d.kind] += 1
        ka = keyfn(d.src.tool, d.src.slots)
        kb = keyfn(d.decoy.tool, d.decoy.slots)
        if ka == kb:
            collide += 1
            kind_hit[d.kind] += 1
            miss_cost += d.decoy.c_miss
            if len(examples) < 8:
                examples.append({"kind": d.kind, "tool": d.src.tool,
                                 "key": ka, "lost": d.src.slots,
                                 "absorbed": d.decoy.slots})
    miss_cost *= p_conflict

    ns_collide = 0
    for d in ns:
        if keyfn(d.src.tool, d.src.slots) == keyfn(d.decoy.tool, d.decoy.slots):
            ns_collide += 1
            miss_cost += d.decoy.c_miss * p_conflict

    pol = KeyPolicy("query_region_stats", alpha, rule_keys=rule_keys)
    extra_by_label_out = dict(extra_by_label)
    return Point(
        alpha=alpha,
        n_risky=pol.n_risky,
        label=pol.describe(),
        fn_rate=n_split / n_ep if n_ep else 0.0,
        fp_rate=collide / len(same_tool) if same_tool else 0.0,
        ns_rate=ns_collide / len(ns) if ns else 0.0,
        dup_cost=dup_cost,
        miss_cost=miss_cost,
        # 只有声明了成本模型才允许合并成一个标量；模型的假设写在
        # contract.COST_ASSUMPTIONS 里，报告必须一并给出。
        total_cost=C.total_cost(dup_cost, miss_cost),
        n_split_episodes=n_split,
        # ★ 第四轮：键/ep 也改成从 dup_units 的 extra_keys 派生。
        #   原来这里另有一个 extra_total 累加 (nk-1)，与 split_score 是同一个量
        #   的第二份实现——两处一旦不一致，键/ep 与分裂分会给出不同的话。
        keys_per_episode=_du["extra_keys"] / n_ep + 1.0 if n_ep else 0.0,
        fp_denominator=len(same_tool),
        fn_by_tool={k: by_tool_hit[k] / by_tool_tot[k]
                    for k in by_tool_tot if by_tool_tot[k]},
        fp_by_kind={k: kind_hit[k] / kind_tot[k]
                    for k in kind_tot if kind_tot[k]},
        fp_examples=examples,
        counts={**cnt,
                # 这三个已从 counts 提到 Point 顶层，这里保留同名字段是为了
                # 让旧的核对脚本（读 counts["dup_cost_equiv_only"]）继续能读到，
                # 且保证与 Point.dup_cost 是同一次计算的结果，不可能分叉。
                "dup_cost_equiv_only": round(dup_cost, 6),
                "dup_cost_legacy": round(dup_cost_legacy, 6),
                "split_score": round(split_score, 6),
                **{f"extra_{k}": v for k, v in extra_by_label_out.items()}},
        n_requests=n_requests,
        n_episodes=n_ep,
        split_score=split_score,
        dup_cost_legacy=dup_cost_legacy,
    )


def eval_point(episodes: List[Episode], pairs: List[Decoy], alpha: float,
               lam: float = 1.0, p_retry: float = 1.0,
               p_conflict: float = 1.0, on_miss: str = "execute") -> Point:
    keys_per_ep: List[int] = []
    for ep in episodes:
        pol = KeyPolicy(ep.op.tool, alpha)
        keys_per_ep.append(len({pol.key(v) for v in ep.variants}))
    return _summarize(keys_per_ep, episodes, pairs,
                      lambda t, a: KeyPolicy(t, alpha).key(a),
                      lam, p_retry, p_conflict, alpha=alpha, on_miss=on_miss)


def eval_strategy(episodes: List[Episode], pairs: List[Decoy],
                  name: str, keyfn: Callable[[str, Dict[str, Any]], str],
                  lam: float = 1.0, p_retry: float = 1.0,
                  p_conflict: float = 1.0, on_miss: str = "execute") -> Point:
    keys_per_ep = [len({keyfn(ep.op.tool, v) for v in ep.variants})
                   for ep in episodes]
    p = _summarize(keys_per_ep, episodes, pairs, keyfn, lam, p_retry, p_conflict,
                   on_miss=on_miss)
    p.label = name
    return p


# --------------------------------------------------------------------------
# 持久化操作 ID 基线（审阅方第六节（一））
# --------------------------------------------------------------------------

def eval_opid_baseline(episodes: List[Episode], pairs: List[Decoy],
                       events: List[EventPair],
                       tools: Optional[Sequence[str]] = None,
                       lam: float = 1.0) -> Dict[str, Any]:
    """
    持久化操作 ID 基线：键 = 应用侧生成并持久化的 op_id，与参数无关。

    ★ 第三轮把这条基线的**信息条件**标清楚（审阅方第七节（三））。
      代码直接拿生成器给的 id_a / id_b 来比，所以"同身份合并、新身份分开"
      在构造上就成立。它没有持久化存储、没有响应重放、没有参数校验、
      没有冲突抛出——**它只是在计数**。
      所以"全 0 错误"不能读成"完整工程方案已验证"。

      它比参数策略多拿了一样东西：**参数之外的可靠身份**。
      这个差异必须写出来，否则并排比较就是在比"有身份信息"和"没身份信息"，
      而不是比"两种键的构造方式"。收窄说法：
        能证明的是——只靠参数无法还原身份，需要参数之外的可靠身份或上下文信息；
        不能证明的是——只有持久化操作 ID 这一条路径。
        （业务事件 ID、任务步骤身份、显式意图版本同样可行，本实验没有排除它们。）

    它在四类事件上的表现是**结构性**的，不是跑出来的统计：
      · 原样重放（身份同、参数同）    → 同 op_id → 合并 ✓
      · 同身份保义改写（身份同、语义同）→ 同 op_id → 合并 ✓
      · 同身份真实变义（身份同、语义变）→ 同 op_id → 合并，
        但必须**额外做参数校验**才不至于静默复用。这一步本基线没有实现，
        所以它在第三类上会显示"吞掉"——这恰恰说明身份并不能替代校验。
      · 不同身份新意图（身份不同、参数可同）→ 不同 op_id → 分开 ✓
    """
    rows = []
    if tools is None:
        tools = sorted({e.tool for e in events})
    for tool in tools:
        sub_events = [e for e in events if e.tool == tool]

        def judge(keyfn, use_identity: bool):
            dup = miss = conflict = 0
            for e in sub_events:
                if use_identity:
                    ka, kb = f"opid|{e.id_a}", f"opid|{e.id_b}"
                else:
                    ka = keyfn(e.tool, e.a)
                    kb = keyfn(e.tool, e.b)
                same = (ka == kb)
                if e.expected_action == "reuse" and not same:
                    dup += 1                       # 该合并没合并 → 重复执行
                elif e.expected_action == "execute" and same:
                    miss += 1                      # 新意图被合并 → 错误抑制
                elif e.expected_action == "reject" and same:
                    conflict += 1                  # 真变义被吞 → 这才是冲突
            return dup, miss, conflict

        for nm, use_id in (("持久化操作 ID", True), ("槽位投影（参数键）", False)):
            dup, miss, conflict = judge(slot_key, use_id)
            rows.append({
                "tool": tool, "strategy": nm, "n_events": len(sub_events),
                "dup": dup, "miss": miss, "conflict": conflict,
                "dup_cost": dup * TOOLS[tool]["c_dup"] * lam,
                "miss_cost": miss * TOOLS[tool]["c_miss"],
                "total": C.total_cost(dup * TOOLS[tool]["c_dup"] * lam,
                                               miss * TOOLS[tool]["c_miss"]),
            })

    # 汇总：按策略合计，供与 E8 并排对照（同一套事件、同一指标定义）
    summary = []
    for nm in ("持久化操作 ID", "槽位投影（参数键）"):
        rs = [r for r in rows if r["strategy"] == nm]
        per_type = {}
        for et in ("replay", "replan_equiv", "replan_change", "new_intent"):
            d = m = c = 0
            for e in events:
                if e.event_type != et:
                    continue
                same = _same_key(nm, e)
                if e.expected_action == "reuse" and not same:
                    d += 1
                elif e.expected_action == "execute" and same:
                    m += 1
                elif e.expected_action == "reject" and same:
                    c += 1
            per_type[et] = {"n": sum(1 for e in events if e.event_type == et),
                            "dup": d, "miss": m, "conflict": c}
        summary.append({"strategy": nm, "n_events": len(events),
                        "dup": sum(r["dup"] for r in rs),
                        "miss": sum(r["miss"] for r in rs),
                        "conflict": sum(r["conflict"] for r in rs),
                        "total": sum(r["total"] for r in rs),
                        "by_event_type": per_type})
    return {"rows": rows, "summary": summary}


def _same_key(strategy: str, e) -> bool:
    """某个策略在单条事件上是否并成同一个键。与 eval_opid_baseline 内判定一致。"""
    if strategy == "持久化操作 ID":
        return e.id_a == e.id_b
    return slot_key(e.tool, e.a) == slot_key(e.tool, e.b)


# --------------------------------------------------------------------------
# 扫描
# --------------------------------------------------------------------------

def _m(xs):
    return float(np.mean(xs)) if len(xs) else 0.0


def _sd(xs):
    return float(np.std(xs, ddof=1)) if len(xs) > 1 else 0.0


def sweep_alphas(seeds=(0, 1, 2, 3, 4), retries: int = 4, lam: float = 1.0,
                 steps: int = 21, pivot: int = 0,
                 cfg: Optional[SampleConfig] = None) -> List[Point]:
    alphas = [i / (steps - 1) for i in range(steps)]
    out = []
    for al in alphas:
        acc = defaultdict(list)
        for s in seeds:
            eps = make_episodes(seed=s, retries=retries, cfg=cfg)
            prs = make_pairs(seed=s, pivot=pivot)
            p = eval_point(eps, prs, al, lam=lam)
            acc["fn"].append(p.fn_rate)
            acc["fp"].append(p.fp_rate)
            acc["dup"].append(p.dup_cost)
            acc["dup_legacy"].append(p.dup_cost_legacy)
            acc["split"].append(p.split_score)
            acc["miss"].append(p.miss_cost)
            acc["total"].append(p.total_cost)
        pol = KeyPolicy("query_region_stats", al)
        out.append(Point(
            alpha=al, n_risky=pol.n_risky, label=pol.describe(),
            fn_rate=_m(acc["fn"]), fp_rate=_m(acc["fp"]), ns_rate=0.0,
            dup_cost=_m(acc["dup"]), miss_cost=_m(acc["miss"]),
            total_cost=_m(acc["total"]), n_split_episodes=0,
            keys_per_episode=0.0, fp_denominator=0,
            split_score=_m(acc["split"]),
            dup_cost_legacy=_m(acc["dup_legacy"]),
        ))
    return out


if __name__ == "__main__":
    eps = make_episodes(seed=0)
    prs = make_pairs(seed=0)

    print("=" * 92)
    print("事件集与诱饵集规模")
    print("=" * 92)
    same = [d for d in prs if d.kind != "跨工具"]
    ns = [d for d in prs if d.kind == "跨工具"]
    print(f"  基准操作 {len(eps)} 个；每个 episode {eps[0].n_requests} 次请求 "
          f"= 首次 1 + 重试 {eps[0].retries}")
    print(f"  诱饵 {len(prs)} 对 = 同工具 {len(same)} + 跨工具 {len(ns)}")
    print(f"  FP 分母 = 同工具诱饵数 = {len(same)}")

    print("\n" + "=" * 92)
    print("★ P0-2 验收：首次请求加回之后，'重试 1 次'不再是结构性 0")
    print("=" * 92)
    print("  口径：seed=0 单种子（与 E6 的八种子均值不是同一个数，两者不可互引）")
    print("  指标：保义重复代价（第四轮主指标）")
    print(f"{'策略':28s} {'retries=1 不带首请求':>22} {'retries=1 带首请求':>20}")
    for nm, fn in (("裸参数哈希", bare_key), ("仅 SAFE", safe_key),
                   ("槽位投影", slot_key)):
        old = eval_strategy(make_episodes(seed=0, retries=1, include_first=False),
                            prs, nm, fn)
        new = eval_strategy(make_episodes(seed=0, retries=1),
                            prs, nm, fn)
        print(f"{nm:28s} {old.dup_cost:>22.3f} {new.dup_cost:>20.3f}")
    print("  左边恒为 0 是结构性的：只有一个样本时，它自己就是'首次请求'，")
    print("  没有第二条可比，任何口径下都算不出重复。这不是降幅无定义。")

    print("\n" + "=" * 92)
    print("五种策略对照（lam=1, p_retry=p_conflict=1, on_miss=execute）")
    print("=" * 92)
    print(f"{'策略':26s} {'FN':>6} {'FP':>6} {'键/ep':>7} "
          f"{'保义重复':>9} {'旧口径':>8} {'分裂分':>7} {'漏做':>7} "
          f"{'保义拆开':>9} {'变义吞掉':>9} {'新意图抑':>9}")
    for nm, fn in (("裸参数哈希", bare_key), ("仅 SAFE", safe_key),
                   ("SAFE+全部RISKY", lambda t, a: KeyPolicy(t, 1.0).key(a)),
                   ("槽位投影（含守卫替代）", slot_key),
                   ("槽位投影（不含替代）",
                    lambda t, a: StructuredKey(t, derive=False).key(a))):
        p = eval_strategy(eps, prs, nm, fn)
        c = p.counts
        print(f"{nm:26s} {p.fn_rate:>6.3f} {p.fp_rate:>6.3f} "
              f"{p.keys_per_episode:>7.2f} {p.dup_cost:>9.2f} "
              f"{p.dup_cost_legacy:>8.2f} {p.split_score:>7.1f} {p.miss_cost:>7.2f} "
              f"{c['equiv_split']:>9} {c['change_swallowed']:>9} "
              f"{c['newintent_suppressed']:>9}")
    print()
    print("读法（第四轮口径）：")
    print("  '保义重复' = 主指标，只数'该复用却另起新键'的样本 → 真实变义不再计入")
    print("  '旧口径'   = 第三版及以前的 (键数−1)×c_dup，仅用于与历史数值对表")
    print("  '分裂分'   = Σ(键数−1)，诊断量。它衡量键分得多细，**不等于**重复成本")
    print("               真实变义与新意图都会抬高它，而那两种分开是正确的")
    print("  '变义吞掉' 一列，第二版根本不存在——它把这件事记成了'重复执行'")