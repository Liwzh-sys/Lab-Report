"""
structured.py — 核心贡献：键不该建在自由文本上，应建在**结构化槽位**上。

这是我从实验里被数据逼出来的结论，也是本报告最主要的原创点。

问题的发现过程
--------------
实验 A 显示：仅启用 SAFE 规则（别名表 + 类型归一 + schema 裁剪），
重复代价从 64 降到 15，降幅 77%，而假阳性仍是 0。这是纯收益。

但实验 B 暴露了瓶颈：FN 率在 alpha 上几乎不下降，卡在 0.3–0.4。
逐条打印后我看到根因不在"规范化不够狠"，而在于：

    job_name: "recompute_S07_2026-08"
    job_name: "recompute-S07-2026-08"      ← 换个连接符
    job_name: "重算_S07_2026-08"            ← 中文动词
    job_name: "RECOMPUTE_S07_2026-08"      ← 大写

同一个操作，四种写法，产生了 4 个键。任何**文本级**规范化都治不了这个：
"recompute" 和 "重算" 之间没有字符串距离可算，"recompute" 和 "recalc"
的差别在字面上和一个真实的语义改动无法区分。

关键洞察
--------
`job_name` 里**重复编码**了 `station` 和 `month` 两个已经在别的槽位里
存在的字段。也就是说：模型在自由文本里重述了一份结构化信息。

    键 = f(job_name)   ← 自由文本，不可控
    键 = f(station, month, action)   ← 结构化槽位，可控

于是有了"槽位投影"：
    从自由文本里**抽取**出结构化槽位，只用槽位参与键的构成，
    自由文本本身**永不进入键**。

这不是"更强的规范化"，是**换了一个键的定义域**。规范化在文本空间里找等价，
槽位投影直接退到结构化空间——后者的等价关系是有限的、可枚举的、可审的。

为什么它安全
------------
因为"该用哪些槽位"这件事由**工具的 schema 声明**，不由算法猜。
schema 是第7讲课时1 讲的"说明书"，是契约。键建在契约上，
而不是建在模型即兴写出的自然语言上。

代价
----
槽位投影会丢掉自由文本里可能承载的**真实**区别。
比如 note 字段的"疑似"vs"确认"，抽取成槽位就需要一个
assertion_level 槽位；抽取不出来就只能整段进键（回到文本空间）。
所以槽位投影不是万灵药，它要求**schema 本身设计得好**。
这带来一个可直接落地的工程建议：**给有语义的自由文本字段加枚举型槽位**。
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from policy import KeyPolicy, _norm_basic, MONTH_ALIAS, REGION_ALIAS, STATION_ALIAS
from universe import TOOLS


# --------------------------------------------------------------------------
# 槽位抽取器：从自由文本里把结构化信息捞出来
# --------------------------------------------------------------------------

_MONTH_PAT = [
    (re.compile(r"(\d{4})[-_/年]?(\d{1,2})月?"), "ym"),
    (re.compile(r"(\d{1,2})月"), "m"),
]

# 站号：刻意不用 \b —— 下划线在正则里属于"词字符"，而 job_name 里
# 站号几乎总是被下划线包着（recompute_S07_2026-08），\b 在那里不成立。
# 这是第三处踩到的正则陷阱，报告里一并记下。
_STATION_PAT = re.compile(r"(?<![A-Za-z0-9])([sbSB]-?\d{2})(?![0-9])")

_REGION_NAMES = sorted(REGION_ALIAS.keys(), key=len, reverse=True)

# 动作词归一：动词在这里是有意义的（recompute ≠ query ≠ write）
_ACTION_VOCAB = {
    "recompute": "recompute", "recalc": "recompute", "重算": "recompute",
    "rerun": "recompute", "redo": "recompute",
    "query": "query", "查": "query", "查询": "query", "get": "query",
    "write": "write", "写": "write", "写入": "write",
    "send": "send", "发": "send", "发送": "send",
    "geocode": "geocode", "落格": "geocode",
}

# 断言强度：这是**责任相关的**语义，必须成为独立槽位
_ASSERTION = {
    "疑似": "suspected", "疑为": "suspected", "可能存在": "suspected",
    "suspected": "suspected",
    "确认": "confirmed", "已确认": "confirmed", "confirmed": "confirmed",
}


def extract_slots(tool: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """
    从一次工具调用的参数里，抽出一份**结构化槽位**。

    原则：
      1. schema 里声明的结构化字段（station/month/region/to/subject）直接用；
      2. 自由文本字段（job_name/note）只用来**补充**缺失的槽位，本身不进键；
      3. 抽不出的部分，落进 text_sig —— 它是"无法结构化"的残余，
         保留它是为了不漏掉真实差异，但它会把文本噪声带回来。
    """
    slots: Dict[str, Any] = {}
    residual: List[str] = []

    # --- 1. 结构化字段直取 ---
    for k in ("station", "month", "region", "to", "subject"):
        if k in args:
            v = _norm_basic(args[k])
            if k == "month":
                v = _norm_month(v)
            if k == "station":
                v = _norm_station(v)
            if k == "region":
                v = _norm_region(v)
            slots[k] = v

    # --- 2. 自由文本：抽出内嵌的槽位 ---
    for tf in ("job_name", "note", "subject"):
        if tf not in args or not isinstance(args[tf], str):
            continue
        s = args[tf]

        # 月份：优先从自由文本里拿到**带年份**的完整月份；
        # 若结构化槽位里只有 "??-08"（缺年份），用文本里的年份补全。
        m_txt = None
        for pat, kind in _MONTH_PAT:
            m = pat.search(s)
            if m:
                if kind == "ym":
                    m_txt = _norm_month(f"{m.group(1)}-{int(m.group(2)):02d}")
                else:
                    m_txt = _norm_month(m.group(1) + "月")
                break
        cur = slots.get("month")
        if m_txt is not None:
            if cur is None:
                slots["month"] = m_txt
            elif isinstance(cur, str) and cur.startswith("??-") and not m_txt.startswith("??-"):
                slots["month"] = m_txt        # 用文本里的年份补全歧义

        # 站号
        if "station" not in slots:
            m = _STATION_PAT.search(s)
            if m:
                slots["station"] = _norm_station(m.group(1))

        # 海区
        if "region" not in slots:
            low = s.lower()
            for rn in _REGION_NAMES:
                if rn in low:
                    slots["region"] = _norm_region(rn)
                    break

        # 动作
        act = None
        low = s.lower()
        for w, canon in _ACTION_VOCAB.items():
            if w in low:
                act = canon
                break
        if act:
            slots["action"] = act

        # 断言强度
        for w, canon in _ASSERTION.items():
            if w in s:
                slots["assertion"] = canon
                break

        # 范围限定
        if re.search(r"[_-](s\d{2}|partial|only)\b|只|仅", s, re.I):
            slots["scope"] = "partial"
        elif "全部" in s or "all" in low:
            slots["scope"] = "full"

    # --- 3. 残余文本：无法结构化的部分 ---
    #     刻意**不**把 job_name 整串放进来，只放剥离了已知槽位后的残余。
    for tf in ("job_name", "note"):
        if tf in args and isinstance(args[tf], str):
            r = args[tf]
            # 先把已知槽位整段抹掉（含其数字），再抹动词/断言/海区词
            r = _STATION_PAT.sub(" ", r)
            for w in list(_ACTION_VOCAB) + list(_ASSERTION) + list(REGION_ALIAS):
                r = re.sub(re.escape(w), " ", r, flags=re.I)
            r = re.sub(r"\d", " ", r)
            r = re.sub(r"[^a-z\u4e00-\u9fff]+", " ", r.lower()).strip()
            if r:
                residual.append(r)

    if residual:
        slots["residual"] = " ".join(sorted(set(residual)))

    return slots


def _norm_month(v: Any) -> Any:
    r"""
    月份归一。**关键纪律：不得擅自降低时间精度。**

    踩过的坑（值得写进报告）：第一版这里写了 `(?:[-/]\d{1,2})?`，
    把 "2026-08-15" 直接裁成 "2026-08"。结果"8月15日重算"与"8月整月重算"
    被算成同一个键，槽位投影的假阳性率从 0 跳到 0.30。
    —— 这个裁精度是**我**干的，不是槽位投影这一思想的固有缺陷。
      但它暴露了槽位投影的真实风险：**槽位抽取器里每一处"顺手归一"
      都是一次未经审计的规范化**，和文本空间的 RISKY 规则同性质。

    正确行为：只统一**书写形式**，不改变**精度**。
      2026-08 / 2026年8月 / 2026/08 / 202608 / Aug 2026 → 2026-08   （同为月精度）
      2026-08-01 / 2026/8/1                                → 2026-08-01（日精度，保留）
      8月                                                  → ??-08     （缺年份，显式标歧义）
    """
    if not isinstance(v, str):
        return v
    s = re.sub(r"\s+", "", v)
    # 先查别名（别名表用"去空格小写"做键）
    if s.lower() in MONTH_ALIAS:
        return MONTH_ALIAS[s.lower()]

    # 带日：保留到日
    m = re.fullmatch(r"(\d{4})[-/年]?(\d{1,2})[-/月](\d{1,2})日?", s)
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"

    # 只到月
    m = re.fullmatch(r"(\d{4})[-/年]?(\d{1,2})月?", s)
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}"

    # 缺年份：显式标为歧义，绝不猜
    m = re.fullmatch(r"(\d{1,2})月?", s)
    if m:
        return f"??-{int(m.group(1)):02d}"

    return s


def _norm_station(v: Any) -> Any:
    if not isinstance(v, str):
        return v
    s = re.sub(r"[^A-Za-z0-9]", "", v).upper()
    return s or v


def _norm_region(v: Any) -> Any:
    if not isinstance(v, str):
        return v
    s = v.strip()
    if s.lower() in REGION_ALIAS:
        return REGION_ALIAS[s.lower()]
    return s


# --------------------------------------------------------------------------
# 三种键策略的对照
# --------------------------------------------------------------------------

class StructuredKey:
    """
    键只由结构化槽位构成，自由文本永不进键。
    slot_set 决定哪些槽位参与（可用来做消融实验）。
    """

    ALL = ("action", "station", "month", "region", "to", "subject",
           "assertion", "scope", "residual")

    def __init__(self, tool: str, slot_set: Optional[Tuple[str, ...]] = None,
                 include_residual: bool = True):
        self.tool = tool
        self.slot_set = slot_set or self.ALL
        if not include_residual:
            self.slot_set = tuple(s for s in self.slot_set if s != "residual")

    def slots(self, args: Dict[str, Any]) -> Dict[str, Any]:
        raw = extract_slots(self.tool, args)
        return {k: raw[k] for k in self.slot_set if k in raw}

    def key(self, args: Dict[str, Any]) -> str:
        return json.dumps(self.slots(args), ensure_ascii=False, sort_keys=True,
                          separators=(",", ":"))


@dataclass
class StrategyResult:
    name: str
    fn_rate: float
    fp_rate: float
    dup_cost: float
    miss_cost: float
    total_cost: float
    keys_per_episode: float
    fp_by_kind: Dict[str, float] = field(default_factory=dict)
    fp_examples: List[Dict[str, Any]] = field(default_factory=list)


def compare_strategies(episodes, pairs, rho: float = 1.0) -> List[StrategyResult]:
    """把四种策略放在同一把尺子上量。"""
    def run(name, keyfn) -> StrategyResult:
        dup = miss = 0.0
        n_keys_total = 0
        n_split = 0
        for ep in episodes:
            ks = {keyfn(ep.op.tool, v) for v in ep.variants}
            n_keys_total += len(ks)
            ex = len(ks) - 1
            dup += ex * ep.op.c_dup * rho
            if ex:
                n_split += 1
        ok_tot: Dict[str, int] = {}
        ok_hit: Dict[str, int] = {}
        exs = []
        collide = 0
        n_same_tool = 0
        for o, d, kind in pairs:
            if o.tool != d.tool:
                continue
            n_same_tool += 1
            ok_tot[kind] = ok_tot.get(kind, 0) + 1
            if keyfn(o.tool, o.slots) == keyfn(d.tool, d.slots):
                collide += 1
                ok_hit[kind] = ok_hit.get(kind, 0) + 1
                miss += d.c_miss
                if len(exs) < 6:
                    exs.append({"kind": kind, "tool": o.tool})

        return StrategyResult(
            name=name,
            fn_rate=n_split / len(episodes),
            fp_rate=collide / n_same_tool if n_same_tool else 0.0,
            dup_cost=dup, miss_cost=miss, total_cost=dup + miss,
            keys_per_episode=n_keys_total / len(episodes),
            fp_by_kind={k: ok_hit.get(k, 0) / v for k, v in ok_tot.items()},
            fp_examples=exs,
        )

    results = []
    # 基线：裸哈希（课件字面做法）
    results.append(run("裸参数哈希（课件字面）",
                       lambda t, a: json.dumps(a, ensure_ascii=False,
                                               sort_keys=True, default=str)))
    # 仅 SAFE
    results.append(run("SAFE 规范化",
                       lambda t, a: KeyPolicy(t, 0.0).key(a)))
    # SAFE + 全部 RISKY
    results.append(run("SAFE + 全部 RISKY",
                       lambda t, a: KeyPolicy(t, 1.0).key(a)))
    # 槽位投影（不含残余文本）
    results.append(run("槽位投影（不含残余）",
                       lambda t, a: StructuredKey(t, include_residual=False).key(a)))
    # 槽位投影（含残余）
    results.append(run("槽位投影（含残余）",
                       lambda t, a: StructuredKey(t, include_residual=True).key(a)))
    return results


if __name__ == "__main__":
    from evaluate import make_episodes, make_pairs

    eps = make_episodes(seed=0)
    prs = make_pairs(seed=0)

    print("=" * 92)
    print("槽位抽取示例")
    print("=" * 92)
    ep = next(e for e in eps if e.op.op_id == "submit_019")
    sk = StructuredKey(ep.op.tool)
    for i, v in enumerate(ep.variants, 1):
        print(f"  v{i}: {json.dumps(v, ensure_ascii=False)}")
        print(f"   →槽位: {json.dumps(sk.slots(v), ensure_ascii=False)}")
        print(f"   →键  : {sk.key(v)}")

    print()
    print("=" * 92)
    print("四种策略对照（rho=1）")
    print("=" * 92)
    print(f"{'策略':24s} {'FN率':>7} {'FP率':>7} {'重复代价':>9} {'漏做代价':>9} {'总代价':>9} {'键/ep':>7}")
    for r in compare_strategies(eps, prs):
        print(f"{r.name:24s} {r.fn_rate:>7.3f} {r.fp_rate:>7.3f} "
              f"{r.dup_cost:>9.2f} {r.miss_cost:>9.2f} {r.total_cost:>9.2f} "
              f"{r.keys_per_episode:>7.2f}")