"""
universe.py — 受控"工具宇宙"：工具 schema、基准逻辑操作、相似诱饵。

设计原则
--------
1. 工具取自课程第7讲课时3 那面"工具墙"（湖仓/空间/计算/检索/质检 五台服务器），
   保证实验对象与课件同源，结论可以挂回第7讲。
2. 每个"逻辑操作"(LogicalOp) 是**语义层面**的一件事，例如
   "查南海北部 2026 年 9 月的区域质检统计"。
3. 每个逻辑操作可以被模型表述成许多**字面不同但语义等价**的参数对象
   (Variant)。这些变体由 perturb.py 生成。
4. 每个逻辑操作还配一个"最小差异诱饵"(Decoy)：语义上**不同**，
   但字面只差一点。诱饵是假阳性的来源。
"""

from __future__ import annotations

import itertools
import json
import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

# --------------------------------------------------------------------------
# 1. 工具 schema
# --------------------------------------------------------------------------
# side_effect: 0=只读, 1=写隔离区, 2=写正式, 3=对外发送
# 这个分级直接来自课件第7讲课时2「权限四级」，它同时决定重复执行的代价。

TOOLS: Dict[str, Dict[str, Any]] = {
    "query_region_stats": {
        "side_effect": 0,
        "server": "lakehouse",
        "required": ["region", "month"],
        "optional": {"include_flag_dist": False},
        "c_dup": 0.0,     # 只读：重复执行无害
        "c_miss": 0.2,    # 漏执行：拿不到数，决策缺依据
    },
    "query_station_stats": {
        "side_effect": 0,
        "server": "lakehouse",
        "required": ["station", "month"],
        "optional": {"include_qc": True},
        "c_dup": 0.0,
        "c_miss": 0.2,
    },
    "geocode_region": {
        "side_effect": 0,
        "server": "spatial",
        "required": ["region"],
        "optional": {"res": 7, "coverage": "all_intersecting"},
        "c_dup": 0.0,
        "c_miss": 0.3,
    },
    "submit_batch_job": {
        "side_effect": 2,
        "server": "compute",
        "required": ["job_name", "station", "month"],
        "optional": {"cores": 32},
        "c_dup": 1.0,     # 基准单位：重算作业跑两遍 = 账单翻倍（第4讲三笔账）
        "c_miss": 0.4,
    },
    "write_qc_note": {
        "side_effect": 2,
        "server": "qc",
        "required": ["station", "month", "note"],
        "optional": {},
        "c_dup": 1.0,     # 正式表写两行
        "c_miss": 0.8,
    },
    "send_email": {
        "side_effect": 3,
        "server": "notify",
        "required": ["to", "subject"],
        "optional": {"body_ref": None},
        "c_dup": 3.0,     # 对外：重复给值班员发告警短信，信任损失最贵
        "c_miss": 1.5,
    },
}

REGIONS = ["南海北部", "南海中部", "东海陆架", "白令海", "马六甲海峡"]
STATIONS = ["S07", "S12", "S31", "B04"]
MONTHS = ["2026-08", "2026-09", "2026-10"]

# 基准操作只用前三个区域/前三个站；诱饵要用**基准之外**的对象，
# 否则诱饵会和基准操作撞成同一件事，把"正确合并"误记成假阳性。
# （这是我在第一版里踩到的坑：换区诱饵直接等于另一个基准操作。）
DECOY_REGIONS = ["白令海", "马六甲海峡"]
DECOY_STATIONS = ["S31", "B04"]
DECOY_MONTHS = ["2026-11", "2026-12"]


# --------------------------------------------------------------------------
# 2. 逻辑操作：语义层的"一件事"
# --------------------------------------------------------------------------

@dataclass
class LogicalOp:
    """一个逻辑操作。它只有**规范形态**，没有字面形态。"""
    op_id: str
    tool: str
    slots: Dict[str, Any]          # 规范槽位（canonical）
    family: str                    # 用于配对诱饵
    note: str = ""

    @property
    def side_effect(self) -> int:
        return TOOLS[self.tool]["side_effect"]

    @property
    def c_dup(self) -> float:
        return TOOLS[self.tool]["c_dup"]

    @property
    def c_miss(self) -> float:
        return TOOLS[self.tool]["c_miss"]


def build_baseline_ops() -> List[LogicalOp]:
    """基准操作集：覆盖 6 个工具 × 四级副作用。"""
    ops: List[LogicalOp] = []
    n = 0

    # 区域查询：3 区域 × 3 月
    for r, m in itertools.product(REGIONS[:3], MONTHS):
        n += 1
        ops.append(LogicalOp(f"q_region_{n:03d}", "query_region_stats",
                             {"region": r, "month": m},
                             family=f"region_stats|{r}"))

    # 单站查询
    for s, m in itertools.product(STATIONS[:3], MONTHS[:2]):
        n += 1
        ops.append(LogicalOp(f"q_station_{n:03d}", "query_station_stats",
                             {"station": s, "month": m},
                             family=f"station_stats|{s}"))

    # 落格
    for r in REGIONS[:3]:
        n += 1
        ops.append(LogicalOp(f"geocode_{n:03d}", "geocode_region",
                             {"region": r},
                             family=f"geocode|{r}"))

    # 提交作业：重算某站某月
    for s, m in itertools.product(STATIONS[:3], MONTHS[:2]):
        n += 1
        ops.append(LogicalOp(f"submit_{n:03d}", "submit_batch_job",
                             {"job_name": f"recompute_{s}_{m}", "station": s, "month": m},
                             family=f"submit|{s}|{m}"))

    # 写质检备注
    for s, m in itertools.product(STATIONS[:2], MONTHS[:2]):
        n += 1
        ops.append(LogicalOp(f"note_{n:03d}", "write_qc_note",
                             {"station": s, "month": m,
                              "note": f"{s} 温度传感器疑似漂移"},
                             family=f"note|{s}|{m}"))

    # 对外发送
    for r in REGIONS[:2]:
        n += 1
        ops.append(LogicalOp(f"mail_{n:03d}", "send_email",
                             {"to": "duty@ocean.example", "subject": f"{r}拥挤告警"},
                             family=f"mail|{r}"))

    return ops


# --------------------------------------------------------------------------
# 3. 诱饵：语义不同、字面极像
# --------------------------------------------------------------------------

def build_decoys(ops: List[LogicalOp]) -> List[Tuple[LogicalOp, LogicalOp, str]]:
    """
    返回 [(原操作, 诱饵操作, 差异类型)]。

    诱饵必须满足两条：
      1. **语义不同** —— 不应当被合并成同一个键；
      2. **字面只差一个槽位** —— 最容易在规范化时被误抹。

    关键纪律：诱饵必须落在基准操作**覆盖不到**的对象上
    （DECOY_REGIONS / DECOY_MONTHS），否则它只是一个重复的基准操作，
    会把"本该合并"算成"错合并"，凭空造出假阳性。
    """
    pairs: List[Tuple[LogicalOp, LogicalOp, str]] = []

    for op in ops:
        s = op.slots

        # (a) 换月：落到基准之外的月份 —— 同一对象、相邻时间，最经典的假合并
        if "month" in s:
            for dm in DECOY_MONTHS:
                if dm != s["month"]:
                    d = LogicalOp(f"{op.op_id}_dmonth_{dm[-2:]}", op.tool,
                                  {**s, "month": dm}, op.family)
                    pairs.append((op, d, "换月"))
                    break

        # (b) 换区：落到基准之外的海区 —— 空间相邻，字面极像
        if "region" in s:
            for dr in DECOY_REGIONS:
                if dr != s["region"]:
                    d = LogicalOp(f"{op.op_id}_dregion", op.tool,
                                  {**s, "region": dr}, op.family)
                    pairs.append((op, d, "换区"))
                    break

        # (c) 换动作：同一对象上"查统计"还是"落格" —— 动作不同、对象相同
        if op.tool == "query_region_stats":
            d = LogicalOp(f"{op.op_id}_daction", "geocode_region",
                          {"region": s["region"]}, op.family)
            pairs.append((op, d, "换动作"))

        # (d) 换范围：只重算 S07 vs 全部 —— 范围收窄，责任不同
        if op.tool == "submit_batch_job":
            d = LogicalOp(f"{op.op_id}_dscope", op.tool,
                          {**s, "job_name": s["job_name"] + "_S07only"}, op.family)
            pairs.append((op, d, "换范围"))

        # (e) 换断言强度："疑似"→"确认" —— 只差两个字，责任差一个量级
        if op.tool == "write_qc_note":
            d = LogicalOp(f"{op.op_id}_dnote", op.tool,
                          {**s, "note": s["note"].replace("疑似", "确认")}, op.family)
            pairs.append((op, d, "换断言强度"))

        # ---- 下面是"针对性诱饵"：专门用来探某条 RISKY 规则的误伤边界 ----
        # 教训：诱饵集定义了"什么算语义不同"。若诱饵只换整月/整区，
        # 就把"时间截断到月""空间截断到海"这两条规则的误伤面**藏起来了**，
        # 审计时它们会显示为"零边际收益"，从而被误判为免费。
        # 所以每一类归一化规则，都必须配一个它能误伤的诱饵。

        # (f) 同月不同日：只有它才能暴露「时间精度截断到月」的误伤
        if "month" in s and s["month"] in MONTHS:
            d = LogicalOp(f"{op.op_id}_dday", op.tool,
                          {**s, "month": s["month"] + "-15"}, op.family)
            pairs.append((op, d, "同月不同日"))

        # (g) 同海区不同分区：只有它才能暴露「空间精度截断到海」的误伤
        #     用基准之外的月份，避免与基准操作本身重复
        if "region" in s and s["region"] in ("南海北部", "南海中部"):
            other = "南海中部" if s["region"] == "南海北部" else "南海北部"
            d = LogicalOp(f"{op.op_id}_dsub", op.tool,
                          {**s, "region": other, "month": "2026-12"
                           if "month" in s else s.get("month", "2026-12")},
                          op.family)
            pairs.append((op, d, "同海不同区"))

        # (h) 否定 vs 肯定：只有它才能暴露「文本词袋化」丢语序/否定的误伤
        if op.tool == "write_qc_note":
            d = LogicalOp(f"{op.op_id}_dneg", op.tool,
                          {**s, "note": s["note"].replace("疑似", "未"),
                            "month": "2026-12"}, op.family)
            pairs.append((op, d, "否定式"))

    return pairs


if __name__ == "__main__":
    ops = build_baseline_ops()
    dec = build_decoys(ops)
    print(f"基准操作 {len(ops)} 个，诱饵对 {len(dec)} 对")
    from collections import Counter
    print("按工具分布:", Counter(o.tool for o in ops))
    print("差异类型分布:", Counter(t for _, _, t in dec))
    # 副作用加权：对外发送最贵
    print("\n副作用成本画像:")
    for t, cfg in TOOLS.items():
        print(f"  {t:22s} side={cfg['side_effect']}  c_dup={cfg['c_dup']:.1f}  c_miss={cfg['c_miss']:.1f}")