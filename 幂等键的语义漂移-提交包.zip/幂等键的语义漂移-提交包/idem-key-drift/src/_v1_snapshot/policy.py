"""
policy.py — 幂等键策略：安全规则 + 危险规则的连续激进度。

这是整份实验的方法论内核，值得单独一个文件。

问题重述
--------
课件第7讲课时1 说：键 = 任务ID + 步骤号 + 参数哈希，由应用生成。
这句话隐含一个未言明的假设：**参数是确定的**。

但智能体的参数是模型生成的一个分布：同一件事，模型在重试时会用
不同的区域写法、不同的月份格式、显式写出默认值、把数字写成字符串、
在备注里换个说法。参数哈希对这个分布是脆弱的。

于是幂等键退化成一次"聚类决策"：
    把两次调用判为"同一件事" → 只执行一次
    判为"两件事" → 执行两次

两个方向的错误都有代价，且**代价不对称**：
    c_dup  —— 漏合并（执行两次）的代价
    c_miss —— 错合并（该执行却跳过）的代价

为什么不存在"最优键"
--------------------
任何把"字面不同"抹平的规则，都在同时抹掉两类信息：
    (1) 纯书写差异（保义）—— 抹掉是纯收益
    (2) 真实语义差异（变义）—— 抹掉是纯损失

问题在于：**从字面上看，这两类差异长得一模一样**。
"2026-08" vs "2026年8月" 是保义；"2026-08" vs "2026-08-15" 是变义。
同一条"把月份归一"的规则，对前者是收益，对后者是灾难。

所以键的严格程度必须**标定**，而不是取极值。标定的依据是 ρ = c_dup / c_miss。

三类规则
--------
SAFE  : 保义。启用只有收益。工程上应当无条件全开。
RISKY : 有代价的近似。每启用一条，假阴性↓、假阳性↑。
        这些才是需要标定的旋钮。

α ∈ [0,1] 控制 RISKY 规则的启用：按"危险度"从低到高，启用前 ⌈α·n⌉ 条。
这样能扫出一条从"极严格"到"极宽松"的完整前沿。
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from universe import TOOLS


# --------------------------------------------------------------------------
# 词表（人工审定的别名表 —— 它的正确性由人来担保，不由算法推断）
# --------------------------------------------------------------------------

REGION_ALIAS = {
    "南海北部": "南海北部", "南海北部海区": "南海北部", "南海北部区域": "南海北部",
    "南海北部海域": "南海北部", "northern south china sea": "南海北部",
    "scs-n": "南海北部",
    "南海中部": "南海中部", "南海中部海区": "南海中部", "南海中部区域": "南海中部",
    "central south china sea": "南海中部", "scs-c": "南海中部",
    "东海陆架": "东海陆架", "东海陆架区": "东海陆架", "东海大陆架": "东海陆架",
    "east china sea shelf": "东海陆架", "ecs-shelf": "东海陆架",
    "白令海": "白令海", "白令海海域": "白令海", "bering sea": "白令海",
    "马六甲海峡": "马六甲海峡", "马六甲": "马六甲海峡",
    "strait of malacca": "马六甲海峡",
}

STATION_ALIAS = {
    "s07": "S07", "s-07": "S07", "站s07": "S07", "s07站": "S07",
    "s12": "S12", "s-12": "S12", "站s12": "S12", "s12站": "S12",
    "s31": "S31", "s-31": "S31", "站s31": "S31", "s31站": "S31",
    "b04": "B04", "b-04": "B04", "站b04": "B04", "b04站": "B04",
}

MONTH_ALIAS = {
    # 纪律：别名表**只统一书写形式，不改变精度**。
    # 曾经这里有 "2026-08-01": "2026-08" 这样的条目 —— 那是在别名层
    # 偷偷把日精度降到月精度，等同于一条未申报的危险规则。已删除。
    "2026-08": "2026-08", "2026年8月": "2026-08", "2026/08": "2026-08",
    "202608": "2026-08", "aug2026": "2026-08", "aug 2026": "2026-08",
    "2026-09": "2026-09", "2026年9月": "2026-09", "2026/09": "2026-09",
    "202609": "2026-09", "sep2026": "2026-09", "sep 2026": "2026-09",
    "2026-10": "2026-10", "2026年10月": "2026-10", "2026/10": "2026-10",
    "202610": "2026-10", "oct2026": "2026-10", "oct 2026": "2026-10",
    "2026-11": "2026-11", "2026-12": "2026-12",
}

_ALIAS: Dict[str, str] = {}
for d in (REGION_ALIAS, STATION_ALIAS, MONTH_ALIAS):
    for k, v in d.items():
        _ALIAS[k.lower().strip()] = v


def _norm_basic(v: Any) -> Any:
    """strip + 空白压缩 + 小写查表（不改大小写本身，只用于查表）"""
    if not isinstance(v, str):
        return v
    s = re.sub(r"\s+", " ", v.strip())
    if s.lower() in _ALIAS:
        return _ALIAS[s.lower()]
    return s


# --------------------------------------------------------------------------
# 规则定义
# --------------------------------------------------------------------------

@dataclass
class Rule:
    key: str
    name: str
    dangerousness: float        # 0=纯安全, 越大越危险
    eats: str                   # 它会吃掉哪一类语义边界
    fn: Any = None


# ---- SAFE 规则 -----------------------------------------------------------

def safe_drop_noise(a: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in a.items() if not k.startswith("__")}


def safe_alias(a: Dict[str, Any]) -> Dict[str, Any]:
    return {k: _norm_basic(v) for k, v in a.items()}


def safe_type_norm(a: Dict[str, Any]) -> Dict[str, Any]:
    out = {}
    for k, v in a.items():
        if isinstance(v, bool):
            out[k] = v
        elif isinstance(v, str):
            low = v.strip().lower()
            if low in ("true", "1", "是", "yes"):
                out[k] = True
            elif low in ("false", "0", "否", "no"):
                out[k] = False
            else:
                try:
                    f = float(v)
                    out[k] = int(f) if f.is_integer() else f
                except ValueError:
                    out[k] = v
        elif isinstance(v, float) and v.is_integer():
            out[k] = int(v)
        else:
            out[k] = v
    return out


def safe_schema_prune(tool: str):
    allowed = set(TOOLS[tool]["required"]) | set(TOOLS[tool]["optional"])
    defaults = {"res": 7, "coverage": "all_intersecting", "cores": 32,
                "include_flag_dist": False, "include_qc": True, "body_ref": None}

    def fn(a: Dict[str, Any]) -> Dict[str, Any]:
        out = {k: v for k, v in a.items() if k in allowed}
        return {k: v for k, v in out.items() if not (k in defaults and defaults[k] == v)}
    return fn


def safe_key_order(a):
    return {k: a[k] for k in sorted(a)}


# ---- RISKY 规则（按危险度升序） ------------------------------------------

def risky_text_bag(a: Dict[str, Any]) -> Dict[str, Any]:
    """词袋化：丢语序、丢标点。危险度低——语序在参数里很少承载语义。
    但它会抹平否定式与肯定式（"未漂移" vs "漂移"）。"""
    tok = re.compile(r"[a-z0-9]+|[\u4e00-\u9fff]")
    out = {}
    for k, v in a.items():
        if isinstance(v, str) and len(v) > 3:
            out[k] = " ".join(sorted(tok.findall(v.lower())))
        else:
            out[k] = v
    return out


def risky_strip_intensity(a: Dict[str, Any]) -> Dict[str, Any]:
    """删程度副词/断言强度词。
    危险度较高：这是最像"美化"的一步，也是最容易吃掉责任的边界。
    '疑似' → '确认' 只差两个字，责任差一个量级。"""
    drop = ["疑似出现", "可能存在", "疑似", "疑为", "已确认", "确认",
            "建议", "复核", "suspected", "please", "retry", "again"]
    out = {}
    for k, v in a.items():
        if isinstance(v, str) and len(v) > 3:
            s = v
            for w in drop:
                s = s.replace(w, " ")
            tok = re.compile(r"[a-z0-9]+|[\u4e00-\u9fff]")
            out[k] = " ".join(sorted(tok.findall(s.lower())))
        else:
            out[k] = v
    return out


def risky_time_coarse(a: Dict[str, Any]) -> Dict[str, Any]:
    """时间精度截断：把 YYYY-MM-DD 截成 YYYY-MM。
    危险：同一月的两个不同日会被合并；"上月重算"与"某日重算"分不开。"""
    out = {}
    for k, v in a.items():
        if k.endswith("month") or "date" in k or "time" in k:
            if isinstance(v, str):
                m = re.fullmatch(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", v.strip())
                if m:
                    v = f"{m.group(1)}-{int(m.group(2)):02d}"
        out[k] = v
    return out


def risky_space_coarse(a: Dict[str, Any]) -> Dict[str, Any]:
    """空间精度截断：把"南海北部/中部"归成"南海"。
    危险：相邻海区被合并 —— 第3讲整节课都在说这会让热点搬家。"""
    out = {}
    for k, v in a.items():
        if k == "region" and isinstance(v, str):
            if "南海" in v:
                v = "南海"
            elif "东海" in v:
                v = "东海"
        out[k] = v
    return out


def risky_scope_drop(a: Dict[str, Any]) -> Dict[str, Any]:
    """丢弃范围限定词（_S07only、_partial 之类）。
    极危险：'只重算 S07' 和 '全部重算' 被当成同一件事。"""
    out = {}
    for k, v in a.items():
        if isinstance(v, str):
            out[k] = re.sub(r"[_-](s\d{2}|partial|only|全部|all)\b", "", v, flags=re.I)
        else:
            out[k] = v
    return out


RISKY_RULES: List[Rule] = [
    # 顺序纪律：**先改结构，后改文本**。
    # 文本词袋化会把 "2026-08-15" 打散成 "08 15 2026"，之后时间截断的正则就匹配不上了
    # —— 这是第二处"规则互相污染"的坑（第一处在 perturb.py 的 rung5/6）。
    # 通用教训：任何"归一化流水线"都必须让结构级规则先跑，文本级规则后跑，
    # 否则后者的输入已经不是你设计的那个形状。
    Rule("scope_drop", "丢弃范围限定词", 0.95, "部分 / 全部", risky_scope_drop),
    Rule("space_coarse", "空间精度截断到海", 0.60, "相邻海区", risky_space_coarse),
    Rule("time_coarse", "时间精度截断到月", 0.45, "同月不同日", risky_time_coarse),
    Rule("strip_intensity", "剥离断言强度词", 0.75, "疑似 / 确认", risky_strip_intensity),
    Rule("text_bag", "文本词袋化", 0.20, "语序 / 否定式", risky_text_bag),
]


class KeyPolicy:
    """
    幂等键策略。

    alpha ∈ [0, 1]：启用前 k 条 RISKY 规则（按危险度升序），
                    k = round(alpha * len(RISKY_RULES))
    safe=True     ：始终启用全部 SAFE 规则（工程基线，无条件该做）

    用法:
        KeyPolicy("submit_batch_job", alpha=0.0).key(args)   # 最严格
        KeyPolicy("submit_batch_job", alpha=1.0).key(args)   # 最宽松
    """

    def __init__(self, tool: str, alpha: float = 0.0, safe: bool = True):
        self.tool = tool
        self.alpha = max(0.0, min(1.0, alpha))
        self.safe = safe
        # 选择顺序 = 危险度升序（先启用最无害的）
        by_danger = sorted(RISKY_RULES, key=lambda r: r.dangerousness)
        k = int(round(self.alpha * len(by_danger)))
        chosen = by_danger[:k]
        # 执行顺序 = 结构级先、文本级后（见 RISKY_RULES 上方的顺序纪律）
        exec_order = {r.key: i for i, r in enumerate(RISKY_RULES)}
        self.active_risky = sorted(chosen, key=lambda r: exec_order[r.key])
        self._prune = safe_schema_prune(tool)

    @property
    def n_risky(self) -> int:
        return len(self.active_risky)

    def project(self, args: Dict[str, Any]) -> Dict[str, Any]:
        a = dict(args)
        if self.safe:
            a = safe_drop_noise(a)
            a = safe_alias(a)
            a = safe_type_norm(a)
            a = self._prune(a)
        for r in self.active_risky:
            a = r.fn(a)
        return safe_key_order(a)

    def key(self, args: Dict[str, Any]) -> str:
        return json.dumps(self.project(args), ensure_ascii=False, sort_keys=True,
                          separators=(",", ":"))

    def describe(self) -> str:
        if not self.active_risky:
            return "严格（全 SAFE，零 RISKY）"
        return " + ".join(r.name for r in self.active_risky)


# 便于叙述的命名档位
NAMED = {
    "strict":  0.0,    # 全 SAFE
    "eng":     0.4,    # SAFE + text_bag + time_coarse
    "loose":   0.6,    # + space_coarse
    "sloppy":  0.8,    # + strip_intensity
    "chaos":   1.0,    # + scope_drop
}


if __name__ == "__main__":
    demo = {"job_name": "recompute_S07_2026-08", "station": " S07", "month": "2026年8月",
            "__trace": "req-1234"}
    print("=== SAFE 规则的作用（alpha=0）===")
    p = KeyPolicy("submit_batch_job", 0.0)
    print("  输入:", json.dumps(demo, ensure_ascii=False))
    print("  键  :", p.key(demo))

    print("\n=== RISKY 规则清单（按危险度升序）===")
    for r in sorted(RISKY_RULES, key=lambda x: x.dangerousness):
        print(f"  {r.dangerousness:.2f}  {r.name:14s} 吃掉: {r.eats}")

    print("\n=== 同一对'不同操作'，在各档位下是否被误合并 ===")
    a = {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-08"}
    b = {"job_name": "recompute_S07_2026-08_partial", "station": "S07", "month": "2026-08"}
    c = {"job_name": "recompute_S07_2026-08", "station": "S07", "month": "2026-08-15"}
    for nm, al in NAMED.items():
        p = KeyPolicy("submit_batch_job", al)
        print(f"  {nm:7s} α={al:.1f} risky={p.n_risky}  "
              f"部分vs全部={'合并' if p.key(a)==p.key(b) else '区分'}  "
              f"日vs月={'合并' if p.key(a)==p.key(c) else '区分'}")