"""
e7_rule_audit.py — 逐条审计 RISKY 规则的边际收益（**薄封装**）。

本脚本不再自己算一遍，而是直接调用 run_experiments.e7_rule_audit()，
把同一份结果以"方便贴进报告"的表格形式打印出来，并单独写出
data/e7_rule_audit.json。

为什么要改成薄封装
------------------
v1 时本文件是**独立实现**：自己调 make_episodes / make_pairs、自己写 measure()、
自己维护一份 RISKY_RULES 快照。后果是同一件事有两份代码、两个口径。
v2 统一分母（113 对同工具诱饵）、统一采样口径（不去重）、修正时间语义契约之后，
独立实现立刻和主流程对不上——而且它对不上时**不会报错**，只会静默打印另一套数。
这就是本次质疑里"七个 bug 无 git 历史证据"的同类问题：两处实现漂移没有人能发现。
所以本轮把本文件降级为纯打印层，数值只有一个来源。

v1 顶部那段结论已作废，原因是它和数据对不上
--------------------------------------------
    v1 写的是"两条规则边际收益为零、一条纯收益、一条纯负收益"。
    按第四轮口径重跑（仅保义重复代价作主指标、统一分母 113、时间语义契约修正后）：
      时间精度截断到月  Δ重复 +0.00   Δ漏做 +8.60  净 +8.60（最差）
      丢弃范围限定词    Δ重复 +0.00   Δ漏做 +2.40  净 +2.40
      空间精度截断到海  Δ重复 +0.00   Δ漏做 +1.80  净 +1.80
      文本词袋化        Δ重复 −2.00   Δ漏做 +3.20  净 +1.20
      剥离断言强度词    Δ重复 −5.75   Δ漏做 +6.40  净 +0.65
    **五条没有一条是纯收益**，连"接近纯收益"的那条也还是净亏。
    v1 那句"一条纯收益"是词袋化摧毁标识符导致 RISKY 的假阳性被低估造成的
    （修前 FP 0.085，修后 0.416）。

    换口径后 Δ重复 的绝对值变小了（例如 −5.62 → −5.75 中"被救回来的重复"
    只数该复用的那部分），因为真实变义被拒绝不再算成重复损失。
    这个方向是对的：那部分本来就不该记在"重复"账上。

另外两个推论也被收窄
--------------------
1. "α 不单调 ⇒ 激进程度不是好抽象"：v2 只能说"在当前这个危险度排序下，
   前缀选择不是充分的策略搜索"，不能说"调旋钮框架被否证"。
   而且 α 只产生六个不同组合（五条规则的激活阈值只有六个可区分位置），
   不该包装成"连续规律"。
2. 单条审计推不出协同与顺序：v2 的 32 子集穷举里有 8 个 synergy = −1.45
   （strip_intensity 与 text_bag 相互遮蔽），顺序调换最大 Δ = −1.775。
   这两件事只有穷举能看出来，逐条相加会**高估**叠加损失。

用法
----
    python src/e7_rule_audit.py      # 打印单条 + 32子集 + 顺序依赖，写 data/e7_rule_audit.json
    python src/run_experiments.py    # 全量 E0–E8（本脚本内容是其中 E7 段）
"""

from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from policy import RISKY_RULES  # noqa: E402
from run_experiments import e7_rule_audit  # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")


def main() -> dict:
    res = e7_rule_audit()
    base = res["baseline"]

    print("=" * 100)
    print("E7 逐条审计：相对「仅 SAFE」的边际影响（8 种子 × 4 次重试，统一分母 113）")
    print("=" * 100)
    print(f"{'基线（仅 SAFE）':<20} dup={base['dup']:.3f}  miss={base['miss']:.3f}  "
          f"total={base['total']:.3f}  FN={base['fn']:.3f}  FP={base['fp']:.3f}")
    print()
    print(f"{'规则':<16}{'危险度':>7}{'吃掉':>10}{'Δ重复':>9}{'Δ漏做':>9}"
          f"{'Δ总代价':>10}{'ΔFP':>9}  判定")
    print("-" * 100)

    # 按 Δ总代价 排序（最差在前），方便直接看出没有纯收益
    for s in sorted(res["single"], key=lambda x: x["d_total"]):
        if s["d_total"] < -0.05 and s["fp"] < 0.005:
            verdict = "纯收益 ✓"
        elif s["d_total"] < -0.05:
            verdict = "有收益/有代价 ⚠"
        elif abs(s["d_total"]) <= 0.05:
            verdict = "无边际收益 —"
        else:
            verdict = "纯负收益 ✗"
        print(f"{s['rule']:<16}{s['danger']:>7.2f}{s['eats']:>10}"
              f"{s['d_dup']:>+9.2f}{s['d_miss']:>+9.2f}{s['d_total']:>+10.2f}"
              f"{s['d_fp']:>+9.3f}  {verdict}")

    n_pure_gain = sum(1 for s in res["single"] if s["d_total"] < -0.05 and s["fp"] < 0.005)
    print()
    print(f"结论：{len(res['single'])} 条规则里纯收益的有 {n_pure_gain} 条。"
          f"把时间精度、空间精度、范围限定词、文本词袋、断言强度搅在一起的整体策略，"
          f"收益全部来自「放弃区分」而非「更聪明的归一」。")

    # ---------------- 32 子集：协同项 ----------------
    print()
    print("=" * 100)
    print(f"E7a 全部 {res['n_subsets']} 个子集穷举（2^5）：规则**不可加**")
    print("=" * 100)
    subs = res["subsets"]
    neg = [s for s in subs if s["n_rules"] >= 2 and s["synergy"] < -1e-9]
    pos = [s for s in subs if s["n_rules"] >= 2 and s["synergy"] > 1e-9]
    zero = [s for s in subs if s["n_rules"] >= 2 and abs(s["synergy"]) <= 1e-9]
    print(f"两两及以上组合共 {len(neg) + len(pos) + len(zero)} 个："
          f"负协同 {len(neg)} 个 / 正协同 {len(pos)} 个 / 可加 {len(zero)} 个")

    if neg:
        vals = sorted({round(s["synergy"], 3) for s in neg})
        print(f"\n负协同的取值：{vals}")
        print("负协同组合明细（规则相互遮蔽 → 逐条相加会高估叠加损失）：")
        for s in neg:
            print(f"  synergy={s['synergy']:+.2f}  Δ总={s['d_total']:+.2f}  "
                  f"{' + '.join(s['rule_keys'])}")
        overlap = set.intersection(*[set(s["rule_keys"]) for s in neg]) if neg else set()
        if overlap:
            print(f"\n  交集：{' + '.join(sorted(overlap))} —— "
                  f"这两条同时开时，后者看不到前者已经抹掉的东西，效果被重复计一次。")

    # ---------------- 顺序依赖 ----------------
    print()
    print("=" * 100)
    print("E7b 顺序依赖：把规则执行顺序反过来，结果是否变化")
    print("=" * 100)
    # 组合名最长 73 字符（五条全开），不能被截断——否则"全开"与"四条"
    # 会打印成同一行，读者分不清哪组是 Δ=−1.100、哪组是 Δ=−1.775。
    print(f"{'规则组合':<76}{'正序':>7}{'反序':>7}{'Δ':>8}  依赖")
    print("-" * 104)
    for t in res["order_tests"]:
        nm = " + ".join(t["rule_keys"])
        tag = "  ← 五条全开" if len(t["rule_keys"]) == len(RISKY_RULES) else ""
        print(f"{nm:<76}{t['forward_total']:>7.2f}{t['reversed_total']:>7.2f}"
              f"{t['delta']:>+8.3f}  {'是' if t['order_dependent'] else '否'}{tag}")
    dep = [t for t in res["order_tests"] if t["order_dependent"]]
    print()
    print(f"{len(dep)}/{len(res['order_tests'])} 组存在顺序依赖，"
          f"最大 |Δ| = {max((abs(t['delta']) for t in dep), default=0.0):.3f}。")
    print("含义：这是**形态依赖**而不是巧合——结构级规则（剥断言/丢范围/调精度）"
          "先把参数改形，文本级规则（词袋化）之后就看不出原形，所以谁先谁后结果不同。"
          "任何把规则集合当成「无序集合」的写法都会漏掉这一段。")

    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, "e7_rule_audit.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print(f"\n写出 {os.path.relpath(path)}")
    return res


if __name__ == "__main__":
    main()