"""
status_of_27.py — 把"27 条全部复现成立"拆成五种状态，并让每一类都能被核对。

为什么必须重做（审阅方第九节）
------------------------------
上一版写的是"27 条全部复现成立——我在 v1 代码上跑 contract_check.py，
得到 19 项 FAIL，没有一条是'我觉得没问题'"。

这句话有三个毛病：

1. **数字对不上**：19 项 FAIL 不等于 27 条质疑。27 条里有的根本不是"断言失败"
   能表达的东西（缺公开链接、缺历史提交、缺真实 LLM 调用）。
2. **把不同性质的事压成一种**：代码碰撞、读代码能确认、只是我表述错了、
   压根没做、过程无法核验——这五类混在一个"成立"里，等于取消了这个词。
3. **至少有一条是错的**：T1/T2。审阅方指出，v1 的 SAFE 与槽位投影本来就区分
   月与日，真正的问题是生成器的标签跟策略打架，不是策略撞了。
   我跑 refute_log 核对，确实如此（v1·SAFE 分、v1·SLOT 分，只有 RISKY_ALL 撞，
   而 RISKY_ALL 是把月截断到月精度，撞是它的设计意图）。
   而我写在文档里的是"T1/T2 在 v1 上撞、v2 上分"——这句话把
   "某个具体策略的行为"讲成了"问题本身"，属于表述错误。

本文件的做法
------------
每条质疑记三个字段：状态、证据、能不能被脚本核对。
其中"反例复现"这一类**必须**给出 refute_log 的 case id，
由本脚本去 data/refutation.json 里核实该 id 存在且 v1 行为确实不符要求。
核实不过就报错——不允许用一句"我复现过了"占位。

五种状态（定义来自审阅方的表，不改写）：
  反例复现      能跑出同键/不同键的代码碰撞
  静态代码确认  读代码能确认，但当前样本跑不出来
  文档修正      只是表述问题，实现本来就对
  尚未实现      承认没做，等下一轮
  过程无法核验  缺原始记录或外部证据
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Dict, List

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")

REPRO = "反例复现"
STATIC = "静态代码确认"
DOC = "文档修正"
TODO = "尚未实现"
UNVER = "过程无法核验"

STATES = (REPRO, STATIC, DOC, TODO, UNVER)

# --------------------------------------------------------------------------
# 27 条：编号沿用 docs/response.md 的编号，描述压缩到一行，不原文抄审阅方
# --------------------------------------------------------------------------
# 字段：
#   n      编号
#   gist   我的压缩（不是原文）
#   state  五类之一
#   ev     证据：脚本/文件/字段，读者可自己去核
#   cases  REPRO 专用：refute_log 的 case id 列表（脚本会核实）
CLAIMS: List[Dict[str, Any]] = [
    # ---- 一、时间语义 ----
    {"n": 1, "gist": "同一日期在月/日精度上的三处标准互斥",
     "state": DOC,
     "ev": "refute_log T1/T2 显示 v1·SAFE 与 v1·SLOT 本来就分（不是撞）；"
           "真正错位的是生成器把 2026-08-01 当保义重试注入，与'日精度代表不同操作'打架。"
           "旧表述'v1 上撞'把 RISKY_ALL(月截断,设计上有损) 的行为讲成了问题本身",
     "cases": []},
    {"n": 2, "gist": "错误的精度口径会让相关数字整体偏移",
     "state": REPRO,
     "ev": "复现的是**后果**而非'策略撞键'：v1·RISKY_ALL 在 T1/T2 上判为同键 "
           "（它把月截断到月精度），于是'粗暴截断'被记成收益。"
           "注意与 #1 分开读：#1 是我把 RISKY_ALL 的行为讲成了策略缺陷（表述错误），"
           "#2 是这种截断确实在旧口径下白捡了分（行为事实）。"
           "改口径后 E2/E7 的 time_coarse 项已重算",
     "cases": ["T1", "T2"]},
    {"n": 3, "gist": "缺年份的裸'8月'不能无条件落到 2026-08",
     "state": STATIC,
     "ev": "contract.norm_month 对无年份输入返回 '??-MM'；contract_check [1] 断言该行为。"
           "当前样本里没有裸'8月'，所以只能读代码+断言确认",
     "cases": []},
    # ---- 二、schema 与残余 ----
    {"n": 4, "gist": "extract_slots 不读 schema，六个已声明字段被忽略",
     "state": REPRO,
     "ev": "v1·SLOT 在 S1–S5 全部撞键；v2 全部分开",
     "cases": ["S1", "S2", "S3", "S4", "S5"]},
    {"n": 5, "gist": "残余归一把备注里的数字整体删掉",
     "state": REPRO,
     "ev": "v1·SLOT 在 S6/S7 撞键，键里留下 '温度偏差 度' 这种挖空残余",
     "cases": ["S6", "S7"]},
    {"n": 6, "gist": "FP=0 只能读成'这批诱饵上没观察到碰撞'",
     "state": DOC,
     "ev": "纯表述：FP 是全称判断还是样本观察。实现无需改，报告已改写口径"
           "（见 report.md 指标定义节，FP 分母=113 同工具诱饵）",
     "cases": []},
    {"n": 7, "gist": "SAFE 无差别套别名/转类型，应改成三重验证才启用",
     "state": REPRO,
     "ev": "v1 在 S9(备注 01 vs 1.0)、S10(邮件主题 S07 vs S-07) 撞键；v2 用 may_alias/may_coerce 逐字段声明",
     "cases": ["S9", "S10"]},
    {"n": 8, "gist": "键里没有 tool；且缺租户/有效期/并发/崩溃恢复",
     "state": REPRO,
     "ev": "前半（跨工具共命名空间）由 S11 复现并已修；后半（租户/有效期/并发/崩溃恢复）"
           "本轮没做，见下条同号 TODO-8",
     "cases": ["S11"]},
    {"n": 8.1, "gist": "租户隔离 / 有效期 / 并发窗口 / 崩溃恢复",
     "state": TODO,
     "ev": "未实现。只在 report.md 的局限节写成待办，没有代码。"
           "这是本轮唯一明确承认没做的一组",
     "cases": []},
    # ---- 三、采样与算子 ----
    {"n": 9, "gist": "去重采样在'不同写法'里挑重试，不是自然分布",
     "state": DOC,
     "ev": "这条不是代码碰撞能表达的，是**采样设计改了**：去重开关默认关闭，"
           "并做单因素归因（E0b，裸 dup −1.50 / 槽位 +0.25）。"
           "归到'文档修正'是因为改的是实验设计的口径与默认值，"
           "没有一个'v1 撞键 / v2 分开'的最小对能演示它",
     "cases": []},
    {"n": 10, "gist": "号称 11 个算子，实际没跑那么多；weight 是装饰品",
     "state": DOC,
     "ev": "原表述把'注册了 15 个算子'讲成'11 个都生效'。改法是**把指标拆成五个计数**"
           "（probed/chosen/returned/changed/on_label，data/e0_activation.csv），"
           "而不是修某个函数——所以这是表述与口径问题。"
           "key_order 的 chosen=203/changed=0 正是原表述错在哪里的证据",
     "cases": []},
    {"n": 11, "gist": "诱饵改多维度；语序反例要用字符集相同关系相反的句子",
     "state": REPRO,
     "ev": "contract_check [7] 断言 113 对同工具诱饵改多维 0 对；S8 用字符集相同语序相反的备注",
     "cases": ["S8"]},
    # ---- 四、统计口径 ----
    {"n": 12, "gist": "93 与 84 两个 FP 分母并存；两个 by_kind 填成同一份",
     "state": DOC,
     "ev": "数字一致性问题，不是代码行为。已统一为 113（跨工具 5 对剔除），"
           "见 results.json meta.fp_denominator",
     "cases": []},
    {"n": 13, "gist": "rho 不是共同比值；λ 只缩放 c_dup；'ρ≈2'被网格放大",
     "state": DOC,
     "ev": "λ 语义写进 results.json meta.lam_semantics；切换点由 e3_lambda_scan.switches 给解析交点"
           "（lam_star=1.1130，网格 0.0504），不再说'ρ≈2'",
     "cases": []},
    {"n": 14, "gist": "总代价直接把两块相加 = 隐含'每个诱饵出现一次'",
     "state": TODO,
     "ev": "已收窄为'可加为主 + 二维帕累托校验'：COST_MODEL='additive'、假设 A1–A5 逐条写出、"
           "36 个出现率组合检查最优点是否落在前沿（n_off_pareto=0/36）。"
           "但真实流量画像下的加权仿真**没做**",
     "cases": []},
    {"n": 15, "gist": "'只读无收益'是 c_dup=0 的设定推论",
     "state": STATIC,
     "ev": "读 TOOLS 的 c_dup 取值即可确认：只读工具 c_dup=0，所以 dup 侧恒为 0。"
           "已在 report.md 写成'设定推论'而非'发现'",
     "cases": []},
    {"n": 16, "gist": "八种子不是八个样本；± 是样本标准差；E5 只用 seed=0",
     "state": STATIC,
     "ev": "evaluate._sd 用 ddof=1，results.json meta.sd_meaning 明写'不是置信区间'；"
           "E5 的 seed 局限保留在报告里，未修（E5 本来就是确定性构造）",
     "cases": []},
    # ---- 五、基线与框架 ----
    {"n": 17, "gist": "缺持久化操作 ID 基线；三类事件没分开；第三类零负例",
     "state": REPRO,
     "ev": "E8 四类事件 + 持久化 ID 一行（results.json E4_strategies.opid_baseline）。"
           "ID 基线在全 4 类上成立，但代价是真实变义被吞 63/63——这是它的信息条件优势与代价",
     "cases": ["S11"]},
    {"n": 18, "gist": "'AI 原生'要收窄；'重试要重新调 LLM'是假设",
     "state": DOC,
     "ev": "改为假设写明。真实 LLM 调用本轮明确不做（审阅方第十节也要求不要为叙述完整性去补）",
     "cases": []},
    {"n": 19, "gist": "E7 单条推不出交互；32 子集该穷举；六前缀不能否证框架",
     "state": DOC,
     "ev": "这是**方法论主张**被接受，不是代码缺陷：E3 改成 32 子集穷举、"
           "E7 加顺序依赖测试、单因素归因拆成 F0a/F0b/F1/F2 四段。"
           "v1 的六前缀结果本身没有算错，错在用它去否证框架",
     "cases": []},
    {"n": 20, "gist": "自己出题自己答题；'排序可移植'同样依赖分布",
     "state": UNVER,
     "ev": "已补隐藏集（28 对，正 8/负 20）+ 冻结哈希（data/holdout_freeze.json）。"
           "但'冻结之后只评一次、不参与策略设计'这个**过程**无法自证："
           "本轮首跑就有 2 条正例失败并据此改了 norm_station 与 STATION_PAT，"
           "这两条已标 used_in_dev 并在 E5 里单独给出扣除后的数。"
           "要真正闭环需要外部保管，本包做不到，不声称做到了",
     "cases": []},
    {"n": 21, "gist": "撤三个大主张，改用收窄稿；'槽位投影'原创性要讲清",
     "state": DOC,
     "ev": "三处主张已撤（见 report.md 结论节的'不主张'清单）",
     "cases": []},
    # ---- 七、交付与过程 ----
    {"n": 22, "gist": "numpy 参与计算，要锁版本",
     "state": DOC,
     "ev": "requirements.txt 锁 numpy==2.5.4 / matplotlib==3.11.2；"
           "verify_env.py 三项对账全过（导入覆盖、版本一致、results.json 生成环境）",
     "cases": []},
    {"n": 23, "gist": "e7_rule_audit.py 顶部注释是旧结论",
     "state": DOC,
     "ev": "已改成薄封装，直接 from run_experiments import e7_rule_audit，不再自带结论文字",
     "cases": []},
    {"n": 24, "gist": "'六个实验'与实际 E1–E7b 不一致",
     "state": DOC,
     "ev": "报告改为按实际实验编号（E0/E0b/E1–E10）列举，个数不再作断言",
     "cases": []},
    {"n": 25, "gist": "无仓库链接、无 remote、PUSH.md 教手动建仓",
     "state": UNVER,
     "ev": "仓库链接与 push 权限不在我这一侧（第一轮明确'本地建好，我自己 push'）。"
           "本包只能保证：git 历史在本地完整、提交 SHA 与 blob SHA 固定可核对。"
           "'已公开发布'这件事无法由本包核验",
     "cases": []},
    {"n": 26, "gist": "七个 bug 无 git 历史证据",
     "state": UNVER,
     "ev": "历史无法补。改为可复现取证：refute_log.py 固定到 V1_COMMIT="
           "31961e12…，并逐个核对 blob SHA（不符即报错退出，不降级）。"
           "这证明'差异现在真实存在且可复现'，不证明'当时是这么修的'",
     "cases": []},
    {"n": 27, "gist": "FN=1 被解释成'执行 5 次'；平均键数算错",
     "state": DOC,
     "ev": "FN 只表示'每个 episode 至少分裂过一次'；平均键数已按新口径重算"
           "（keys_per_ep 在 data/e4_summary.csv），FN 不再是主指标",
     "cases": []},
]


def verify(refut: Dict[str, Any]) -> List[str]:
    """核实每个 REPRO 条目的 case id 真实存在、且 v1 行为确实不符要求。"""
    by_id = {r["id"]: r for r in refut.get("cases", [])}
    problems: List[str] = []
    for c in CLAIMS:
        if c["state"] != REPRO:
            continue
        if not c["cases"]:
            problems.append(f"#{c['n']} 标为'{REPRO}'却没有给 case id")
            continue
        for cid in c["cases"]:
            r = by_id.get(cid)
            if r is None:
                problems.append(f"#{c['n']} 引用的 {cid} 不在 refutation.json 里")
                continue
            # v1 至少要有一个策略判错，否则这条"反例"其实没复现出来
            bad = [s for s, ok in r["v1"]["correct"].items() if not ok]
            if not bad:
                problems.append(
                    f"#{c['n']} 引用的 {cid} 在 v1 上四个策略全部符合要求，"
                    f"复现不成立")
    return problems


def main() -> int:
    path = os.path.join(DATA, "refutation.json")
    if not os.path.exists(path):
        print("!! 先跑 refute_log.py 生成 data/refutation.json")
        return 1
    with open(path, encoding="utf-8") as f:
        refut = json.load(f)

    problems = verify(refut)

    counts = {s: sum(1 for c in CLAIMS if c["state"] == s) for s in STATES}

    print("=" * 92)
    print("27 条质疑的五状态分类")
    print("=" * 92)
    for s in STATES:
        print(f"\n【{s}】{counts[s]} 条")
        for c in CLAIMS:
            if c["state"] != s:
                continue
            extra = f"  ← 复现: {','.join(c['cases'])}" if c["cases"] else ""
            print(f"  #{c['n']:<5} {c['gist']}{extra}")

    print("\n" + "=" * 92)
    print("核对：所有标为「反例复现」的条目，其 case id 是否真的能在 v1 上复现")
    print("=" * 92)
    if problems:
        for p in problems:
            print(f"  FAIL  {p}")
    else:
        n_cases = len({cid for c in CLAIMS if c["state"] == REPRO for cid in c["cases"]})
        print(f"  ok    {counts[REPRO]} 条标为'{REPRO}'，共用 {n_cases} 个 case，"
              f"每个都能在 refutation.json 里找到且 v1 至少一个策略判错")

    total = len(CLAIMS)
    print(f"\n合计 {total} 条（含 #8.1 对 #8 后半的拆分，所以计数比 27 多一条）")
    print("  说明：#8 的前半（跨工具共命名空间）已复现并修好，后半（租户/有效期/"
          "并发/崩溃恢复）没做。压成一条会把'已修'和'没做'混在一起，"
          "所以拆成 #8 与 #8.1 分别记状态。")

    out = {
        "total": total,
        "counts": counts,
        "claims": CLAIMS,
        "verify_problems": problems,
        "note": ("状态定义照抄审阅方的表，不改写。" 
                 "'反例复现'必须由 refute_log 的 case 支撑，由本脚本核实；"
                 "'过程无法核验'是承认，不是免责。"),
    }
    op = os.path.join(DATA, "claims_status.json")
    with open(op, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"\n写出 data/claims_status.json")
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(main())