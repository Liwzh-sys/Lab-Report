"""
verify_env.py — 环境可核验性：把"我这里是这么跑的"变成一份可对账的记录。

为什么需要这个文件（审阅方：「依赖未环境证明」）
--------------------------------------------
上一版 requirements.txt 只写了两行版本号，但没有任何东西证明：
  · 这两行是不是真的够（装了它就能跑完三个脚本）
  · 我报告里的数字是不是在这个环境里跑出来的
  · Python 小版本换了会不会变

前两条可以自动查，第三条只能部分查。本文件做的是前两条 + 给第三条留证据：

  1. 记录解释器与所有第三方包的版本，写进 data/env.json；
  2. 扫描 src/*.py 的导入，把**没有被 requirements.txt 覆盖**的标出来；
  3. 用 requirements.txt 里的版本与当前环境逐项对账，不一致就报；
  4. 校验 data/results.json 里记的 python 版本与当前环境是否一致
     —— 不一致意味着"结果不是这台环境跑出来的"，必须重跑。

它证明不了的：干净安装能不能跑通。那需要另起一个 venv，见 README 的
「如何在干净环境复现」一节，那里给的是可复制的命令，不是保证。
"""

from __future__ import annotations

import ast
import json
import os
import platform
import re
import sys
from typing import Dict, List, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
DATA = os.path.join(ROOT, "data")
REQ = os.path.join(ROOT, "requirements.txt")

STDLIB = set(getattr(sys, "stdlib_module_names", ()))
LOCAL = {"contract", "policy", "structured", "universe", "perturb",
         "evaluate", "holdout", "run_experiments", "refute_log",
         "make_figs", "e7_rule_audit", "verify_env"}


def parse_requirements() -> Dict[str, str]:
    out = {}
    if not os.path.exists(REQ):
        return out
    for line in open(REQ, encoding="utf-8"):
        line = line.split("#")[0].strip()
        if not line or "==" not in line:
            continue
        k, v = line.split("==", 1)
        out[k.strip().lower()] = v.strip()
    return out


def imported_top_modules() -> Dict[str, List[str]]:
    """扫描 src/*.py 的顶层导入，返回 {模块名: [出现在哪些文件]}"""
    seen: Dict[str, List[str]] = {}
    for fn in sorted(os.listdir(HERE)):
        if not fn.endswith(".py"):
            continue
        src = open(os.path.join(HERE, fn), encoding="utf-8").read()
        try:
            tree = ast.parse(src)
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            names: List[str] = []
            if isinstance(node, ast.Import):
                names = [a.name.split(".")[0] for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                if node.level:          # 相对导入
                    continue
                if node.module:
                    names = [node.module.split(".")[0]]
            for n in names:
                if n in STDLIB or n in LOCAL or n == "__future__":
                    continue
                seen.setdefault(n, [])
                if fn not in seen[n]:
                    seen[n].append(fn)
    return seen


def pkg_version(name: str):
    try:
        from importlib.metadata import version
        return version(name)
    except Exception:
        return None


def main() -> int:
    req = parse_requirements()
    imps = imported_top_modules()

    print("=" * 78)
    print("环境记录")
    print("=" * 78)
    print(f"解释器      {sys.executable}")
    print(f"Python      {platform.python_version()}  ({platform.python_implementation()})")
    print(f"平台        {platform.platform()}")
    print(f"字节序/位数 {sys.byteorder} / {8 * __import__('struct').calcsize('P')}")

    pkgs = {}
    for name in sorted(imps):
        v = pkg_version(name)
        pkgs[name] = v
        print(f"第三方      {name:14s} {v if v else '!! 未安装'}   ← {', '.join(imps[name])}")

    fails: List[str] = []
    print("\n" + "=" * 78)
    print("对账 1：代码导入 vs requirements.txt")
    print("=" * 78)
    for name, files in sorted(imps.items()):
        if name in req:
            print(f"  ok    {name:14s} 已声明 =={req[name]}")
        else:
            print(f"  FAIL  {name:14s} 被 {', '.join(files)} 导入，但 requirements.txt 没声明")
            fails.append(f"{name} 未在 requirements.txt 声明")

    print("\n" + "=" * 78)
    print("对账 2：requirements.txt vs 当前实际版本")
    print("=" * 78)
    for name, want in sorted(req.items()):
        got = pkg_version(name)
        if got == want:
            print(f"  ok    {name:14s} =={want}")
        else:
            print(f"  FAIL  {name:14s} 声明 =={want}，实际 {got}")
            fails.append(f"{name} 版本不符（声明 {want}，实际 {got}）")

    print("\n" + "=" * 78)
    print("对账 3：results.json 的生成环境 vs 当前环境")
    print("=" * 78)
    res_path = os.path.join(DATA, "results.json")
    env_record = {
        "python": platform.python_version(),
        "python_full": sys.version,
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "executable": sys.executable,
        "packages": pkgs,
        "requirements": req,
        "imported_third_party": imps,
    }
    if os.path.exists(res_path):
        with open(res_path, encoding="utf-8") as f:
            res = json.load(f)
        meta = res.get("meta", {})
        rp = meta.get("python") or meta.get("env_python")
        if rp is None:
            print("  !!    results.json 没有记录生成环境（meta.python 缺失）")
            print("        → 无法判断报告数字是不是这套环境跑出来的")
            fails.append("results.json 未记录生成环境")
        elif str(rp).split()[0] != platform.python_version():
            print(f"  FAIL  results.json 由 Python {rp} 生成，当前 {platform.python_version()}")
            fails.append("结果与当前解释器版本不一致，必须重跑")
        else:
            print(f"  ok    results.json 由 Python {rp} 生成，与当前一致")
    else:
        print("  !!    data/results.json 不存在（先跑 run_experiments.py）")

    os.makedirs(DATA, exist_ok=True)
    out = os.path.join(DATA, "env.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(env_record, f, ensure_ascii=False, indent=2)
    print(f"\n写出 data/env.json")

    print("\n" + "=" * 78)
    if fails:
        print(f"结果：{len(fails)} 项未通过")
        for x in fails:
            print(f"  · {x}")
        return 1
    print("结果：全部通过")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())