"""
universe.py — 受控"工具宇宙"：工具 schema、基准逻辑操作、最小差异诱饵。

本版相对 v1 的三处修正
---------------------
1. **诱饵每对只改一个维度**。v1 的 (g) 同海不同区诱饵同时改了 region 和
   month，(h) 否定式诱饵同时改了 note 和 month。后果是月份字段一个人
   挡在前面，把真正想测的文本规则风险遮住——审计时那些规则会显示为
   "零边际收益"，从而被误判为免费。

2. **取消"诱饵必须在基准集合之外"这条限制**。v1 的注释写道"否则诱饵会和
   基准操作撞成同一件事，把正确合并误记成假阳性"。这句话是错的：
   评估按**成对关系**比较，另一个基准操作只要与当前操作确实不是同一意图，
   就是合法负例。多余的限制反而逼着去改无关字段，把"最小差异"设计搞坏了。
   本版改为：诱饵只需满足"与源操作语义不同且只差一个字段"。

3. **负例显式分为三类**（对应审阅方 TABLE14）：传输重试 / 重规划 / 独立新意图。
   v1 全部实验都压在"重试"与"重规划"的模糊地带，第三类一个都没有。

关于 n_base_ops
---------------
v1 报告里说 30 个基准操作、93 对诱饵。本版的计数全部由代码算出并写进
results.json 的 meta，不再手写。
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

# --------------------------------------------------------------------------
# 1. 工具 schema
# --------------------------------------------------------------------------
# side_effect: 0=只读, 1=写隔离区, 2=写正式, 3=对外发送
# 分级来自课程第7讲课时2「权限四级」，它同时决定重复执行的代价。

TOOLS: Dict[str, Dict[str, Any]] = {
    "query_region_stats": {
        "side_effect": 0, "server": "lakehouse",
        "required": ["region", "month"],
        "optional": {"include_flag_dist": False},
        "c_dup": 0.0, "c_miss": 0.2,
    },
    "query_station_stats": {
        "side_effect": 0, "server": "lakehouse",
        "required": ["station", "month"],
        "optional": {"include_qc": True},
        "c_dup": 0.0, "c_miss": 0.2,
    },
    "geocode_region": {
        "side_effect": 0, "server": "spatial",
        "required": ["region"],
        "optional": {"res": 7, "coverage": "all_intersecting"},
        "c_dup": 0.0, "c_miss": 0.3,
    },
    "submit_batch_job": {
        "side_effect": 2, "server": "compute",
        "required": ["job_name", "station", "month"],
        "optional": {"cores": 32},
        "c_dup": 1.0, "c_miss": 0.4,
    },
    "write_qc_note": {
        "side_effect": 2, "server": "qc",
        "required": ["station", "month", "note"],
        "optional": {},
        "c_dup": 1.0, "c_miss": 0.8,
    },
    "send_email": {
        "side_effect": 3, "server": "notify",
        "required": ["to", "subject"],
        "optional": {"body_ref": "B-001"},
        "c_dup": 3.0, "c_miss": 1.5,
    },
}

REGIONS = ["南海北部", "南海中部", "东海陆架", "白令海", "马六甲海峡"]
STATIONS = ["S07", "S12", "S31", "B04"]
MONTHS = ["2026-08", "2026-09", "2026-10"]

# 诱饵用的对象：与基准集**不要求**互斥（见模块 docstring 第 2 点），
# 但仍刻意选基准外的值，好让"同一对象、只改一个字段"这件事更纯粹。
DECOY_REGIONS = ["白令海", "马六甲海峡"]
DECOY_STATIONS = ["S31", "B04"]
DECOY_MONTHS = ["2026-11", "2026-12"]
SUB_REGIONS = {"南海北部": "南海中部", "南海中部": "南海北部"}


# --------------------------------------------------------------------------
# 2. 逻辑操作
# --------------------------------------------------------------------------

@dataclass
class LogicalOp:
    """一个逻辑操作。它只有**规范形态**，没有字面形态。"""
    op_id: str
    tool: str
    slots: Dict[str, Any]
    family: str
    intent_group: str = ""      # 独立新意图的分组标记（同组可能是重复意图）
    note: str = ""

    @property
    def side_effect(self) -> int:
        return TOOLS[self.tool]["side_effect"]

    @property
    def c_dup(self) -> float:
        return TOOLS[self.tool]["c_dup"]

    @property
    def c_miss(self) -> float:
        return TOOLS[self.tool]["c_miss"]


def build_baseline_ops() -> List[LogicalOp]:
    """基准操作集：覆盖 6 个工具 × 四级副作用。"""
    ops: List[LogicalOp] = []
    n = 0

    for r, m in itertools.product(REGIONS[:3], MONTHS):
        n += 1
        ops.append(LogicalOp(f"q_region_{n:03d}", "query_region_stats",
                             {"region": r, "month": m}, family=f"region_stats|{r}"))

    for s, m in itertools.product(STATIONS[:3], MONTHS[:2]):
        n += 1
        ops.append(LogicalOp(f"q_station_{n:03d}", "query_station_stats",
                             {"station": s, "month": m}, family=f"station_stats|{s}"))

    for r in REGIONS[:3]:
        n += 1
        ops.append(LogicalOp(f"geocode_{n:03d}", "geocode_region",
                             {"region": r}, family=f"geocode|{r}"))

    for s, m in itertools.product(STATIONS[:3], MONTHS[:2]):
        n += 1
        ops.append(LogicalOp(f"submit_{n:03d}", "submit_batch_job",
                             {"job_name": f"recompute_{s}_{m}", "station": s, "month": m},
                             family=f"submit|{s}|{m}"))

    for s, m in itertools.product(STATIONS[:2], MONTHS[:2]):
        n += 1
        ops.append(LogicalOp(f"note_{n:03d}", "write_qc_note",
                             {"station": s, "month": m,
                              "note": f"{s} 温度传感器疑似漂移"},
                             family=f"note|{s}|{m}"))

    for r in REGIONS[:2]:
        n += 1
        ops.append(LogicalOp(f"mail_{n:03d}", "send_email",
                             {"to": "duty@ocean.example", "subject": f"{r}拥挤告警"},
                             family=f"mail|{r}"))

    return ops


# --------------------------------------------------------------------------
# 3. 诱饵（最小差异负例）
# --------------------------------------------------------------------------

@dataclass
class Decoy:
    """
    一对样本：语义相同（正例）或不同（负例），字面差异控制在最小。

    字段纪律（审核用）：
      changed  —— 负例应当只有一个键；正例可以是 0 个（纯写法变化）
      why      —— 为什么这两个是/不是同一件事
      kind     —— 差异类型，用于按类统计
      polarity —— "正例"（期望合并）/ "负例"（期望分开）

    ★ 第三轮新增 polarity：审阅方指出隐藏集 18 组全是负例，
      一个永不合并的策略也能拿 0/18 碰撞、满分。没有正例，
      "碰撞率"这个指标就没有下界意义。
    """
    src: LogicalOp
    decoy: LogicalOp
    changed: Tuple[str, ...]
    kind: str
    why: str
    polarity: str = "负例"

    def __post_init__(self):
        # 跨工具探针的差异维度是"工具"，不体现在参数字典里，故 changed=()
        if self.kind == "跨工具":
            if self.src.tool == self.decoy.tool:
                raise ValueError(f"跨工具探针 {self.decoy.op_id} 的工具相同")
            return
        # 正例：允许 0 个字段变化（纯键序/追踪字段差异），也允许写法变化
        if self.polarity == "正例":
            if self.src.tool != self.decoy.tool:
                raise ValueError(f"正例 {self.decoy.op_id} 跨了工具")
            return
        # 多字段差异样本：**故意的**，用于检验"一处差异即整体判不同"导致的漏判。
        # 这类样本不能用来审计单条规则（差异不唯一），单列一类，不混进单字段统计。
        if self.kind.startswith("多字段"):
            if len(self.changed) < 2:
                raise ValueError(f"{self.decoy.op_id} 标为多字段却只改了 {self.changed}")
            a, b = self.src.slots, self.decoy.slots
            diff = {k for k in set(a) | set(b) if a.get(k) != b.get(k)}
            if diff != set(self.changed):
                raise ValueError(
                    f"{self.decoy.op_id} 声明的 diff {sorted(self.changed)} "
                    f"与实际 {sorted(diff)} 不符")
            return
        if len(self.changed) != 1:
            raise ValueError(
                f"诱饵 {self.decoy.op_id} 改了 {len(self.changed)} 个维度 "
                f"{self.changed}——必须只改一个")


def _one_field(base: Dict[str, Any], field: str, value: Any) -> Dict[str, Any]:
    out = dict(base)
    out[field] = value
    return out


def build_decoys(ops: List[LogicalOp]) -> List[Decoy]:
    """
    构造最小差异负例。**每对只改一个字段**，并在构造时断言这一点。

    覆盖六类：
      换月      同一对象、相邻月份        → 暴露时间归一过宽
      同日不同日 同一月内不同日期          → 暴露"时间截断到月"的误伤
      换区      同一模式、不同海区        → 暴露空间归一过宽
      同海不同区 南海北部 vs 南海中部      → 暴露"空间截断到海"的误伤
      换断言强度 疑似 vs 确认             → 暴露"剥离断言强度"的误伤
      换语序    甲影响乙 vs 乙影响甲       → 暴露"文本词袋化"的误伤
      换范围    全部 vs 只 S07           → 暴露"丢弃范围限定词"的误伤
      换正文    同主题不同 body_ref       → 暴露字段遗漏
      换分辨率  同区域不同 res           → 暴露字段遗漏
      换配置    同作业不同 cores          → 暴露字段遗漏
    """
    pairs: List[Decoy] = []

    for op in ops:
        s = op.slots

        # (a) 换月：同一对象，月份改到基准外的月份
        if "month" in s and s["month"] in MONTHS:
            dm = next(m for m in DECOY_MONTHS if m != s["month"])
            pairs.append(Decoy(
                op,
                LogicalOp(f"{op.op_id}__month", op.tool,
                          _one_field(s, "month", dm), op.family),
                ("month",), "换月",
                "不同月份是不同数据切片，重算范围不同"))

        # (b) 同月不同日：只有它能暴露「时间截断到月」的误伤
        if "month" in s and s["month"] in MONTHS:
            pairs.append(Decoy(
                op,
                LogicalOp(f"{op.op_id}__day", op.tool,
                          _one_field(s, "month", s["month"] + "-15"), op.family),
                ("month",), "同日不同日",
                "整月重算与单日重算是不同作业，计算范围不同"))

        # (c) 换区：同一模式，换到基准外的海区
        if "region" in s:
            dr = next(r for r in DECOY_REGIONS if r != s["region"])
            pairs.append(Decoy(
                op,
                LogicalOp(f"{op.op_id}__region", op.tool,
                          _one_field(s, "region", dr), op.family),
                ("region",), "换区",
                "不同海区是不同对象，产物不可互换"))

        # (d) 同海不同区：只有它能暴露「空间截断到海」的误伤
        if "region" in s and s["region"] in SUB_REGIONS:
            pairs.append(Decoy(
                op,
                LogicalOp(f"{op.op_id}__subregion", op.tool,
                          _one_field(s, "region", SUB_REGIONS[s["region"]]), op.family),
                ("region",), "同海不同区",
                "南海北部与南海中部是相邻但不同的海区，第3讲专门讲过热点的空间错位"))

        # (e) 换断言强度：只差两个字，责任差一个量级
        if op.tool == "write_qc_note" and "疑似" in s.get("note", ""):
            pairs.append(Decoy(
                op,
                LogicalOp(f"{op.op_id}__assert", op.tool,
                          _one_field(s, "note", s["note"].replace("疑似", "确认")),
                          op.family),
                ("note",), "换断言强度",
                "'疑似漂移'与'确认漂移'触发不同的处置流程与责任归属"))

        # (f) 换语序：字符集合完全相同、关系相反 —— 专测词袋化的语序损失
        #     审阅方原话：要测语序损失，得用字符集合相同但关系相反的句子，
        #     并且固定住其他所有字段。所以这一对是"反向句 vs 反向句"，
        #     而不是"基准备注 vs 反向句"（后者差异太大，测不出语序）。
        if op.tool == "write_qc_note":
            base_note = {"station": s["station"], "month": s["month"]}
            pairs.append(Decoy(
                LogicalOp(f"{op.op_id}__ordA", op.tool,
                          {**base_note, "note": "温跃层影响声速"}, op.family),
                LogicalOp(f"{op.op_id}__ordB", op.tool,
                          {**base_note, "note": "声速影响温跃层"}, op.family),
                ("note",), "换语序",
                "同一批字、因果方向相反：前者说温跃层改变声速，后者说声速改变温跃层"))

        # (g) 换范围：全部 vs 只 S07 —— 专测「丢弃范围限定词」
        if op.tool == "submit_batch_job":
            pairs.append(Decoy(
                op,
                LogicalOp(f"{op.op_id}__scope", op.tool,
                          _one_field(s, "job_name", s["job_name"] + "_S07only"),
                          op.family),
                ("job_name",), "换范围",
                "'只重算 S07'与'重算全部站点'是不同作业，账单与产物都不同"))

        # (h) 换正文版本：同收件人同主题、不同 body_ref
        if op.tool == "send_email":
            pairs.append(Decoy(
                op,
                LogicalOp(f"{op.op_id}__body", op.tool,
                          _one_field(s, "body_ref", "B-002"), op.family),
                ("body_ref",), "换正文",
                "正文版本不同即不同通知，收件人需要看到不同内容"))

        # (i) 换分辨率：同区域不同 res
        if op.tool == "geocode_region":
            pairs.append(Decoy(
                op,
                LogicalOp(f"{op.op_id}__res", op.tool,
                          _one_field(s, "res", 9), op.family),
                ("res",), "换分辨率",
                "res 决定网格分辨率，落格产物不同"))

        # (j) 换覆盖策略：同区域同 res、不同 coverage
        if op.tool == "geocode_region":
            pairs.append(Decoy(
                op,
                LogicalOp(f"{op.op_id}__cov", op.tool,
                          _one_field(s, "coverage", "centroid_only"), op.family),
                ("coverage",), "换覆盖",
                "是否覆盖所有相交格决定产物完整度"))

        # (k) 换资源配置：同作业不同 cores
        if op.tool == "submit_batch_job":
            pairs.append(Decoy(
                op,
                LogicalOp(f"{op.op_id}__cores", op.tool,
                          _one_field(s, "cores", 64), op.family),
                ("cores",), "换配置",
                "cores 改变资源与计费，按契约保守视为不同请求"))

        # (l) 换是否附带列：同切片不同返回结构
        if op.tool in ("query_region_stats", "query_station_stats"):
            f = "include_flag_dist" if op.tool == "query_region_stats" else "include_qc"
            dflt = TOOLS[op.tool]["optional"][f]
            pairs.append(Decoy(
                op,
                LogicalOp(f"{op.op_id}__col", op.tool,
                          _one_field(s, f, not dflt), op.family),
                (f,), "换返回列",
                f"{f} 改变返回列结构，消费方解析逻辑不同"))

    return pairs


def build_namespace_probes() -> List[Decoy]:
    """
    跨工具命名空间探针。

    这类负例的构造方式与同工具诱饵不同：**参数字典完全相同，只有工具不同**。
    它验证的是"键里有没有工具名"，与参数归一化无关。
    v1 的评估器遇到跨工具诱饵直接 `continue` 跳过（"不同工具天然隔离，
    不可能同键"）——但那个"天然隔离"是运行时假设，代码里并没有隔离。
    本版把工具名写进键，因此这类探针**必须全部区分**；若撞了就是 bug。

    注意：changed 为空元组是**故意的**，它不走 __post_init__ 的单字段断言。
    """
    # 用固定样本：同形参数、不同工具
    samples = [
        ("region+month", {"region": "南海北部", "month": "2026-08"},
         ["query_region_stats", "geocode_region"],
         "同一区域同一月份，一个查统计一个落格"),
        ("station+month", {"station": "S07", "month": "2026-08"},
         ["query_station_stats", "submit_batch_job", "write_qc_note"],
         "同一站点同一月份，查统计 / 提交作业 / 写备注是三种操作"),
        ("text", {"to": "duty@ocean.example", "subject": "南海北部拥挤告警"},
         ["send_email", "write_qc_note"],
         "文本字段形状相同，语义完全不同"),
    ]
    out: List[Decoy] = []
    for tag, args, tools, why in samples:
        for i in range(len(tools)):
            for j in range(i + 1, len(tools)):
                a = LogicalOp(f"ns_{tag}_{tools[i]}", tools[i], dict(args), tag)
                b = LogicalOp(f"ns_{tag}_{tools[j]}", tools[j], dict(args), tag)
                out.append(Decoy(a, b, (), "跨工具", why))
    return out


# --------------------------------------------------------------------------
# 4. 三类事件（审阅方 TABLE14）—— v1 完全没有第三类
# --------------------------------------------------------------------------

@dataclass
class EventPair:
    """
    一对事件，带"身份是否相同"与"变化是否保义"两个真值标签。

    ★ 第三轮：标签从**一个**布尔扩成**两个**布尔。
      第二版只有 identity_same，于是 e8_events() 只能拿 `a != b` 判"变了"，
      把 53 次保义改写（月份换写法、站号加连字符、区域加"海区"）全记成
      "语义冲突"。审阅方说得对：那是把"我抓到了 53 个坏东西"和
      "我误杀了 53 个好请求"混成一件事，方向完全相反。

    现在两个标签合起来给出**四类事件**，每类有明确的期望动作：

      原样重放        identity_same=T  change=T?否（a==b）      → 复用
      同身份保义改写   identity_same=T  semantic_change=False   → 复用
      同身份真实变义   identity_same=T  semantic_change=True    → 拒绝（报冲突）
      不同身份新意图   identity_same=F  （参数可同可不同）      → 执行

    `semantic_change` 由 contract.contract_equiv() 判定，不由 `a != b` 判定。
    """
    a: Dict[str, Any]
    b: Dict[str, Any]
    tool: str
    event_type: str            # replay / replan_equiv / replan_change / new_intent
    identity_same: bool
    semantic_change: bool = False
    expected_action: str = ""  # reuse / reject / execute
    id_a: str = ""
    id_b: str = ""
    note: str = ""


EVENT_TYPES = ("replay", "replan_equiv", "replan_change", "new_intent")

EVENT_CN = {
    "replay": "原样重放",
    "replan_equiv": "同身份保义改写",
    "replan_change": "同身份真实变义",
    "new_intent": "不同身份新意图",
}

EXPECTED_ACTION = {
    "replay": "reuse",
    "replan_equiv": "reuse",
    "replan_change": "reject",
    "new_intent": "execute",
}


def _semantic_change(tool: str, a: Dict[str, Any], b: Dict[str, Any]) -> bool:
    """
    两个参数字典之间是否存在**契约意义上的**语义变化。

    逐字段比对；只在 a 或 b 里出现的字段也算变化（缺省与给出不同）。
    `__` 前缀的追踪字段按契约不进键，因此不参与判定。
    """
    from contract import contract_equiv
    keys = (set(a) | set(b))
    for k in keys:
        if k.startswith("__"):
            continue
        va, vb = a.get(k), b.get(k)
        if va is None and vb is None:
            continue
        if not contract_equiv(tool, k, va, vb):
            return True
    return False


def build_event_pairs(ops: List[LogicalOp]) -> List[EventPair]:
    """
    构造四类事件对照集。

    ★ 第三轮重写。第二版的三类事件里，"重规划"这一类**全部**来自
      `_drift_alt()`，而它只返回保义等价形式（月份换写法、站号别名、
      区域别名）。也就是说第二版的 53 个"重规划"没有一个是真变义，
      却被 `a != b` 判成冲突。那是把自己的成功记成了事故。

    现在：
      · replan_equiv  —— 保义改写，期望**复用**（合并才是对的）
      · replan_change —— 真实变义，期望**拒绝**（合并才是错的）
    真实变义这一类是新增的，来源是真正改月份/改站号/改范围/改断言强度，
    不是换个写法。
    """
    out: List[EventPair] = []
    seq = 0

    for op in ops:
        s = op.slots

        # 1) 原样重放：参数逐字相同、身份相同 → 复用
        seq += 1
        oid = f"OP-{seq:05d}"
        out.append(EventPair(
            a=dict(s), b=dict(s), tool=op.tool,
            event_type="replay", identity_same=True, semantic_change=False,
            expected_action="reuse", id_a=oid, id_b=oid,
            note="传输层超时重试，应用应复用已确定的参数与身份"))

        # 2) 同身份保义改写：参数写法不同、语义相同、身份相同 → 复用
        for field, alt in _equiv_alt(op):
            seq += 1
            oid = f"OP-{seq:05d}"
            b = _one_field(s, field, alt)
            chg = _semantic_change(op.tool, s, b)
            out.append(EventPair(
                a=dict(s), b=b, tool=op.tool,
                event_type="replan_equiv", identity_same=True,
                semantic_change=chg, expected_action="reuse",
                id_a=oid, id_b=oid,
                note=f"重规划后 {field} 写成另一种等价形式，仍是同一次操作"))

        # 3) 同身份真实变义：参数真的改了、身份相同 → 拒绝（报冲突）
        for field, alt in _change_alt(op):
            seq += 1
            oid = f"OP-{seq:05d}"
            b = _one_field(s, field, alt)
            chg = _semantic_change(op.tool, s, b)
            out.append(EventPair(
                a=dict(s), b=b, tool=op.tool,
                event_type="replan_change", identity_same=True,
                semantic_change=chg, expected_action="reject",
                id_a=oid, id_b=oid,
                note=f"重规划后 {field} 真的变了（{alt!r}），同一个身份不能静默复用"))

        # 4) 不同身份新意图：参数**完全相同**，但身份不同 → 执行
        seq += 1
        out.append(EventPair(
            a=dict(s), b=dict(s), tool=op.tool,
            event_type="new_intent", identity_same=False, semantic_change=False,
            expected_action="execute",
            id_a=f"OP-{seq:05d}", id_b=f"OP-{seq:05d}b",
            note="两次独立的同类请求，参数相同但意图不同，必须执行两次"))

    return out


def _equiv_alt(op: LogicalOp) -> List[Tuple[str, Any]]:
    """
    保义等价写法。**全部由契约派生**（第三轮修正）。

    第二版这里自己维护了一份站号/区域别名映射（`st = {...}`、`rg = {...}`），
    于是契约并不是唯一来源——审阅方第七节（一）指出"标准只剩一处"不成立，
    一部分原因就在这里。现在一律从 contract 的别名表反查。
    """
    from contract import MONTH_EQUIV, REGION_ALIAS, STATION_ALIAS
    s = op.slots
    alts: List[Tuple[str, Any]] = []
    if "month" in s:
        cand = MONTH_EQUIV.get(s["month"])
        if cand:
            alts.append(("month", cand[0]))
    if "station" in s:
        rev = _reverse_alias(STATION_ALIAS, s["station"])
        if rev:
            alts.append(("station", rev))
    if "region" in s:
        rev = _reverse_alias(REGION_ALIAS, s["region"])
        if rev:
            alts.append(("region", rev))
    return alts


def _reverse_alias(table: Dict[str, str], canon: str) -> Optional[str]:
    """在"别名 → 规范名"的表里，找 canon 的另一种写法。"""
    for k, v in table.items():
        if v == canon and k != canon:
            return k
    return None


def _change_alt(op: LogicalOp) -> List[Tuple[str, Any]]:
    """
    真实变义。**与保义改写不同源**：这里改的是值本身，不是写法。

    来源都是业务上确凿不同的方向：
      month    重规划到另一个月（不同数据切片）
      station  重规划到另一个站（不同对象）
      region   换到另一个海区
      job_name 范围收窄（_partial / _S07only）
      note     断言强度 疑似 → 确认
    """
    s = op.slots
    alts: List[Tuple[str, Any]] = []
    if "month" in s and s["month"] in MONTHS:
        alts.append(("month", next(m for m in DECOY_MONTHS if m != s["month"])))
    if "station" in s and s["station"] in STATIONS:
        alts.append(("station", next(x for x in STATIONS if x != s["station"])))
    if "region" in s:
        alts.append(("region", next(r for r in DECOY_REGIONS if r != s["region"])))
    if op.tool == "submit_batch_job" and "job_name" in s:
        alts.append(("job_name", s["job_name"] + "_partial"))
    if op.tool == "write_qc_note" and "疑似" in s.get("note", ""):
        alts.append(("note", s["note"].replace("疑似", "确认")))
    return alts


def _drift_alt(op: LogicalOp) -> List[Tuple[str, Any]]:
    """兼容旧调用点：等价写法。已改为 `_equiv_alt` 的别名。"""
    return _equiv_alt(op)


if __name__ == "__main__":
    from collections import Counter

    ops = build_baseline_ops()
    same_tool = build_decoys(ops)
    ns = build_namespace_probes()
    dec = same_tool + ns
    ev = build_event_pairs(ops)

    print(f"基准操作 {len(ops)} 个")
    print("按工具:", dict(Counter(o.tool for o in ops)))
    print(f"\n诱饵 {len(dec)} 对 = 同工具 {len(same_tool)} + 跨工具 {len(ns)}")
    print("按类型:", dict(Counter(d.kind for d in dec)))
    bad = [d for d in dec if d.kind != "跨工具" and len(d.changed) != 1]
    print(f"  改多维度的同工具诱饵: {len(bad)}  "
          f"（跨工具探针 changed=() 是有意为之：参数相同、只有工具不同）")
    print(f"\n事件对 {len(ev)} 对，按类型:", dict(Counter(e.event_type for e in ev)))
    print("  其中参数完全相同的事件对:",
          sum(1 for e in ev if e.a == e.b),
          f"（new_intent {sum(1 for e in ev if e.a == e.b and e.event_type == 'new_intent')} 对"
          f" / retry {sum(1 for e in ev if e.a == e.b and e.event_type == 'retry')} 对）")
    print("\n副作用成本画像:")
    for t, cfg in TOOLS.items():
        rho = cfg["c_dup"] / cfg["c_miss"] if cfg["c_miss"] else float("inf")
        print(f"  {t:22s} side={cfg['side_effect']} c_dup={cfg['c_dup']:.1f} "
              f"c_miss={cfg['c_miss']:.1f} 比值={rho:.2f}")