"""
policy.py — 文本空间的键策略：SAFE 规则 + 可枚举的 RISKY 规则。

这一版相对 v1 有三处**性质上**的改动（不是调参）：

1. SAFE 不再是"名字叫安全"，而是"每一步都有契约依据"。
   v1 的 safe_alias 对所有字段套同一张别名表、safe_type_norm 对所有字符串
   试着转布尔/数值。审阅方两个反例（备注 "01" vs "1.0"、主题 "S07" vs "S-07"）
   就是这么来的。本版改为**按字段白名单**：字段不在 contract.TYPE_COERCIBLE /
   ALIAS_FIELDS 里，就一个字符都不许动。

2. 键里带工具命名空间。v1 两种 key 都只返回参数 JSON，评估遇到跨工具诱饵
   直接 skip——等于把"运行时另有隔离"这个**未验证假设**藏进了代码。

3. RISKY 规则可以按名字显式指定（不只是 alpha 旋钮）。
   这样才能穷举 5 条规则的 32 个子集，而不是只测 6 个前缀。

关于 ρ（本版改称 λ）
--------------------
v1 的实现是 `dup += extra * c_dup * rho`，也就是把每个工具**已有的** c_dup
再乘一个统一缩放量。所以：
  · 它**不是** c_dup/c_miss 的比值；
  · 各工具的真实代价比各不相同（批作业 2.5、写备注 1.25、邮件 2.0）；
  · "ρ≈2 所以开四条规则"这句话里的 2 是谁的 2，v1 没说清。
本版一律写作 λ（重复代价的整体缩放量），并在报告里给出每个工具的
真实比值与 C_k(λ) 的表达式。
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

import contract as C
from universe import TOOLS


# --------------------------------------------------------------------------
# 兼容别名：v1 的其他模块曾从这里 import 这三张表
# --------------------------------------------------------------------------
REGION_ALIAS = C.REGION_ALIAS
STATION_ALIAS = C.STATION_ALIAS
MONTH_ALIAS = C.MONTH_ALIAS
_norm_basic = lambda v: v          # 已废弃：见 safe_alias 的按字段白名单


# --------------------------------------------------------------------------
# 归一化原语（全部按字段类型分派，绝不"看值的类型"猜意图）
# --------------------------------------------------------------------------

_BOOL_TRUE = {"true", "1", "是", "yes", "t", "y"}
_BOOL_FALSE = {"false", "0", "否", "no", "f", "n"}


def _clean_text(v: Any, fold: bool = False) -> Any:
    """
    文本字段的归一。**默认逐字保留**，只有显式声明可折叠的字段才压缩空白。

    ★ 第三轮修正：第二版这里无条件执行
          re.sub(r"\\s+", " ", v.strip())
      注释还写着"这两步对任何文本字段都保义"。那个断言是错的：
      对 note 这种人手写的正文，换行是排版信息本身，
      "第一行\\n第二行" 与 "第一行 第二行" 是两段不同的文字。
      审阅方的空白探针正是打在这里。

    现在的规则：折叠与否由 contract.WHITESPACE_FOLDABLE 按字段声明，
    默认 False —— 沉默不是许可。
    """
    if not isinstance(v, str):
        return v
    if not fold:
        return v                       # 逐字保留，连首尾空白都不动
    return re.sub(r"\s+", " ", v.strip())


def _coerce_bool(v: Any) -> Any:
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)) and v in (0, 1):
        return bool(v)
    if isinstance(v, str):
        low = v.strip().lower()
        if low in _BOOL_TRUE:
            return True
        if low in _BOOL_FALSE:
            return False
    return v


def _coerce_int(v: Any) -> Any:
    if isinstance(v, bool):
        return v
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        return int(v) if v.is_integer() else v
    if isinstance(v, str):
        s = v.strip()
        try:
            f = float(s)
        except ValueError:
            return v
        return int(f) if f.is_integer() else f
    return v


def norm_field(tool: str, field_name: str, v: Any) -> Any:
    """
    单个字段的归一化。分派依据是**字段类别**（由 schema 默认值 + 契约白名单
    决定），不是"值长什么样"。
    """
    kind = C.field_kind(tool, field_name)
    fold = C.may_fold_whitespace(tool, field_name)

    if kind == "month":
        return C.norm_month(v)
    if kind == "station":
        return C.norm_station(v, allow_alias=C.may_alias(tool, field_name))
    if kind == "region":
        return C.norm_region(v, allow_alias=C.may_alias(tool, field_name))
    if kind == "bool":
        return _coerce_bool(v) if C.may_coerce(tool, field_name) else _clean_text(v, fold)
    if kind == "int":
        return _coerce_int(v) if C.may_coerce(tool, field_name) else _clean_text(v, fold)

    # text：**永不**转数值/布尔、**永不**套别名；空白是否折叠按字段声明
    return _clean_text(v, fold)


# --------------------------------------------------------------------------
# SAFE 流水线
# --------------------------------------------------------------------------

def safe_drop_noise(a: Dict[str, Any]) -> Dict[str, Any]:
    """丢掉 `__trace` / `__note` 之类非 schema 字段。"""
    return {k: v for k, v in a.items() if not k.startswith("__")}


def safe_schema_project(tool: str, a: Dict[str, Any]) -> Dict[str, Any]:
    """
    只保留契约声明的字段，并补齐 schema 默认值。
    补默认值是为了让"没写"与"显式写出默认值"等价——这两者确实保义，
    但必须在**归一化之后**再与默认值比较，否则 'true' 与 True 比不相等。
    """
    fields = C.key_fields(tool)
    out: Dict[str, Any] = {}
    for f in fields:
        if f in a:
            out[f] = a[f]
        else:
            d = C.default_of(tool, f)
            if d is not None or f in TOOLS[tool]["optional"]:
                out[f] = d
    return out


def safe_normalize(tool: str, a: Dict[str, Any]) -> Dict[str, Any]:
    return {f: norm_field(tool, f, v) for f, v in a.items()}


def safe_drop_explicit_default(tool: str, a: Dict[str, Any]) -> Dict[str, Any]:
    """归一化之后，显式写出的默认值与"没写"已经同形，可以合并。"""
    out = {}
    for f, v in a.items():
        d = C.default_of(tool, f)
        if f in TOOLS[tool]["optional"] and d == v:
            continue
        out[f] = v
    return out


# --------------------------------------------------------------------------
# RISKY 规则（按危险度升序给出排序，执行顺序另有一张表）
# --------------------------------------------------------------------------

@dataclass
class Rule:
    key: str
    name: str
    dangerousness: float        # 0=最无害, 越大越危险
    eats: str                   # 它吃掉哪一类语义边界
    fn: Any = None


_TOK = re.compile(r"[a-z0-9]+|[\u4e00-\u9fff]")
_DROP_INTENSITY = ["疑似出现", "可能存在", "疑似", "疑为", "已确认", "确认",
                   "建议", "复核", "suspected", "please", "retry", "again"]

# 文本类规则只作用于**自由文本**字段。
# v1 对**所有** str 值做词袋化，连 duty@ocean.example 都被打散成
# "duty example ocean"、连 body_ref 的 "B-002" 都被切成 "002 b"。
# 那不是"文本归一化"，是把标识符当散文处理。标识型字段（邮箱、引用号、
# 枚举值）参与的是精确相等判断，任何字符级重排都是纯损失。
FREE_TEXT_FIELDS = {"note", "job_name", "subject"}


def risky_text_bag(tool: str, a: Dict[str, Any]) -> Dict[str, Any]:
    """词袋化：丢语序、丢标点。会抹平"甲影响乙"与"乙影响甲"。"""
    out = {}
    for k, v in a.items():
        if k in FREE_TEXT_FIELDS and isinstance(v, str) and len(v) > 3:
            out[k] = " ".join(sorted(_TOK.findall(v.lower())))
        else:
            out[k] = v
    return out


def risky_time_coarse(tool: str, a: Dict[str, Any]) -> Dict[str, Any]:
    """时间精度截断：YYYY-MM-DD → YYYY-MM。本版契约明确说这不保义。"""
    out = {}
    for k, v in a.items():
        if isinstance(v, str):
            m = re.fullmatch(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", v.strip())
            if m and (k == "month" or k.endswith("_month") or "date" in k):
                v = f"{m.group(1)}-{int(m.group(2)):02d}"
        out[k] = v
    return out


def risky_space_coarse(tool: str, a: Dict[str, Any]) -> Dict[str, Any]:
    """空间精度截断：南海北部/中部 → 南海。相邻海区被合并。"""
    out = {}
    for k, v in a.items():
        if k == "region" and isinstance(v, str):
            if "南海" in v:
                v = "南海"
            elif "东海" in v:
                v = "东海"
        out[k] = v
    return out


def risky_strip_intensity(tool: str, a: Dict[str, Any]) -> Dict[str, Any]:
    """剥离断言强度词。'疑似' vs '确认' 只差两个字，责任差一个量级。"""
    out = {}
    for k, v in a.items():
        if k in FREE_TEXT_FIELDS and isinstance(v, str) and len(v) > 3:
            s = v
            for w in _DROP_INTENSITY:
                s = s.replace(w, " ")
            out[k] = " ".join(sorted(_TOK.findall(s.lower())))
        else:
            out[k] = v
    return out


def risky_scope_drop(tool: str, a: Dict[str, Any]) -> Dict[str, Any]:
    """丢弃范围限定词。'只重算 S07' 与 '全部重算' 被当成同一件事。"""
    out = {}
    for k, v in a.items():
        if k in FREE_TEXT_FIELDS and isinstance(v, str):
            out[k] = re.sub(r"[_-](s\d{2}\s*only|partial|only|\u5168\u90e8|all)\b",
                            "", v, flags=re.I)
        else:
            out[k] = v
    return out


# 执行顺序：**结构级先、文本级后**。
# 词袋化会把 '2026-08-15' 打散成 '08 15 2026'，之后再跑时间截断就匹配不上。
RISKY_RULES: List[Rule] = [
    Rule("scope_drop", "丢弃范围限定词", 0.95, "部分 / 全部", risky_scope_drop),
    Rule("strip_intensity", "剥离断言强度词", 0.75, "疑似 / 确认", risky_strip_intensity),
    Rule("space_coarse", "空间精度截断到海", 0.60, "相邻海区", risky_space_coarse),
    Rule("time_coarse", "时间精度截断到月", 0.45, "同月不同日", risky_time_coarse),
    Rule("text_bag", "文本词袋化", 0.20, "语序 / 否定式", risky_text_bag),
]
RULE_BY_KEY = {r.key: r for r in RISKY_RULES}
BY_DANGER = sorted(RISKY_RULES, key=lambda r: r.dangerousness)
EXEC_ORDER = {r.key: i for i, r in enumerate(RISKY_RULES)}


class KeyPolicy:
    """
    文本空间键策略。

    两种构造方式：
        KeyPolicy(tool, alpha=0.0)                 # 老接口：按危险度取前 k 条
        KeyPolicy(tool, rule_keys=["text_bag"])    # 新接口：显式指定，供 32 子集穷举
    """

    def __init__(self, tool: str, alpha: float = 0.0, safe: bool = True,
                 rule_keys: Optional[Sequence[str]] = None):
        self.tool = tool
        self.alpha = max(0.0, min(1.0, alpha))
        self.safe = safe
        if rule_keys is None:
            k = int(round(self.alpha * len(BY_DANGER)))
            chosen = BY_DANGER[:k]
        else:
            unknown = [k for k in rule_keys if k not in RULE_BY_KEY]
            if unknown:
                raise KeyError(f"未知 RISKY 规则：{unknown}")
            chosen = [RULE_BY_KEY[k] for k in rule_keys]
        self.active_risky = sorted(chosen, key=lambda r: EXEC_ORDER[r.key])

    @property
    def n_risky(self) -> int:
        return len(self.active_risky)

    @property
    def rule_keys(self) -> List[str]:
        return [r.key for r in self.active_risky]

    def project(self, args: Dict[str, Any]) -> Dict[str, Any]:
        a = dict(args)
        if self.safe:
            a = safe_drop_noise(a)
            a = safe_schema_project(self.tool, a)
            a = safe_normalize(self.tool, a)
            a = safe_drop_explicit_default(self.tool, a)
        for r in self.active_risky:
            a = r.fn(self.tool, a)
        return {k: a[k] for k in sorted(a)}

    def key(self, args: Dict[str, Any]) -> str:
        # 命名空间：工具名进键。没有它，两个工具同形参数直接撞。
        body = json.dumps(self.project(args), ensure_ascii=False, sort_keys=True,
                          separators=(",", ":"))
        return f"{self.tool}{C.KEY_NAMESPACE_SEP}{body}"

    def describe(self) -> str:
        if not self.active_risky:
            return "SAFE only"
        return "SAFE + " + ",".join(self.rule_keys)


NAMED = {
    "strict": 0.0, "eng": 0.4, "loose": 0.6, "sloppy": 0.8, "chaos": 1.0,
}


if __name__ == "__main__":
    demo = {"job_name": "recompute_S07_2026-08", "station": " S07",
            "month": "2026年8月", "__trace": "req-1234"}
    print("=== SAFE 归一化（alpha=0）===")
    p = KeyPolicy("submit_batch_job", 0.0)
    print("  输入:", json.dumps(demo, ensure_ascii=False))
    print("  键  :", p.key(demo))

    print("\n=== 类型契约：文本字段不许转 ===")
    q = KeyPolicy("write_qc_note", 0.0)
    for note in ("01", "1.0"):
        print(f"  note={note!r:8s} → {q.key({'station': 'S07', 'month': '2026-08', 'note': note})}")
    e = KeyPolicy("send_email", 0.0)
    for subj in ("S07", "S-07"):
        print(f"  subject={subj!r:8s} → {e.key({'to': 'duty@lab.cn', 'subject': subj})}")

    print("\n=== RISKY 规则清单（危险度升序）===")
    for r in BY_DANGER:
        print(f"  {r.dangerousness:.2f}  {r.name:14s} 吃掉: {r.eats}")